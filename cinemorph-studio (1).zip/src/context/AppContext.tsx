import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  StudioToolId,
  AdminSiteConfig,
  SavedProject
} from '../types';
import { DEFAULT_ADMIN_CONFIG } from '../constants/defaults';
import { ApiService } from '../services/api';

export type AppView = 'home' | 'tool' | 'pricing' | 'projects' | 'admin' | 'legal';
export type LegalPageSlug =
  | 'about'
  | 'contact'
  | 'privacy'
  | 'terms'
  | 'cookies'
  | 'disclaimer'
  | 'dmca'
  | 'acceptable-use'
  | 'refund'
  | 'ai-disclaimer'
  | 'security'
  | 'faq';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AppContextType {
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  activeToolId: StudioToolId;
  setActiveToolId: (toolId: StudioToolId) => void;
  openTool: (toolId: StudioToolId) => void;
  activeLegalSlug: LegalPageSlug;
  openLegalPage: (slug: LegalPageSlug) => void;
  isDark: boolean;
  toggleTheme: () => void;
  siteConfig: AdminSiteConfig;
  updateSiteConfig: (newConfig: AdminSiteConfig) => Promise<boolean>;
  isAdminAuthenticated: boolean;
  adminUser: { email: string; role: string } | null;
  adminToken: string | null;
  loginAdmin: (token: string, user: { email: string; role: string }) => void;
  logoutAdmin: () => void;
  savedProjects: SavedProject[];
  saveProject: (project: Omit<SavedProject, 'id' | 'createdAt'>) => SavedProject;
  deleteProject: (id: string) => void;
  toasts: ToastMessage[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [activeToolId, setActiveToolId] = useState<StudioToolId>('cartoon');
  const [activeLegalSlug, setActiveLegalSlug] = useState<LegalPageSlug>('about');
  const [isDark, setIsDark] = useState<boolean>(true);
  const [siteConfig, setSiteConfig] = useState<AdminSiteConfig>(() => {
    const local = localStorage.getItem('cinemorph_site_config');
    if (local) {
      try { return JSON.parse(local); } catch { /* ignore */ }
    }
    return DEFAULT_ADMIN_CONFIG;
  });

  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(false);
  const [adminUser, setAdminUser] = useState<{ email: string; role: string } | null>(null);
  const [adminToken, setAdminToken] = useState<string | null>(null);

  const [savedProjects, setSavedProjects] = useState<SavedProject[]>(() => {
    const local = localStorage.getItem('cinemorph_saved_projects');
    if (local) {
      try { return JSON.parse(local); } catch { /* ignore */ }
    }
    return [];
  });

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Initialize URL parameters and server config
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const viewParam = params.get('view') as AppView | null;
    const toolParam = params.get('tool') as StudioToolId | null;
    const pageParam = params.get('page') as LegalPageSlug | null;

    if (viewParam) {
      setCurrentView(viewParam);
    } else if (toolParam) {
      setActiveToolId(toolParam);
      setCurrentView('tool');
    } else if (pageParam) {
      setActiveLegalSlug(pageParam);
      setCurrentView('legal');
    }

    // Check stored admin session
    const storedToken = sessionStorage.getItem('cinemorph_admin_token');
    const storedUser = sessionStorage.getItem('cinemorph_admin_user');
    if (storedToken && storedUser) {
      try {
        setAdminToken(storedToken);
        setAdminUser(JSON.parse(storedUser));
        setIsAdminAuthenticated(true);
      } catch {
        sessionStorage.removeItem('cinemorph_admin_token');
      }
    }

    // Sync config from server
    ApiService.getSiteConfig().then((serverCfg) => {
      if (serverCfg && serverCfg.siteName) {
        setSiteConfig(serverCfg);
        localStorage.setItem('cinemorph_site_config', JSON.stringify(serverCfg));
      }
    });
  }, []);

  // Sync theme class
  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [isDark]);

  const toggleTheme = () => {
    setIsDark(prev => !prev);
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  const openTool = (toolId: StudioToolId) => {
    setActiveToolId(toolId);
    setCurrentView('tool');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    window.history.pushState({}, '', `/?tool=${toolId}`);
  };

  const openLegalPage = (slug: LegalPageSlug) => {
    setActiveLegalSlug(slug);
    setCurrentView('legal');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    window.history.pushState({}, '', `/?page=${slug}`);
  };

  const loginAdmin = (token: string, user: { email: string; role: string }) => {
    setAdminToken(token);
    setAdminUser(user);
    setIsAdminAuthenticated(true);
    sessionStorage.setItem('cinemorph_admin_token', token);
    sessionStorage.setItem('cinemorph_admin_user', JSON.stringify(user));
    showToast('Admin session authenticated successfully', 'success');
  };

  const logoutAdmin = () => {
    setAdminToken(null);
    setAdminUser(null);
    setIsAdminAuthenticated(false);
    sessionStorage.removeItem('cinemorph_admin_token');
    sessionStorage.removeItem('cinemorph_admin_user');
    showToast('Logged out from admin panel', 'info');
    setCurrentView('home');
  };

  const updateSiteConfig = async (newConfig: AdminSiteConfig): Promise<boolean> => {
    setSiteConfig(newConfig);
    localStorage.setItem('cinemorph_site_config', JSON.stringify(newConfig));
    if (adminToken) {
      const ok = await ApiService.saveSiteConfig(newConfig, adminToken);
      if (ok) {
        showToast('Site settings updated and saved to server', 'success');
        return true;
      }
    }
    showToast('Site settings updated locally', 'info');
    return true;
  };

  const saveProject = (projectData: Omit<SavedProject, 'id' | 'createdAt'>): SavedProject => {
    const newProject: SavedProject = {
      ...projectData,
      id: `proj_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      createdAt: Date.now()
    };
    const updated = [newProject, ...savedProjects];
    setSavedProjects(updated);
    localStorage.setItem('cinemorph_saved_projects', JSON.stringify(updated));
    showToast(`Project "${newProject.title}" saved to library`, 'success');
    return newProject;
  };

  const deleteProject = (id: string) => {
    const updated = savedProjects.filter(p => p.id !== id);
    setSavedProjects(updated);
    localStorage.setItem('cinemorph_saved_projects', JSON.stringify(updated));
    showToast('Project removed', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        activeToolId,
        setActiveToolId,
        openTool,
        activeLegalSlug,
        openLegalPage,
        isDark,
        toggleTheme,
        siteConfig,
        updateSiteConfig,
        isAdminAuthenticated,
        adminUser,
        adminToken,
        loginAdmin,
        logoutAdmin,
        savedProjects,
        saveProject,
        deleteProject,
        toasts,
        showToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
