export type DashboardCategory =
  | 'VIDEO'
  | 'AUDIO'
  | 'AI VIDEO'
  | 'AI AUDIO'
  | 'CAPTIONS & TRANSCRIPTS'
  | 'SHORTS & SOCIAL'
  | 'EDITOR'
  | 'CONTENT AI'
  | 'IMAGE & THUMBNAIL'
  | 'CONVERTERS'
  | 'COMPRESSORS'
  | 'GIF & MEDIA'
  | 'PROJECTS'
  | 'TOOLS'
  | 'SETTINGS';

export type StudioToolId =
  | 'cartoon'
  | 'viral-shorts'
  | 'captions'
  | 'dubbing'
  | 'tts'
  | 'speech-to-text'
  | 'editor'
  | 'enhancer'
  | 'audio-toolkit'
  | 'video-toolkit'
  | 'content'
  | 'thumbnail'
  | 'gif-media'
  | 'social-repurpose'
  | 'converter'
  | 'compressor'
  | 'resizer'
  | 'audio'
  | 'transcription';

export interface StudioToolMeta {
  id: StudioToolId;
  name: string;
  tagline: string;
  category: DashboardCategory;
  description: string;
  iconName: string;
  badge?: string;
  isPopular?: boolean;
  subtools?: string[];
}

export type CartoonStyleId =
  | '2d-cartoon'
  | '3d-cartoon'
  | 'anime'
  | 'comic-book'
  | 'watercolor'
  | 'hand-drawn'
  | 'pixar-inspired'
  | 'claymation'
  | 'sketch'
  | 'cinematic-animation'
  | 'kids-cartoon'
  | 'chibi'
  | 'retro-cartoon'
  | 'cyberpunk-animation'
  | 'fantasy-animation'
  | 'storybook'
  | 'ink'
  | 'custom';

export interface CartoonStyleConfig {
  id: CartoonStyleId;
  name: string;
  description: string;
  edgeStrength: number; // 0 to 100
  edgeThreshold: number; // 0 to 255
  colorBands: number; // 2 to 32
  saturation: number; // 0 to 200%
  contrast: number; // 50 to 200%
  brightness: number; // -50 to 50
  smoothness: number; // 1 to 5
  fpsLimit?: number;
  grain?: number;
  bloom?: number;
  warmth?: number;
  styleStrength?: number; // 0 to 100
  consistency?: number; // 0 to 100
  detailLevel?: number; // 0 to 100
  facePreservation?: boolean;
  motionPreservation?: boolean;
  prompt?: string;
  negativePrompt?: string;
}

export interface ViralClipItem {
  id: string;
  title: string;
  hook: string;
  startTime: number;
  endTime: number;
  duration: number;
  viralScore: number;
  rationale: string;
  aspectRatio: '9:16' | '1:1' | '16:9' | '4:5' | '4:3';
  subtitlesCount: number;
  sentenceBoundaryStart?: string;
  sentenceBoundaryEnd?: string;
  ctaSuggestion?: string;
  hashtags?: string[];
  description?: string;
}

export interface SubtitleWord {
  word: string;
  start: number;
  end: number;
}

export interface SubtitleCue {
  id: string;
  startTime: number;
  endTime: number;
  text: string;
  translatedText?: string;
  speaker?: string;
  words?: SubtitleWord[];
}

export interface SubtitleStylePreset {
  id: 'hormozi' | 'cyber' | 'minimal' | 'netflix' | 'boxed' | 'shadow' | 'cinematic' | 'karaoke';
  name: string;
  fontFamily: string;
  fontSize: number;
  textColor: string;
  highlightColor: string;
  backgroundColor?: string;
  strokeColor?: string;
  strokeWidth?: number;
  textTransform: 'uppercase' | 'none';
  positionY: number;
}

export interface TimelineTrackItem {
  id: string;
  trackId: string;
  type: 'video' | 'audio' | 'text' | 'image';
  name: string;
  startTime: number; // timeline seconds
  duration: number; // clip duration seconds
  sourceOffset: number; // source offset seconds
  speed: number;
  volume: number;
  opacity: number;
  rotation: number;
  scale: number;
  x: number;
  y: number;
  color?: string;
  textContent?: string;
  fontSize?: number;
  fontFamily?: string;
  textColor?: string;
  backgroundColor?: string;
}

export interface TimelineTrack {
  id: string;
  name: string;
  type: 'video' | 'audio' | 'overlay';
  muted: boolean;
  locked: boolean;
  visible: boolean;
}

export interface JobItem {
  id: string;
  type: string;
  status: 'queued' | 'processing' | 'completed' | 'failed' | 'cancelled';
  progress: number;
  currentStep?: string;
  error?: string;
  resultUrl?: string;
  createdAt: number;
  updatedAt: number;
  metadata?: Record<string, unknown>;
}

export interface PricingPlan {
  id: 'free' | 'pro' | 'premium' | 'business';
  name: string;
  tagline: string;
  priceMonthly: number;
  priceYearly: number;
  enabled: boolean;
  isPopular?: boolean;
  features: string[];
  limits: {
    exportsPerDay: number;
    maxResolution: '720p' | '1080p' | '2K' | '4K';
    maxDurationMinutes: number;
    aiCreditsPerMonth: number;
    watermark: boolean;
    priorityProcessing: boolean;
  };
}

export interface SiteAnnouncement {
  show: boolean;
  message: string;
  type: 'info' | 'warning' | 'success';
}

export interface AdminSiteConfig {
  siteName: string;
  tagline: string;
  logoText: string;
  accentColor: string;
  supportEmail: string;
  supportWhatsApp: string;
  maintenanceMode: boolean;
  announcement: SiteAnnouncement;
  toolSettings: Record<string, { enabled: boolean; customName?: string; dailyLimit: number; category?: string }>;
  plans: PricingPlan[];
  seo: {
    siteTitle: string;
    metaDescription: string;
    keywords: string;
    canonicalUrl: string;
    ogImageUrl: string;
  };
  analytics: {
    ga4MeasurementId: string;
    googleSearchConsoleCode: string;
    adsensePublisherId: string;
    enableAdSensePlaceholders: boolean;
  };
}

export interface SavedProject {
  id: string;
  title: string;
  toolId: StudioToolId;
  createdAt: number;
  duration?: number;
  resolution?: string;
  fileSize?: string;
  previewUrl?: string;
  metadata?: Record<string, unknown>;
  timelineState?: {
    tracks: TimelineTrack[];
    items: TimelineTrackItem[];
  };
}

export interface AIContentToolMeta {
  id: string;
  name: string;
  category: 'Video Scripts' | 'Hooks & Titles' | 'Social Repurposing' | 'Copywriting' | 'YouTube & SEO';
  description: string;
  promptTemplate: string;
  inputs: {
    name: string;
    label: string;
    type: 'text' | 'textarea' | 'select';
    placeholder?: string;
    options?: string[];
    defaultValue?: string;
  }[];
}

export interface SupportedLanguage {
  code: string;
  name: string;
  nativeName: string;
  flag?: string;
}
