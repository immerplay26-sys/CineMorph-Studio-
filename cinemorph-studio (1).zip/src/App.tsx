import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { NotificationToast } from './components/common/NotificationToast';

import { StudioHome } from './components/dashboard/StudioHome';
import { PricingView } from './components/dashboard/PricingView';
import { ProjectsLibrary } from './components/dashboard/ProjectsLibrary';

import { CartoonStudio } from './components/tools/CartoonStudio';
import { ViralShortsMaker } from './components/tools/ViralShortsMaker';
import { AICaptionsTool } from './components/tools/AICaptionsTool';
import { TextToSpeechTool } from './components/tools/TextToSpeechTool';
import { VideoEnhancerTool } from './components/tools/VideoEnhancerTool';
import { VideoConverterTool } from './components/tools/VideoConverterTool';
import { VideoCompressorTool } from './components/tools/VideoCompressorTool';
import { VideoResizerTool } from './components/tools/VideoResizerTool';
import { VideoEditorTool } from './components/tools/VideoEditorTool';
import { AudioStudioTool } from './components/tools/AudioStudioTool';
import { AudioToolkitComplete } from './components/tools/AudioToolkitComplete';
import { MultilingualDubbingTool } from './components/tools/MultilingualDubbingTool';
import { AIContentStudio } from './components/tools/AIContentStudio';
import { TranscriptionTool } from './components/tools/TranscriptionTool';
import { ThumbnailStudioTool } from './components/tools/ThumbnailStudioTool';
import { SocialRepurposerTool } from './components/tools/SocialRepurposerTool';
import { GifMediaTool } from './components/tools/GifMediaTool';

import { AdminPanel } from './components/admin/AdminPanel';
import { AdminLogin } from './components/admin/AdminLogin';
import { LegalPages } from './components/legal/LegalPages';
import { Wrench, Phone, Mail } from 'lucide-react';

const AppContent: React.FC = () => {
  const { currentView, activeToolId, isAdminAuthenticated, siteConfig } = useApp();

  // Maintenance mode screen if active and user not an admin
  if (siteConfig.maintenanceMode && !isAdminAuthenticated) {
    return (
      <div className="min-h-screen bg-neutral-950 text-white flex items-center justify-center p-6 text-center">
        <div className="max-w-md space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
            <Wrench className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold">{siteConfig.siteName} is under maintenance</h1>
          <p className="text-xs text-neutral-400">
            We are performing scheduled upgrades to enhance video and neural processing speeds. We will be back online shortly.
          </p>
          <div className="pt-4 border-t border-neutral-800 text-xs text-neutral-500 space-y-1">
            <p>WhatsApp: +923199389323</p>
            <p>Email: muhammadofficial356@gmail.com</p>
          </div>
        </div>
      </div>
    );
  }

  const renderTool = () => {
    switch (activeToolId) {
      case 'cartoon':
        return <CartoonStudio />;
      case 'viral-shorts':
        return <ViralShortsMaker />;
      case 'captions':
        return <AICaptionsTool />;
      case 'dubbing':
        return <MultilingualDubbingTool />;
      case 'tts':
        return <TextToSpeechTool />;
      case 'enhancer':
        return <VideoEnhancerTool />;
      case 'converter':
        return <VideoConverterTool />;
      case 'compressor':
        return <VideoCompressorTool />;
      case 'resizer':
      case 'video-toolkit':
        return <VideoResizerTool />;
      case 'editor':
        return <VideoEditorTool />;
      case 'audio':
      case 'audio-toolkit':
        return <AudioToolkitComplete />;
      case 'content':
        return <AIContentStudio />;
      case 'transcription':
      case 'speech-to-text':
        return <TranscriptionTool />;
      case 'thumbnail':
        return <ThumbnailStudioTool />;
      case 'social-repurpose':
        return <SocialRepurposerTool />;
      case 'gif-media':
        return <GifMediaTool />;
      default:
        return <CartoonStudio />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 transition-colors">
      <Header />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentView === 'home' && <StudioHome />}
        {currentView === 'tool' && renderTool()}
        {currentView === 'pricing' && <PricingView />}
        {currentView === 'projects' && <ProjectsLibrary />}
        {currentView === 'legal' && <LegalPages />}
        {currentView === 'admin' && (isAdminAuthenticated ? <AdminPanel /> : <AdminLogin />)}
      </main>

      <Footer />
      <NotificationToast />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
