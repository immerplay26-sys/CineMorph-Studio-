import {
  StudioToolMeta,
  CartoonStyleConfig,
  PricingPlan,
  AdminSiteConfig,
  SubtitleStylePreset,
  AIContentToolMeta,
  SupportedLanguage,
  DashboardCategory
} from '../types';

export const SUPPORTED_LANGUAGES: SupportedLanguage[] = [
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'ur', name: 'Urdu', nativeName: 'اردو' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية' },
  { code: 'fa', name: 'Persian', nativeName: 'فارسی' },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe' },
  { code: 'es', name: 'Spanish', nativeName: 'Español' },
  { code: 'fr', name: 'French', nativeName: 'Français' },
  { code: 'de', name: 'German', nativeName: 'Deutsch' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português' },
  { code: 'nl', name: 'Dutch', nativeName: 'Nederlands' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский' },
  { code: 'uk', name: 'Ukrainian', nativeName: 'Українська' },
  { code: 'pl', name: 'Polish', nativeName: 'Polski' },
  { code: 'ro', name: 'Romanian', nativeName: 'Română' },
  { code: 'el', name: 'Greek', nativeName: 'Ελληνικά' },
  { code: 'he', name: 'Hebrew', nativeName: 'עברית' },
  { code: 'zh', name: 'Chinese (Simplified)', nativeName: '简体中文' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語' },
  { code: 'ko', name: 'Korean', nativeName: '한국어' },
  { code: 'th', name: 'Thai', nativeName: 'ไทย' },
  { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt' },
  { code: 'id', name: 'Indonesian', nativeName: 'Bahasa Indonesia' },
  { code: 'ms', name: 'Malay', nativeName: 'Bahasa Melayu' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी' },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം' },
  { code: 'ne', name: 'Nepali', nativeName: 'नेपाली' },
  { code: 'sv', name: 'Swedish', nativeName: 'Svenska' },
  { code: 'no', name: 'Norwegian', nativeName: 'Norsk' },
  { code: 'da', name: 'Danish', nativeName: 'Dansk' },
  { code: 'fi', name: 'Finnish', nativeName: 'Suomi' },
  { code: 'cs', name: 'Czech', nativeName: 'Čeština' },
  { code: 'sk', name: 'Slovak', nativeName: 'Slovenčina' },
  { code: 'hu', name: 'Hungarian', nativeName: 'Magyar' },
  { code: 'bg', name: 'Bulgarian', nativeName: 'Български' },
  { code: 'sr', name: 'Serbian', nativeName: 'Српски' },
  { code: 'hr', name: 'Croatian', nativeName: 'Hrvatski' },
  { code: 'tl', name: 'Filipino (Tagalog)', nativeName: 'Tagalog' },
  { code: 'sw', name: 'Swahili', nativeName: 'Kiswahili' }
];

export const STUDIO_TOOLS: StudioToolMeta[] = [
  {
    id: 'cartoon',
    name: 'Real Video to Cartoon & Animation',
    tagline: 'Transform real video footage into 18 animation & artistic styles',
    category: 'AI VIDEO',
    description: 'Transform visual appearance into 2D Cartoon, Anime, 3D Pixar-style, Watercolor, Comic, Ink, and Claymation while keeping motion, subjects, and camera timing intact.',
    iconName: 'Sparkles',
    badge: 'Flagship AI',
    isPopular: true,
    subtools: ['2D Cartoon', 'Anime', '3D Stylized', 'Comic Halftone', 'Watercolor', 'Stop Motion']
  },
  {
    id: 'viral-shorts',
    name: 'Viral Clip & Shorts Maker',
    tagline: 'Analyze long-form video into high-retention short clips with smart reframing',
    category: 'SHORTS & SOCIAL',
    description: 'AI detects interesting hooks and speech moments, removes silence, cuts at sentence boundaries, reframes to 9:16 vertical, and animates karaoke captions.',
    iconName: 'Film',
    badge: 'Popular',
    isPopular: true,
    subtools: ['AI Highlight Detector', 'Smart 9:16 Reframe', 'Auto-Duration (15-90s)', 'Batch Clip Export', 'Safe-Zone Overlay']
  },
  {
    id: 'captions',
    name: 'AI Caption & Subtitle Studio',
    tagline: 'Automatic speech recognition, subtitle editor, and animated burned-in typography',
    category: 'CAPTIONS & TRANSCRIPTS',
    description: 'Supports real speech transcription in 45+ languages with word-level highlights, timing adjustment, font/stroke/shadow controls, and SRT/VTT/TXT export.',
    iconName: 'Subtitles',
    badge: 'Essential',
    isPopular: true,
    subtools: ['Speech Recognition', 'Word-level Timing', 'Hormozi Style', 'SRT/VTT Export', 'Burn to Video']
  },
  {
    id: 'dubbing',
    name: 'Multilingual Video Dubbing & Translation',
    tagline: 'Translate video voice and subtitles into 45+ languages with timing preservation',
    category: 'AI AUDIO',
    description: 'Full translation pipeline with speaker gender matching, synchronized audio timing, voice speed modulation, and simultaneous translated captions.',
    iconName: 'Languages',
    badge: 'Multilingual',
    isPopular: true,
    subtools: ['Voice Dubbing', 'Subtitle Translation', '45+ Languages', 'Original Audio Blend', 'Voice Speed Sync']
  },
  {
    id: 'tts',
    name: 'Text to Speech (AI Neural Voices)',
    tagline: 'Generate natural, studio-quality speech with custom voice personas',
    category: 'AI AUDIO',
    description: 'Powered by Gemini 3.8 Flash Lite TTS with prebuilt voices (Kore, Puck, Charon, Fenrir, Zephyr), speed/pitch modulation, and broadcast WAV export.',
    iconName: 'Mic',
    badge: 'Fast',
    subtools: ['5 Neural Personas', 'Speed/Pitch Controls', 'Broadcast WAV', 'Preview Player']
  },
  {
    id: 'speech-to-text',
    name: 'Speech to Text & Transcription',
    tagline: 'Convert spoken media into timestamped transcripts with speaker diarization',
    category: 'CAPTIONS & TRANSCRIPTS',
    description: 'High-accuracy speech-to-text with speaker identification, search & replace, transcript cleanup, and 1-click clipboard or document download.',
    iconName: 'AlignLeft',
    subtools: ['Timestamp Generator', 'Speaker Diarization', 'Filler Word Cleaner', 'TXT/SRT Export']
  },
  {
    id: 'editor',
    name: 'Multi-Track Timeline Video Editor',
    tagline: 'Professional browser-based NLE video & audio timeline editor',
    category: 'EDITOR',
    description: 'Multi-track timeline with video, audio, text, and image tracks. Trim, split, ripple delete, rotate, opacity, speed ramp, audio sync, filters, and undo/redo.',
    iconName: 'Scissors',
    isPopular: true,
    subtools: ['Multi-Track Timeline', 'Trim & Split', 'Ripple Delete', 'Text Overlays', 'Audio Sync', 'Filters & Color']
  },
  {
    id: 'enhancer',
    name: 'Video Enhancer & Upscaler',
    tagline: 'Sharpen, reduce noise, equalize contrast, and improve resolution up to 2K',
    category: 'VIDEO',
    description: 'Fine-tuned digital processing algorithms to deblur, sharpen edges, balance dynamic range, clean compression artifacts, with split before/after comparison.',
    iconName: 'Wand2',
    subtools: ['Unsharp Mask', 'Edge Restoration', 'Dynamic Range Lift', 'Denoise Filter', 'Split Comparison']
  },
  {
    id: 'audio-toolkit',
    name: 'Complete Audio Toolkit',
    tagline: 'Vocal remover, audio converter, compressor, cutter, silence remover, and recorder',
    category: 'AUDIO',
    description: 'Full suite of audio utilities: Vocal Remover (karaoke/instrumental extractor), Audio Converter (MP3, WAV, AAC, OGG, OPUS), Normalizer, Equalizer, Cutter, and Voice Recorder.',
    iconName: 'Volume2',
    badge: 'Complete Suite',
    isPopular: true,
    subtools: ['Vocal Remover', 'Audio Converter', 'Silence Detector', 'Audio Trimmer', 'Normalizer & EQ', 'Voice Recorder']
  },
  {
    id: 'video-toolkit',
    name: 'Complete Video Toolkit',
    tagline: 'Converter, compressor, resizer, cropper, rotator, speed, reverse, and frame extractor',
    category: 'VIDEO',
    description: 'Comprehensive utility suite for quick video operations: format transcoding, file size compressor, aspect ratio resizer, cropper, speed changer, and frame extractor.',
    iconName: 'Video',
    subtools: ['Format Transcoder', 'Size Compressor', 'Social Resizer', 'Speed Changer', 'Frame Extractor']
  },
  {
    id: 'content',
    name: 'AI Content & Script Studio',
    tagline: '40+ specialized creator AI engines for scripts, viral hooks, titles, and SEO',
    category: 'CONTENT AI',
    description: 'High-impact AI copy generation for YouTube, TikTok, Instagram Reels, and blogs powered by Gemini 3.8 Flash without conversational fluff.',
    iconName: 'FileText',
    badge: '40+ Engines',
    isPopular: true,
    subtools: ['Video Scripts', 'First 3s Hooks', 'High-CTR Titles', 'SEO Descriptions', 'Trending Hashtags', 'Content Calendar']
  },
  {
    id: 'thumbnail',
    name: 'Thumbnail & Graphic Studio',
    tagline: 'Design high-CTR clickable thumbnails with 3D text strokes and social presets',
    category: 'IMAGE & THUMBNAIL',
    description: 'Dedicated canvas graphic studio tailored for YouTube (16:9), Shorts/TikTok (9:16), and Instagram with high-contrast text and photo upload.',
    iconName: 'Image',
    subtools: ['16:9 & 9:16 Presets', '3D Text Strokes', 'Glow & Shadow', 'Sticker Badges', 'PNG/WebP Export']
  },
  {
    id: 'social-repurpose',
    name: 'Social Media Repurposer',
    tagline: 'One master video adapted for Shorts, TikTok, Reels with safe-zone guides',
    category: 'SHORTS & SOCIAL',
    description: 'Simulates native platform UI overlays for TikTok, Instagram Reels, and YouTube Shorts to ensure captions and faces are never obscured by buttons.',
    iconName: 'Share2',
    subtools: ['TikTok Safe Zone', 'Reels Safe Zone', 'Shorts Safe Zone', 'Platform Presets']
  },
  {
    id: 'gif-media',
    name: 'GIF & Short Media Suite',
    tagline: 'Video to animated GIF, GIF to video, and slideshow montage creator',
    category: 'GIF & MEDIA',
    description: 'Create lightweight looping animated GIFs with custom FPS, speed ramp, and palette compression.',
    iconName: 'Layers',
    subtools: ['Video to GIF', 'GIF to Video', 'Framerate Limiter', 'Loop Optimizer']
  },
  {
    id: 'converter',
    name: 'Universal Media Converter',
    tagline: 'Transcode MP4, WebM, MOV, AVI, MKV, MP3, WAV, AAC, and OGG',
    category: 'CONVERTERS',
    description: 'High-performance media transcoding with bitrate, resolution, FPS, and audio codec selection.',
    iconName: 'RefreshCw',
    subtools: ['Video Transcoder', 'Audio Transcoder', 'Codec Selector', 'Bitrate Control']
  },
  {
    id: 'compressor',
    name: 'Smart Media Compressor',
    tagline: 'Shrink video and audio file sizes by up to 85% with estimated size indicator',
    category: 'COMPRESSORS',
    description: 'Target specific file sizes for Discord (8MB), email, WhatsApp, or web without perceptual degradation.',
    iconName: 'Minimize2',
    subtools: ['Target File Size (MB)', 'Quality Presets', 'Discord Preset (8MB)', 'Live Size Estimator']
  },
  {
    id: 'resizer',
    name: 'Aspect Ratio & Social Resizer',
    tagline: 'Reframe for YouTube (16:9), Shorts (9:16), Instagram (1:1, 4:5)',
    category: 'VIDEO',
    description: 'Intelligent reframing with blurred ambient background fill, black bars, or center-weighted crop.',
    iconName: 'Maximize2',
    subtools: ['Ambient Blur Padding', 'Crop to Fill', 'Black Bars', 'Custom Dimensions']
  }
];

export const CARTOON_STYLES: CartoonStyleConfig[] = [
  {
    id: '2d-cartoon',
    name: '2D Cartoon',
    description: 'Classic Saturday morning cartoon style with clean black ink contours and vibrant flat color fill.',
    edgeStrength: 75,
    edgeThreshold: 80,
    colorBands: 7,
    saturation: 140,
    contrast: 130,
    brightness: 5,
    smoothness: 3,
    styleStrength: 85,
    consistency: 90,
    detailLevel: 75,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: '3d-cartoon',
    name: '3D Cartoon',
    description: 'Soft rounded digital character look with volumetric shading, specular highlights, and clean edges.',
    edgeStrength: 35,
    edgeThreshold: 110,
    colorBands: 16,
    saturation: 125,
    contrast: 115,
    brightness: 8,
    smoothness: 4,
    bloom: 20,
    styleStrength: 80,
    consistency: 92,
    detailLevel: 80,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'anime',
    name: 'Anime & Manga',
    description: 'Japanese animation cel-shading aesthetic with fine ink linework, high saturation, and crisp light steps.',
    edgeStrength: 85,
    edgeThreshold: 65,
    colorBands: 6,
    saturation: 150,
    contrast: 140,
    brightness: 10,
    smoothness: 3,
    styleStrength: 90,
    consistency: 88,
    detailLevel: 85,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'comic-book',
    name: 'Comic Book',
    description: 'Graphic novel aesthetic featuring heavy black outlines, high contrast shadows, and Ben-Day dot halftone.',
    edgeStrength: 95,
    edgeThreshold: 50,
    colorBands: 5,
    saturation: 160,
    contrast: 165,
    brightness: -5,
    smoothness: 2,
    grain: 35,
    styleStrength: 95,
    consistency: 85,
    detailLevel: 70,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'watercolor',
    name: 'Watercolor Painting',
    description: 'Soft artistic pigment bleeding with textured paper edge darkening and subtle organic color blending.',
    edgeStrength: 30,
    edgeThreshold: 120,
    colorBands: 12,
    saturation: 115,
    contrast: 95,
    brightness: 12,
    smoothness: 5,
    grain: 20,
    styleStrength: 75,
    consistency: 80,
    detailLevel: 65,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'hand-drawn',
    name: 'Hand Drawn Sketch',
    description: 'Cross-hatch pencil drawing with dynamic sketched lines, graphite textures, and paper grain.',
    edgeStrength: 90,
    edgeThreshold: 60,
    colorBands: 4,
    saturation: 25,
    contrast: 150,
    brightness: 5,
    smoothness: 2,
    grain: 40,
    styleStrength: 88,
    consistency: 82,
    detailLevel: 75,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'pixar-inspired',
    name: 'Pixar-Inspired 3D',
    description: 'Warm cinematic studio look with rich subsurface lighting, gentle gradient ambient occlusion, and vibrant colors.',
    edgeStrength: 25,
    edgeThreshold: 130,
    colorBands: 20,
    saturation: 130,
    contrast: 110,
    brightness: 6,
    smoothness: 4,
    bloom: 25,
    warmth: 15,
    styleStrength: 85,
    consistency: 94,
    detailLevel: 88,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'claymation',
    name: 'Clay / Stop Motion',
    description: 'Chunky tactile claymation surface with matte clay posterization and authentic 12 FPS stop-motion timing.',
    edgeStrength: 60,
    edgeThreshold: 90,
    colorBands: 8,
    saturation: 120,
    contrast: 125,
    brightness: 0,
    smoothness: 3,
    fpsLimit: 12,
    grain: 15,
    styleStrength: 92,
    consistency: 95,
    detailLevel: 78,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'sketch',
    name: 'Fine Pencil Sketch',
    description: 'Monochromatic architectural charcoal and graphite line art on crisp sketchpad paper.',
    edgeStrength: 100,
    edgeThreshold: 45,
    colorBands: 3,
    saturation: 0,
    contrast: 175,
    brightness: 10,
    smoothness: 1,
    styleStrength: 95,
    consistency: 88,
    detailLevel: 90,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'ink',
    name: 'Traditional Ink Wash',
    description: 'Sumie-inspired fluid black ink strokes with expressive calligraphic contour gradients.',
    edgeStrength: 92,
    edgeThreshold: 55,
    colorBands: 4,
    saturation: 15,
    contrast: 160,
    brightness: 8,
    smoothness: 2,
    styleStrength: 85,
    consistency: 86,
    detailLevel: 80,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'storybook',
    name: 'Children Storybook',
    description: 'Whimsical textured fairytale illustrations with soft gouache painting and warm ambient glow.',
    edgeStrength: 45,
    edgeThreshold: 95,
    colorBands: 10,
    saturation: 145,
    contrast: 110,
    brightness: 14,
    smoothness: 4,
    bloom: 20,
    warmth: 15,
    styleStrength: 82,
    consistency: 90,
    detailLevel: 75,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'cinematic-animation',
    name: 'Cinematic Animation',
    description: 'Dramatic teal-and-orange feature film palette, anamorphic depth of field, and film grain.',
    edgeStrength: 45,
    edgeThreshold: 95,
    colorBands: 14,
    saturation: 135,
    contrast: 135,
    brightness: -2,
    smoothness: 3,
    bloom: 30,
    grain: 25,
    styleStrength: 85,
    consistency: 92,
    detailLevel: 85,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'kids-cartoon',
    name: 'Kids Cartoon',
    description: 'Bright cheerful primary colors with rounded thick contours and playful friendly tones.',
    edgeStrength: 70,
    edgeThreshold: 85,
    colorBands: 7,
    saturation: 170,
    contrast: 125,
    brightness: 14,
    smoothness: 4,
    styleStrength: 88,
    consistency: 90,
    detailLevel: 70,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'chibi',
    name: 'Chibi Kawaii',
    description: 'Cute pastel palette with soft bloom, lightened shadows, and dreamy warm tones.',
    edgeStrength: 40,
    edgeThreshold: 100,
    colorBands: 9,
    saturation: 135,
    contrast: 105,
    brightness: 18,
    smoothness: 4,
    bloom: 35,
    warmth: 10,
    styleStrength: 80,
    consistency: 88,
    detailLevel: 72,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'retro-cartoon',
    name: 'Retro 1930s Cartoon',
    description: 'Vintage rubber-hose aesthetic with aged sepia toning, vignette flicker, and CRT curvature.',
    edgeStrength: 85,
    edgeThreshold: 70,
    colorBands: 4,
    saturation: 20,
    contrast: 160,
    brightness: -5,
    smoothness: 2,
    fpsLimit: 15,
    grain: 45,
    styleStrength: 95,
    consistency: 85,
    detailLevel: 65,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'cyberpunk-animation',
    name: 'Cyberpunk Animation',
    description: 'Electric neon edge luminescence, cyan-magenta chromatic aberration, and high tech dark contrasts.',
    edgeStrength: 90,
    edgeThreshold: 60,
    colorBands: 8,
    saturation: 180,
    contrast: 155,
    brightness: -8,
    smoothness: 2,
    bloom: 50,
    styleStrength: 92,
    consistency: 87,
    detailLevel: 82,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'fantasy-animation',
    name: 'Fantasy Animation',
    description: 'Ethereal fairytale aesthetic with mystical golden aura, glowing highlights, and enchanted depth.',
    edgeStrength: 40,
    edgeThreshold: 105,
    colorBands: 12,
    saturation: 145,
    contrast: 120,
    brightness: 8,
    smoothness: 4,
    bloom: 40,
    warmth: 20,
    styleStrength: 85,
    consistency: 90,
    detailLevel: 80,
    facePreservation: true,
    motionPreservation: true
  },
  {
    id: 'custom',
    name: 'Custom Parameter Style',
    description: 'Complete creative control over all edges, color quantization, contrast, grain, bloom, and FPS limits.',
    edgeStrength: 60,
    edgeThreshold: 80,
    colorBands: 8,
    saturation: 125,
    contrast: 120,
    brightness: 0,
    smoothness: 3,
    styleStrength: 80,
    consistency: 85,
    detailLevel: 75,
    facePreservation: true,
    motionPreservation: true
  }
];

export const SUBTITLE_STYLES: SubtitleStylePreset[] = [
  {
    id: 'hormozi',
    name: 'Viral Bold (Hormozi)',
    fontFamily: 'Cabinet Grotesk',
    fontSize: 48,
    textColor: '#FFFFFF',
    highlightColor: '#FACC15',
    strokeColor: '#000000',
    strokeWidth: 4,
    textTransform: 'uppercase',
    positionY: 76
  },
  {
    id: 'karaoke',
    name: 'Dynamic Karaoke',
    fontFamily: 'Plus Jakarta Sans',
    fontSize: 44,
    textColor: '#94A3B8',
    highlightColor: '#38BDF8',
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    textTransform: 'none',
    positionY: 80
  },
  {
    id: 'cinematic',
    name: 'Cinematic Minimal',
    fontFamily: 'Plus Jakarta Sans',
    fontSize: 36,
    textColor: '#F8FAFC',
    highlightColor: '#E2E8F0',
    strokeColor: 'rgba(0,0,0,0.85)',
    strokeWidth: 2,
    textTransform: 'none',
    positionY: 86
  },
  {
    id: 'cyber',
    name: 'Neon Cyberpunk',
    fontFamily: 'JetBrains Mono',
    fontSize: 42,
    textColor: '#38BDF8',
    highlightColor: '#F43F5E',
    backgroundColor: 'rgba(15, 23, 42, 0.9)',
    textTransform: 'uppercase',
    positionY: 78
  },
  {
    id: 'minimal',
    name: 'Modern Minimalist',
    fontFamily: 'Plus Jakarta Sans',
    fontSize: 36,
    textColor: '#F8FAFC',
    highlightColor: '#818CF8',
    textTransform: 'none',
    positionY: 82
  },
  {
    id: 'netflix',
    name: 'Cinema Classic',
    fontFamily: 'Plus Jakarta Sans',
    fontSize: 38,
    textColor: '#FFFFFF',
    highlightColor: '#E2E8F0',
    strokeColor: 'rgba(0,0,0,0.8)',
    strokeWidth: 2,
    textTransform: 'none',
    positionY: 84
  },
  {
    id: 'boxed',
    name: 'Boxed Badge',
    fontFamily: 'Cabinet Grotesk',
    fontSize: 40,
    textColor: '#090D16',
    highlightColor: '#4F46E5',
    backgroundColor: '#FFFFFF',
    textTransform: 'uppercase',
    positionY: 74
  },
  {
    id: 'shadow',
    name: 'Floating Shadow',
    fontFamily: 'Cabinet Grotesk',
    fontSize: 44,
    textColor: '#F1F5F9',
    highlightColor: '#34D399',
    strokeColor: '#0F172A',
    strokeWidth: 3,
    textTransform: 'uppercase',
    positionY: 75
  }
];

export const AI_CONTENT_TOOLS: AIContentToolMeta[] = [
  {
    id: 'script-generator',
    name: 'Full Video Script Writer',
    category: 'Video Scripts',
    description: 'Generates comprehensive video scripts structured with Hook, Introduction, Core Value, and Strong Call-to-Action.',
    promptTemplate: 'Write a high-converting, engaging video script on the topic "{topic}". Target audience: "{audience}". Desired length: "{duration}". Tone: "{tone}". Include visual staging cues in brackets [like this] and speaker lines.',
    inputs: [
      { name: 'topic', label: 'Video Topic or Core Idea', type: 'text', placeholder: 'e.g. 5 AI tools that will save you 10 hours a week' },
      { name: 'audience', label: 'Target Audience', type: 'text', placeholder: 'e.g. Freelancers, digital creators, small business owners' },
      { name: 'duration', label: 'Desired Length', type: 'select', options: ['30 seconds (Shorts/TikTok)', '60 seconds', '3 minutes', '5-8 minutes YouTube video'] },
      { name: 'tone', label: 'Tone of Voice', type: 'select', options: ['Engaging & Energetic', 'Professional & Authoritative', 'Casual & Relatable', 'Humorous & Punchy'] }
    ]
  },
  {
    id: 'video-hook-generator',
    name: 'First 3-Second Viral Hook Crafter',
    category: 'Hooks & Titles',
    description: 'Generates 7 psychological scroll-stopping hooks designed to prevent viewers from swiping away in the first 3 seconds.',
    promptTemplate: 'Generate 7 powerful first-3-seconds hooks for a video about "{topic}". Provide hooks categorized by psychological angle: Curiosity Gap, Contrarian/Controversial, Immediate Value, Pain Point, and Story Starter. Format clearly with brief rationale.',
    inputs: [
      { name: 'topic', label: 'What is your video about?', type: 'textarea', placeholder: 'e.g. Why most people fail when trying to build habits and what actually works.' }
    ]
  },
  {
    id: 'title-generator',
    name: 'High-CTR Title & Headline Generator',
    category: 'Hooks & Titles',
    description: 'Produces 10 YouTube and social media headlines optimized for high click-through rates and curiosity without misleading clickbait.',
    promptTemplate: 'Create 10 high-CTR video titles for "{topic}". Style: "{style}". Keep each title punchy (under 60 characters). Provide emotional trigger breakdown for each.',
    inputs: [
      { name: 'topic', label: 'Video Subject', type: 'text', placeholder: 'e.g. Complete Beginner Guide to Video Editing in 2026' },
      { name: 'style', label: 'Title Flavor', type: 'select', options: ['Curiosity & Mystery', 'How-To & Educational', 'Direct & Bold', 'Listicle / Numbers', 'Transformation / Before-After'] }
    ]
  },
  {
    id: 'youtube-shorts-script',
    name: 'YouTube Shorts Script Engine',
    category: 'Video Scripts',
    description: 'Bite-sized, hyper-paced 45-60s vertical script with fast scene transitions and built-in re-watch loop hooks.',
    promptTemplate: 'Write an optimized 60-second YouTube Shorts script on "{topic}". Must include an inescapable hook, seamless loop sentence at the end that connects back to the beginning, and on-screen text instructions.',
    inputs: [
      { name: 'topic', label: 'Shorts Subject', type: 'text', placeholder: 'e.g. The secret psychology behind Apple retail stores' }
    ]
  },
  {
    id: 'tiktok-script',
    name: 'TikTok Video Script Engine',
    category: 'Video Scripts',
    description: 'Fast-paced, high-relatability script written in natural, conversational vernacular with trending format structures.',
    promptTemplate: 'Create a viral TikTok video script for "{topic}". Tone must be native TikTok style (conversational, dynamic pacing, punchy lines). Include audio sound effect suggestions.',
    inputs: [
      { name: 'topic', label: 'Topic or Product', type: 'text', placeholder: 'e.g. The weirdest productivity trick that actually doubled my focus' }
    ]
  },
  {
    id: 'reels-script',
    name: 'Instagram Reels Script Engine',
    category: 'Video Scripts',
    description: 'Aesthetic, punchy script with visual text hooks and high save/share viral triggers.',
    promptTemplate: 'Write an Instagram Reels script for "{topic}". Focus on shareability and saves. Include 3 text-on-screen bullet highlights and a clean closing question to prompt comments.',
    inputs: [
      { name: 'topic', label: 'Reel Topic', type: 'text', placeholder: 'e.g. 3 travel hacks flight attendants will never tell you' }
    ]
  },
  {
    id: 'description-generator',
    name: 'SEO Description & Show Notes',
    category: 'YouTube & SEO',
    description: 'SEO-rich video descriptions with timestamps, key takeaways, links placeholders, and search keywords.',
    promptTemplate: 'Write an SEO-optimized video description and show notes for a video titled "{title}". Summary of content: "{summary}". Include 3-sentence summary, timestamp placeholders, 5 key takeaways, and relevant keywords naturally woven in.',
    inputs: [
      { name: 'title', label: 'Video Title', type: 'text', placeholder: 'e.g. How to Build an AI App from Scratch' },
      { name: 'summary', label: 'Key points covered in video', type: 'textarea', placeholder: 'e.g. Discussing system architecture, choosing Gemini API, deploying full-stack.' }
    ]
  },
  {
    id: 'hashtag-generator',
    name: 'Trending Hashtags & Tags Suite',
    category: 'Social Repurposing',
    description: 'Generates 3 tiers of hashtags: high-volume reach, niche community, and specific topic tags.',
    promptTemplate: 'Provide 25 hashtags for "{topic}" on "{platform}". Categorize into: Broad/High Volume (1M+ posts), Medium Niche (100k-500k), and Ultra-Specific community tags. No generic spam tags.',
    inputs: [
      { name: 'topic', label: 'Niche / Topic', type: 'text', placeholder: 'e.g. AI video editing tools' },
      { name: 'platform', label: 'Platform', type: 'select', options: ['Instagram Reels', 'TikTok', 'YouTube Shorts', 'LinkedIn Video', 'X (Twitter)'] }
    ]
  },
  {
    id: 'caption-generator',
    name: 'Social Media Caption Crafter',
    category: 'Copywriting',
    description: 'Engaging, clean text captions formatted with line breaks, emojis, and comment-generating questions.',
    promptTemplate: 'Write 3 social media captions for a video about "{topic}". Option 1: Story-driven. Option 2: Bullet-pointed tips. Option 3: Short and punchy. Include call-to-actions to comment.',
    inputs: [
      { name: 'topic', label: 'What is your post about?', type: 'text', placeholder: 'e.g. The exact routine that helped me stop procrastinating' }
    ]
  },
  {
    id: 'content-ideas-generator',
    name: '30-Day Content Calendar & Ideas',
    category: 'Hooks & Titles',
    description: 'Generates 15 high-performing video concepts with unique angles for your specific creator niche.',
    promptTemplate: 'Generate 15 creative, high-engagement video ideas for a creator in the "{niche}" niche. For each idea provide: Concept Title, Why it works, and Target format (Shorts vs Long-form).',
    inputs: [
      { name: 'niche', label: 'Your Channel / Creator Niche', type: 'text', placeholder: 'e.g. Personal finance for college graduates and 20-somethings' }
    ]
  },
  {
    id: 'blog-outline-generator',
    name: 'Repurpose Video into Blog / Article',
    category: 'Social Repurposing',
    description: 'Transforms video concepts and transcripts into a structured, publication-ready article outline.',
    promptTemplate: 'Convert the following video topic or transcript into a comprehensive, SEO-friendly blog article outline: "{transcript}". Include H2/H3 headers, bullet summaries for each section, and meta description.',
    inputs: [
      { name: 'transcript', label: 'Video Transcript or Notes', type: 'textarea', placeholder: 'Paste transcript or core notes here...' }
    ]
  },
  {
    id: 'rewrite-paraphrase',
    name: 'Smart Paraphraser & Tone Shifter',
    category: 'Copywriting',
    description: 'Rewrites and sharpens sentences into punchier, more engaging creator language without fluff.',
    promptTemplate: 'Rewrite the following text to make it "{style}". Eliminate passive voice, enhance flow, and keep it crisp: "{text}"',
    inputs: [
      { name: 'text', label: 'Original Text', type: 'textarea', placeholder: 'Paste text to rewrite...' },
      { name: 'style', label: 'Target Style', type: 'select', options: ['Punchy & Dynamic', 'Professional & Polished', 'Conversational & Friendly', 'Bold & Persuasive'] }
    ]
  },
  {
    id: 'summarizer-cleaner',
    name: 'Transcript Summarizer & Filler Cleaner',
    category: 'Copywriting',
    description: 'Cleans up raw speech transcripts by removing "um", "uh", stutters, and summarizing key insights.',
    promptTemplate: 'Clean the following transcript by removing filler words (um, uh, like, you know), fix grammatical run-ons, and provide a 3-bullet summary of key insights: "{transcript}"',
    inputs: [
      { name: 'transcript', label: 'Raw Spoken Transcript', type: 'textarea', placeholder: 'Paste spoken speech or interview transcript...' }
    ]
  },
  {
    id: 'cta-generator',
    name: 'High-Conversion Call-To-Action (CTA)',
    category: 'Hooks & Titles',
    description: 'Designs 6 tailored end-screen calls to action for newsletter signups, downloads, subscriptions, and follows.',
    promptTemplate: 'Create 6 compelling end-of-video CTAs for "{goal}". Target viewer state: engaged and finished watching video. Formulate 2 for verbal delivery, 2 for on-screen text overlays, and 2 for pinned comments.',
    inputs: [
      { name: 'goal', label: 'What do you want viewers to do?', type: 'text', placeholder: 'e.g. Subscribe to channel, visit website, grab free template' }
    ]
  },
  {
    id: 'thumbnail-text-ideas',
    name: 'Thumb-Stopping 3-Word Thumbnail Texts',
    category: 'Hooks & Titles',
    description: 'Generates ultra-short, high-contrast 2 to 4 word phrases designed to complement (not repeat) your video title.',
    promptTemplate: 'Generate 12 punchy, 2-to-4 word phrases to put directly on a YouTube thumbnail for a video titled "{title}". The thumbnail text must NOT repeat the title, but add curiosity or emotional punch.',
    inputs: [
      { name: 'title', label: 'Video Title', type: 'text', placeholder: 'e.g. I Tested 10 Productivity Apps for 30 Days' }
    ]
  },
  {
    id: 'prompt-generator',
    name: 'AI Video Prompt Engineer',
    category: 'Video Scripts',
    description: 'Crafts detailed, cinematic text-to-video and style prompts with camera angles, lighting, and movement cues.',
    promptTemplate: 'Craft 3 ultra-detailed, cinematic text prompts for an AI video generation model (like Veo) for the concept: "{concept}". Include lighting type (e.g. rim lighting, golden hour), camera motion (e.g. slow dolly forward, anamorphic lens), frame rate, and atmosphere details.',
    inputs: [
      { name: 'concept', label: 'Scene Concept', type: 'text', placeholder: 'e.g. A cybernetic explorer discovering an ancient glowing temple in a rainy jungle' }
    ]
  },
  {
    id: 'chapter-generator',
    name: 'YouTube Chapter & Timestamp Generator',
    category: 'YouTube & SEO',
    description: 'Breaks long video notes or transcripts into clickable YouTube chapters with timestamps.',
    promptTemplate: 'Create clickable YouTube timestamps and chapters for this video content: "{transcript}". Format as "00:00 - Chapter Title", keeping titles concise and search-friendly.',
    inputs: [
      { name: 'transcript', label: 'Video Transcript or Notes', type: 'textarea', placeholder: 'Paste transcript...' }
    ]
  }
];

export const DEFAULT_PRICING_PLANS: PricingPlan[] = [
  {
    id: 'free',
    name: 'Starter Free',
    tagline: 'All core AI studio features unlocked for everyone with zero setup fee',
    priceMonthly: 0,
    priceYearly: 0,
    enabled: true,
    features: [
      'Real Video-to-Cartoon transformation (all 18 styles)',
      'Viral Shorts Maker with 9:16 auto-reframing',
      'AI Caption & Subtitle generator with SRT/VTT export',
      'Multilingual Translation & Dubbing in 45+ languages',
      'Multi-track timeline video editor',
      'Complete Audio Suite with Vocal Remover',
      '40+ AI Content & Script Generation engines',
      'Client-side video enhancer, compressor, and converter',
      'Standard 720p & 1080p WebM/MP4 export'
    ],
    limits: {
      exportsPerDay: 25,
      maxResolution: '1080p',
      maxDurationMinutes: 15,
      aiCreditsPerMonth: 150,
      watermark: false,
      priorityProcessing: false
    }
  },
  {
    id: 'pro',
    name: 'Creator Pro',
    tagline: 'For active YouTube and social media creators producing weekly content',
    priceMonthly: 19,
    priceYearly: 190,
    enabled: true,
    isPopular: true,
    features: [
      'Everything in Starter Free',
      'High-speed priority queue',
      'Batch Shorts extraction (up to 10 clips per upload)',
      'Full 1080p & 2K resolution export where hardware supports',
      'Extended video duration up to 30 minutes',
      'Custom subtitle typography and saved brand presets',
      'Unlimited AI script and hook generation'
    ],
    limits: {
      exportsPerDay: 100,
      maxResolution: '2K',
      maxDurationMinutes: 30,
      aiCreditsPerMonth: 500,
      watermark: false,
      priorityProcessing: true
    }
  },
  {
    id: 'premium',
    name: 'Studio Premium',
    tagline: 'For digital agencies, video editors, and full-time creative teams',
    priceMonthly: 49,
    priceYearly: 490,
    enabled: true,
    features: [
      'Everything in Creator Pro',
      'Unlimited video exports & processing',
      'Full 4K export pipeline support',
      'Extended video duration up to 120 minutes',
      'Multi-speaker podcast transcription & cleanup',
      'Custom style shader tuning & preset saving',
      'Direct API webhook integration options'
    ],
    limits: {
      exportsPerDay: 500,
      maxResolution: '4K',
      maxDurationMinutes: 120,
      aiCreditsPerMonth: 2000,
      watermark: false,
      priorityProcessing: true
    }
  },
  {
    id: 'business',
    name: 'Enterprise Business',
    tagline: 'Dedicated infrastructure, custom SLA, and team collaboration',
    priceMonthly: 149,
    priceYearly: 1490,
    enabled: true,
    features: [
      'Everything in Studio Premium',
      'Dedicated GPU rendering server endpoints',
      'Unlimited team members with role-based permissions',
      'Custom AI voice and cartoon style fine-tuning',
      'Dedicated account manager and 24/7 priority support',
      'Enterprise SLA & custom data retention rules'
    ],
    limits: {
      exportsPerDay: 5000,
      maxResolution: '4K',
      maxDurationMinutes: 240,
      aiCreditsPerMonth: 10000,
      watermark: false,
      priorityProcessing: true
    }
  }
];

export const DEFAULT_ADMIN_CONFIG: AdminSiteConfig = {
  siteName: 'CineMorph Studio',
  tagline: 'AI Video Transformation, Viral Shorts & Creative Suite',
  logoText: 'CineMorph',
  accentColor: '#6366F1',
  supportEmail: 'muhammadofficial356@gmail.com',
  supportWhatsApp: '+923199389323',
  maintenanceMode: false,
  announcement: {
    show: true,
    message: '✨ CineMorph Studio is fully unlocked! All 15 Video, Audio, and AI Engines are free for creators.',
    type: 'info'
  },
  toolSettings: {},
  plans: DEFAULT_PRICING_PLANS,
  seo: {
    siteTitle: 'CineMorph Studio – AI Video Transformation & Viral Shorts Suite',
    metaDescription: 'Transform real videos into anime and 3D cartoon styles, create viral 9:16 Shorts with smart captions, dub into 45+ languages, and generate video scripts with AI.',
    keywords: 'AI video to cartoon, viral shorts maker, AI video editor, anime video filter, video captions generator, video compressor, video enhancer, video dubbing AI',
    canonicalUrl: 'https://cinemorph.studio',
    ogImageUrl: 'https://cinemorph.studio/og-banner.jpg'
  },
  analytics: {
    ga4MeasurementId: '',
    googleSearchConsoleCode: '',
    adsensePublisherId: '',
    enableAdSensePlaceholders: false
  }
};
