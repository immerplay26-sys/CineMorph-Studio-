import { CartoonStyleConfig } from '../types';

export class VideoProcessingEngine {
  private videoEl: HTMLVideoElement | null = null;
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private animationFrameId: number | null = null;
  private lastRenderTime: number = 0;
  private mediaRecorder: MediaRecorder | null = null;
  private recordedChunks: Blob[] = [];
  private audioCtx: AudioContext | null = null;
  private audioSourceNode: MediaElementAudioSourceNode | null = null;
  private audioDestNode: MediaStreamAudioDestinationNode | null = null;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const context = canvas.getContext('2d', { willReadFrequently: true });
    if (!context) {
      throw new Error('Canvas 2D context with willReadFrequently is not supported.');
    }
    this.ctx = context;
  }

  public attachVideo(video: HTMLVideoElement) {
    this.videoEl = video;
    if (video.videoWidth > 0 && video.videoHeight > 0) {
      this.canvas.width = video.videoWidth;
      this.canvas.height = video.videoHeight;
    }
  }

  public renderSingleFrame(
    style: CartoonStyleConfig,
    splitRatio: number | null = null, // e.g. 0.5 for 50% split comparison
    videoElOverride?: HTMLVideoElement
  ) {
    const video = videoElOverride || this.videoEl;
    if (!video || video.readyState < 2) return;

    const width = video.videoWidth || 640;
    const height = video.videoHeight || 360;

    if (this.canvas.width !== width || this.canvas.height !== height) {
      this.canvas.width = width;
      this.canvas.height = height;
    }

    // Draw video frame to canvas
    this.ctx.drawImage(video, 0, 0, width, height);

    // If split comparison: save original image data for split left side
    let originalData: ImageData | null = null;
    if (splitRatio !== null && splitRatio > 0 && splitRatio < 1) {
      originalData = this.ctx.getImageData(0, 0, width, height);
    }

    // Apply the real artistic transformation
    const frameData = this.ctx.getImageData(0, 0, width, height);
    this.applyArtisticTransform(frameData, style, width, height);
    this.ctx.putImageData(frameData, 0, 0);

    // If split comparison is active, re-draw original on the left side
    if (splitRatio !== null && splitRatio > 0 && splitRatio < 1 && originalData) {
      const splitX = Math.floor(width * splitRatio);
      this.ctx.putImageData(originalData, 0, 0, 0, 0, splitX, height);

      // Draw subtle dividing line
      this.ctx.strokeStyle = '#FFFFFF';
      this.ctx.lineWidth = 2;
      this.ctx.shadowColor = 'rgba(0,0,0,0.8)';
      this.ctx.shadowBlur = 6;
      this.ctx.beginPath();
      this.ctx.moveTo(splitX, 0);
      this.ctx.lineTo(splitX, height);
      this.ctx.stroke();
      this.ctx.shadowBlur = 0;
    }
  }

  public startLivePreview(
    getStyle: () => CartoonStyleConfig,
    getSplitRatio: () => number | null
  ) {
    this.stopLivePreview();

    const loop = (timestamp: number) => {
      const style = getStyle();
      const splitRatio = getSplitRatio();

      // Check FPS limitation (e.g. 12fps for claymation)
      const targetFps = style.fpsLimit || 60;
      const interval = 1000 / targetFps;

      if (timestamp - this.lastRenderTime >= interval) {
        this.renderSingleFrame(style, splitRatio);
        this.lastRenderTime = timestamp;
      }

      this.animationFrameId = requestAnimationFrame(loop);
    };

    this.animationFrameId = requestAnimationFrame(loop);
  }

  public stopLivePreview() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  /**
   * Real pixel manipulation engine applying Edge Detection (Sobel),
   * Color Quantization, Saturation, Contrast, Halftone, and specific style heuristics.
   */
  private applyArtisticTransform(
    imageData: ImageData,
    style: CartoonStyleConfig,
    width: number,
    height: number
  ) {
    const data = imageData.data;
    const totalPixels = width * height;

    // Helper buffers
    const gray = new Uint8Array(totalPixels);
    for (let i = 0, j = 0; i < data.length; i += 4, j++) {
      // Perceived luminance
      gray[j] = Math.round(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
    }

    // Sobel edge gradient computation
    const edges = new Uint8Array(totalPixels);
    const edgeThreshold = style.edgeThreshold;

    // Convolve with 3x3 Sobel kernels
    for (let y = 1; y < height - 1; y++) {
      const yRow = y * width;
      const yPrev = (y - 1) * width;
      const yNext = (y + 1) * width;

      for (let x = 1; x < width - 1; x++) {
        const p00 = gray[yPrev + x - 1];
        const p01 = gray[yPrev + x];
        const p02 = gray[yPrev + x + 1];

        const p10 = gray[yRow + x - 1];
        const p12 = gray[yRow + x + 1];

        const p20 = gray[yNext + x - 1];
        const p21 = gray[yNext + x];
        const p22 = gray[yNext + x + 1];

        // Horizontal gradient Gx
        const gx = -p00 + p02 - 2 * p10 + 2 * p12 - p20 + p22;
        // Vertical gradient Gy
        const gy = -p00 - 2 * p01 - p02 + p20 + 2 * p21 + p22;

        const mag = Math.sqrt(gx * gx + gy * gy);
        edges[yRow + x] = mag > edgeThreshold ? Math.min(255, Math.floor(mag)) : 0;
      }
    }

    const colorBands = Math.max(2, Math.min(32, style.colorBands));
    const bandStep = 255 / (colorBands - 1);
    const contrastFactor = style.contrast / 100;
    const saturationFactor = style.saturation / 100;
    const edgeStrengthNorm = style.edgeStrength / 100;
    const warmthShift = style.warmth || 0;
    const grain = style.grain || 0;

    const isComic = style.id === 'comic-book';
    const isSketch = style.id === 'sketch';
    const isWatercolor = style.id === 'watercolor';
    const isCyberpunk = style.id === 'cyberpunk-animation';
    const isRetro = style.id === 'retro-cartoon';

    for (let y = 0; y < height; y++) {
      const yOffset = y * width;
      for (let x = 0; x < width; x++) {
        const idx = (yOffset + x) * 4;
        let r = data[idx];
        let g = data[idx + 1];
        let b = data[idx + 2];

        // 1. Color Quantization / Posterization (Cel-shading)
        r = Math.round(Math.round(r / bandStep) * bandStep);
        g = Math.round(Math.round(g / bandStep) * bandStep);
        b = Math.round(Math.round(b / bandStep) * bandStep);

        // 2. Contrast adjustment
        r = Math.min(255, Math.max(0, Math.floor(128 + (r - 128) * contrastFactor + style.brightness)));
        g = Math.min(255, Math.max(0, Math.floor(128 + (g - 128) * contrastFactor + style.brightness)));
        b = Math.min(255, Math.max(0, Math.floor(128 + (b - 128) * contrastFactor + style.brightness)));

        // 3. Saturation boost/cut
        const lum = 0.299 * r + 0.587 * g + 0.114 * b;
        r = Math.min(255, Math.max(0, Math.floor(lum + (r - lum) * saturationFactor)));
        g = Math.min(255, Math.max(0, Math.floor(lum + (g - lum) * saturationFactor)));
        b = Math.min(255, Math.max(0, Math.floor(lum + (b - lum) * saturationFactor)));

        // 4. Style-specific nuance
        if (warmthShift > 0) {
          r = Math.min(255, r + warmthShift * 0.8);
          g = Math.min(255, g + warmthShift * 0.3);
          b = Math.max(0, b - warmthShift * 0.4);
        }

        // Halftone pattern for Comic Book
        if (isComic) {
          const dotGrid = ((x % 4) === 0 && (y % 4) === 0);
          if (dotGrid && lum < 180) {
            r = Math.floor(r * 0.6);
            g = Math.floor(g * 0.6);
            b = Math.floor(b * 0.6);
          }
        }

        // Sketch style: white canvas with dark graphite strokes
        if (isSketch) {
          const edgeVal = edges[yOffset + x];
          const stroke = 255 - Math.min(255, Math.floor(edgeVal * edgeStrengthNorm * 2.2));
          r = stroke;
          g = stroke;
          b = stroke;
        } else {
          // 5. Edge overlay (Black ink or Neon Glow)
          const edgeVal = edges[yOffset + x];
          if (edgeVal > 0) {
            const edgeFactor = Math.min(1, (edgeVal / 255) * edgeStrengthNorm);
            if (isCyberpunk) {
              // Neon edge: cyan / magenta glow
              r = Math.min(255, Math.floor(r * (1 - edgeFactor) + 244 * edgeFactor));
              g = Math.min(255, Math.floor(g * (1 - edgeFactor) + 63 * edgeFactor));
              b = Math.min(255, Math.floor(b * (1 - edgeFactor) + 240 * edgeFactor));
            } else if (isWatercolor) {
              // Softer watercolor pigment contour
              r = Math.floor(r * (1 - edgeFactor * 0.5));
              g = Math.floor(g * (1 - edgeFactor * 0.5));
              b = Math.floor(b * (1 - edgeFactor * 0.5));
            } else {
              // Classic dark ink contour
              r = Math.floor(r * (1 - edgeFactor));
              g = Math.floor(g * (1 - edgeFactor));
              b = Math.floor(b * (1 - edgeFactor));
            }
          }
        }

        // Retro sepia shift
        if (isRetro) {
          const tr = 0.393 * r + 0.769 * g + 0.189 * b;
          const tg = 0.349 * r + 0.686 * g + 0.168 * b;
          const tb = 0.272 * r + 0.534 * g + 0.131 * b;
          r = Math.min(255, Math.floor(tr));
          g = Math.min(255, Math.floor(tg));
          b = Math.min(255, Math.floor(tb));
        }

        // Subtle organic film/paper grain
        if (grain > 0) {
          const noise = (Math.random() - 0.5) * grain;
          r = Math.min(255, Math.max(0, Math.floor(r + noise)));
          g = Math.min(255, Math.max(0, Math.floor(g + noise)));
          b = Math.min(255, Math.max(0, Math.floor(b + noise)));
        }

        data[idx] = r;
        data[idx + 1] = g;
        data[idx + 2] = b;
      }
    }
  }

  /**
   * Real video recording & export pipeline!
   * Captures the transformed canvas stream + original video audio and packages into downloadable WebM/MP4.
   */
  public async recordTransformedVideo(
    video: HTMLVideoElement,
    style: CartoonStyleConfig,
    onProgress: (percent: number, currentTime: number, totalDuration: number) => void
  ): Promise<Blob> {
    return new Promise(async (resolve, reject) => {
      try {
        this.stopLivePreview();

        const duration = video.duration || 5;
        const width = video.videoWidth || 640;
        const height = video.videoHeight || 360;

        this.canvas.width = width;
        this.canvas.height = height;

        // Set up Canvas Stream
        const targetFps = style.fpsLimit || 30;
        const canvasStream = this.canvas.captureStream(targetFps);

        // Capture audio track if supported
        try {
          if (!this.audioCtx) {
            const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
            this.audioCtx = new AudioCtx();
          }
          if (this.audioCtx.state === 'suspended') {
            await this.audioCtx.resume();
          }
          if (!this.audioSourceNode) {
            this.audioSourceNode = this.audioCtx.createMediaElementSource(video);
            this.audioDestNode = this.audioCtx.createMediaStreamDestination();
            this.audioSourceNode.connect(this.audioDestNode);
            this.audioSourceNode.connect(this.audioCtx.destination);
          }
          if (this.audioDestNode && this.audioDestNode.stream.getAudioTracks().length > 0) {
            const audioTrack = this.audioDestNode.stream.getAudioTracks()[0];
            canvasStream.addTrack(audioTrack);
          }
        } catch {
          // Audio source might already be connected or not permitted
        }

        // Determine supported mime type
        let mimeType = 'video/webm;codecs=vp9,opus';
        if (!MediaRecorder.isTypeSupported(mimeType)) {
          mimeType = 'video/webm';
        }
        if (!MediaRecorder.isTypeSupported(mimeType)) {
          mimeType = 'video/mp4';
        }

        this.recordedChunks = [];
        this.mediaRecorder = new MediaRecorder(canvasStream, {
          mimeType: MediaRecorder.isTypeSupported(mimeType) ? mimeType : undefined,
          videoBitsPerSecond: 4_500_000 // 4.5 Mbps crisp output
        });

        this.mediaRecorder.ondataavailable = (e) => {
          if (e.data && e.data.size > 0) {
            this.recordedChunks.push(e.data);
          }
        };

        this.mediaRecorder.onstop = () => {
          const finalBlob = new Blob(this.recordedChunks, {
            type: this.mediaRecorder?.mimeType || 'video/webm'
          });
          resolve(finalBlob);
        };

        this.mediaRecorder.onerror = (err) => {
          reject(err);
        };

        // Reset video to start
        video.currentTime = 0;
        await new Promise<void>((r) => {
          const onSeek = () => {
            video.removeEventListener('seeked', onSeek);
            r();
          };
          video.addEventListener('seeked', onSeek);
        });

        this.mediaRecorder.start(250); // Record chunks every 250ms

        let isEnded = false;
        const onEnded = () => {
          isEnded = true;
        };
        video.addEventListener('ended', onEnded);

        await video.play();

        const processLoop = () => {
          if (isEnded || video.ended || video.currentTime >= duration) {
            video.removeEventListener('ended', onEnded);
            video.pause();
            if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
              this.mediaRecorder.stop();
            }
            onProgress(100, duration, duration);
            return;
          }

          this.renderSingleFrame(style, null, video);
          const percent = Math.min(99, Math.floor((video.currentTime / duration) * 100));
          onProgress(percent, video.currentTime, duration);

          requestAnimationFrame(processLoop);
        };

        requestAnimationFrame(processLoop);
      } catch (err) {
        reject(err);
      }
    });
  }

  public destroy() {
    this.stopLivePreview();
    if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
      this.mediaRecorder.stop();
    }
    if (this.audioCtx) {
      this.audioCtx.close().catch(() => {});
    }
  }
}
