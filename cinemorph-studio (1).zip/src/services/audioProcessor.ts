export interface SilenceSegment {
  start: number;
  end: number;
  duration: number;
}

export class AudioProcessingEngine {
  private audioCtx: AudioContext | null = null;
  private mediaRecorder: MediaRecorder | null = null;
  private recordedAudioChunks: Blob[] = [];

  private getAudioContext(): AudioContext {
    if (!this.audioCtx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioCtx();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  /**
   * Extract audio track from video file as an AudioBuffer
   */
  public async extractAudioFromVideo(videoFile: File | Blob): Promise<AudioBuffer> {
    const arrayBuffer = await videoFile.arrayBuffer();
    const ctx = this.getAudioContext();
    return await ctx.decodeAudioData(arrayBuffer);
  }

  /**
   * Detect silences in audio (RMS energy below threshold for minSilenceDuration)
   */
  public detectSilences(
    audioBuffer: AudioBuffer,
    thresholdDb: number = -38, // dB threshold
    minSilenceDuration: number = 0.4 // minimum seconds
  ): SilenceSegment[] {
    const channelData = audioBuffer.getChannelData(0);
    const sampleRate = audioBuffer.sampleRate;
    const windowSize = Math.floor(sampleRate * 0.05); // 50ms windows
    const thresholdAmp = Math.pow(10, thresholdDb / 20);

    const silences: SilenceSegment[] = [];
    let inSilence = false;
    let silenceStart = 0;

    for (let i = 0; i < channelData.length; i += windowSize) {
      let sumSquares = 0;
      const end = Math.min(i + windowSize, channelData.length);
      for (let j = i; j < end; j++) {
        sumSquares += channelData[j] * channelData[j];
      }
      const rms = Math.sqrt(sumSquares / (end - i));

      const timeSec = i / sampleRate;

      if (rms < thresholdAmp) {
        if (!inSilence) {
          inSilence = true;
          silenceStart = timeSec;
        }
      } else {
        if (inSilence) {
          inSilence = false;
          const duration = timeSec - silenceStart;
          if (duration >= minSilenceDuration) {
            silences.push({
              start: parseFloat(silenceStart.toFixed(2)),
              end: parseFloat(timeSec.toFixed(2)),
              duration: parseFloat(duration.toFixed(2))
            });
          }
        }
      }
    }

    if (inSilence) {
      const totalTime = channelData.length / sampleRate;
      const duration = totalTime - silenceStart;
      if (duration >= minSilenceDuration) {
        silences.push({
          start: parseFloat(silenceStart.toFixed(2)),
          end: parseFloat(totalTime.toFixed(2)),
          duration: parseFloat(duration.toFixed(2))
        });
      }
    }

    return silences;
  }

  /**
   * Trim audio buffer between startTime and endTime and export as WAV Blob
   */
  public async trimAudio(
    audioBuffer: AudioBuffer,
    startTime: number,
    endTime: number
  ): Promise<Blob> {
    const sampleRate = audioBuffer.sampleRate;
    const startOffset = Math.floor(startTime * sampleRate);
    const endOffset = Math.min(Math.floor(endTime * sampleRate), audioBuffer.length);
    const frameCount = endOffset - startOffset;

    if (frameCount <= 0) {
      throw new Error('Invalid trim range: start time must be less than end time.');
    }

    const offlineCtx = new OfflineAudioContext(
      audioBuffer.numberOfChannels,
      frameCount,
      sampleRate
    );

    const trimmedBuffer = offlineCtx.createBuffer(
      audioBuffer.numberOfChannels,
      frameCount,
      sampleRate
    );

    for (let channel = 0; channel < audioBuffer.numberOfChannels; channel++) {
      const srcData = audioBuffer.getChannelData(channel);
      const destData = trimmedBuffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        destData[i] = srcData[startOffset + i];
      }
    }

    return this.audioBufferToWav(trimmedBuffer);
  }

  /**
   * Convert AudioBuffer directly to WAV standard Blob
   */
  public audioBufferToWav(buffer: AudioBuffer): Blob {
    const numOfChan = buffer.numberOfChannels;
    const length = buffer.length * numOfChan * 2 + 44;
    const out = new DataView(new ArrayBuffer(length));
    const channels: Float32Array[] = [];
    let sampleRate = buffer.sampleRate;
    let offset = 0;
    let pos = 0;

    function setUint16(data: number) {
      out.setUint16(pos, data, true);
      pos += 2;
    }

    function setUint32(data: number) {
      out.setUint32(pos, data, true);
      pos += 4;
    }

    // RIFF identifier
    setUint32(0x46464952); // "RIFF"
    setUint32(length - 8); // file length - 8
    setUint32(0x45564157); // "WAVE"

    // fmt sub-chunk
    setUint32(0x20746d66); // "fmt " chunk
    setUint32(16); // Subchunk1Size (16 for PCM)
    setUint16(1); // AudioFormat (1 = PCM)
    setUint16(numOfChan);
    setUint32(sampleRate);
    setUint32(sampleRate * 2 * numOfChan); // byte rate
    setUint16(numOfChan * 2); // block align
    setUint16(16); // bits per sample

    // data sub-chunk
    setUint32(0x61746164); // "data" chunk
    setUint32(length - pos - 4);

    for (let i = 0; i < buffer.numberOfChannels; i++) {
      channels.push(buffer.getChannelData(i));
    }

    while (pos < length) {
      for (let i = 0; i < numOfChan; i++) {
        let sample = Math.max(-1, Math.min(1, channels[i][offset]));
        sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0;
        out.setInt16(pos, sample, true);
        pos += 2;
      }
      offset++;
    }

    return new Blob([out.buffer], { type: 'audio/wav' });
  }

  /**
   * Start microphone voice recorder
   */
  public async startMicrophoneRecording(
    onDataChunk?: (blob: Blob) => void
  ): Promise<MediaStream> {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.recordedAudioChunks = [];

    let mimeType = 'audio/webm';
    if (!MediaRecorder.isTypeSupported(mimeType)) {
      mimeType = 'audio/ogg';
    }

    this.mediaRecorder = new MediaRecorder(stream, {
      mimeType: MediaRecorder.isTypeSupported(mimeType) ? mimeType : undefined
    });

    this.mediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        this.recordedAudioChunks.push(e.data);
        if (onDataChunk) onDataChunk(e.data);
      }
    };

    this.mediaRecorder.start(250);
    return stream;
  }

  /**
   * Stop microphone voice recorder and return final audio Blob
   */
  public stopMicrophoneRecording(): Promise<Blob> {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder) {
        reject(new Error('No active recording session.'));
        return;
      }

      this.mediaRecorder.onstop = () => {
        const finalBlob = new Blob(this.recordedAudioChunks, {
          type: this.mediaRecorder?.mimeType || 'audio/webm'
        });
        // Stop all mic tracks
        this.mediaRecorder?.stream.getTracks().forEach((track) => track.stop());
        this.mediaRecorder = null;
        resolve(finalBlob);
      };

      this.mediaRecorder.stop();
    });
  }
}
