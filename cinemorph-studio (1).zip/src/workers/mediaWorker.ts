// Dedicated Web Worker for off-thread pixel shaders and audio RMS calculation

self.onmessage = (e: MessageEvent) => {
  const { type, data } = e.data;

  if (type === 'APPLY_SOBEL') {
    const { pixels, width, height, edgeThreshold } = data;
    const total = width * height;
    const gray = new Uint8Array(total);

    // Compute gray
    for (let i = 0, j = 0; i < pixels.length; i += 4, j++) {
      gray[j] = Math.round(0.299 * pixels[i] + 0.587 * pixels[i + 1] + 0.114 * pixels[i + 2]);
    }

    const edges = new Uint8Array(total);
    for (let y = 1; y < height - 1; y++) {
      const yRow = y * width;
      const yPrev = (y - 1) * width;
      const yNext = (y + 1) * width;

      for (let x = 1; x < width - 1; x++) {
        const p00 = gray[yPrev + x - 1];
        const p02 = gray[yPrev + x + 1];
        const p10 = gray[yRow + x - 1];
        const p12 = gray[yRow + x + 1];
        const p20 = gray[yNext + x - 1];
        const p22 = gray[yNext + x + 1];

        const p01 = gray[yPrev + x];
        const p21 = gray[yNext + x];

        const gx = -p00 + p02 - 2 * p10 + 2 * p12 - p20 + p22;
        const gy = -p00 - 2 * p01 - p02 + p20 + 2 * p21 + p22;

        const mag = Math.sqrt(gx * gx + gy * gy);
        edges[yRow + x] = mag > edgeThreshold ? Math.min(255, Math.floor(mag)) : 0;
      }
    }

    self.postMessage({ type: 'SOBEL_COMPLETE', edges });
  } else if (type === 'SCAN_SILENCE') {
    const { channelData, sampleRate, thresholdDb = -36, minDuration = 0.4 } = data;
    const windowSize = Math.floor(sampleRate * 0.05);
    const thresholdAmp = Math.pow(10, thresholdDb / 20);

    const silences: Array<{ start: number; end: number; duration: number }> = [];
    let inSilence = false;
    let silenceStart = 0;

    for (let i = 0; i < channelData.length; i += windowSize) {
      let sum = 0;
      const end = Math.min(i + windowSize, channelData.length);
      for (let j = i; j < end; j++) {
        sum += channelData[j] * channelData[j];
      }
      const rms = Math.sqrt(sum / (end - i));
      const t = i / sampleRate;

      if (rms < thresholdAmp) {
        if (!inSilence) {
          inSilence = true;
          silenceStart = t;
        }
      } else {
        if (inSilence) {
          inSilence = false;
          const dur = t - silenceStart;
          if (dur >= minDuration) {
            silences.push({
              start: parseFloat(silenceStart.toFixed(2)),
              end: parseFloat(t.toFixed(2)),
              duration: parseFloat(dur.toFixed(2))
            });
          }
        }
      }
    }

    self.postMessage({ type: 'SILENCE_COMPLETE', silences });
  }
};
