import React, { useRef, useState, useCallback, useEffect } from 'react';
import { ChevronsLeftRight } from 'lucide-react';

interface SplitSliderProps {
  splitRatio: number;
  onChange: (ratio: number) => void;
  className?: string;
}

export const SplitSlider: React.FC<SplitSliderProps> = ({
  splitRatio,
  onChange,
  className = ''
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const updateRatioFromClientX = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const ratio = Math.max(0.05, Math.min(0.95, x / rect.width));
    onChange(ratio);
  }, [onChange]);

  const handleMouseDown = () => setIsDragging(true);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        updateRatioFromClientX(e.clientX);
      }
    };

    const handleMouseUp = () => {
      if (isDragging) setIsDragging(false);
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (isDragging && e.touches.length > 0) {
        updateRatioFromClientX(e.touches[0].clientX);
      }
    };

    const handleTouchEnd = () => {
      if (isDragging) setIsDragging(false);
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      window.addEventListener('touchmove', handleTouchMove);
      window.addEventListener('touchend', handleTouchEnd);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, [isDragging, updateRatioFromClientX]);

  return (
    <div
      ref={containerRef}
      className={`absolute inset-0 cursor-ew-resize select-none pointer-events-auto ${className}`}
      onMouseDown={handleMouseDown}
      onTouchStart={handleMouseDown}
    >
      {/* Vertical divider line */}
      <div
        className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_10px_rgba(0,0,0,0.8)] pointer-events-none"
        style={{ left: `${splitRatio * 100}%` }}
      >
        {/* Handle pill in center */}
        <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-white text-neutral-900 shadow-xl flex items-center justify-center border border-neutral-300">
          <ChevronsLeftRight className="w-4 h-4" />
        </div>

        {/* Labels */}
        <div className="absolute top-3 right-3 text-[10px] font-semibold uppercase tracking-wider bg-black/70 text-white/90 px-2 py-0.5 rounded backdrop-blur-sm pointer-events-none">
          Original
        </div>
        <div className="absolute top-3 left-3 text-[10px] font-semibold uppercase tracking-wider bg-indigo-600/90 text-white px-2 py-0.5 rounded backdrop-blur-sm pointer-events-none">
          Transformed
        </div>
      </div>
    </div>
  );
};
