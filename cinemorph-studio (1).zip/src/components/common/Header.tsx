import React from 'react';
import { useApp } from '../../context/AppContext';
import { Sun, Moon, Sparkles, Shield, FolderOpen } from 'lucide-react';

export const Header: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    openTool,
    isDark,
    toggleTheme,
    siteConfig,
    isAdminAuthenticated
  } = useApp();

  return (
    <header className="sticky top-0 z-40 w-full border-b border-neutral-200/80 dark:border-neutral-800/80 bg-white/90 dark:bg-neutral-950/90 backdrop-blur-md transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => {
            setCurrentView('home');
            window.history.pushState({}, '', '/');
          }}
          className="text-xl font-bold tracking-tight text-neutral-900 dark:text-white hover:opacity-90 transition-opacity flex items-center gap-2 shrink-0 text-left"
        >
          <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 inline-block"></span>
          <span>{siteConfig.siteName || 'CineMorph Studio'}</span>
        </button>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-neutral-600 dark:text-neutral-400">
          <button
            onClick={() => {
              setCurrentView('home');
              window.history.pushState({}, '', '/');
            }}
            className={`hover:text-neutral-900 dark:hover:text-white transition-colors whitespace-nowrap ${currentView === 'home' ? 'text-neutral-900 dark:text-white font-semibold underline underline-offset-8 decoration-indigo-500 decoration-2' : ''}`}
          >
            All Tools
          </button>
          <button
            onClick={() => openTool('cartoon')}
            className={`hover:text-neutral-900 dark:hover:text-white transition-colors whitespace-nowrap ${currentView === 'tool' ? 'text-neutral-900 dark:text-white font-semibold underline underline-offset-8 decoration-indigo-500 decoration-2' : ''}`}
          >
            Cartoon Studio
          </button>
          <button
            onClick={() => openTool('viral-shorts')}
            className="hover:text-neutral-900 dark:hover:text-white transition-colors whitespace-nowrap"
          >
            Viral Shorts
          </button>
          <button
            onClick={() => openTool('content')}
            className="hover:text-neutral-900 dark:hover:text-white transition-colors whitespace-nowrap"
          >
            AI Scripts
          </button>
          <button
            onClick={() => {
              setCurrentView('pricing');
              window.history.pushState({}, '', '/?page=pricing');
            }}
            className={`hover:text-neutral-900 dark:hover:text-white transition-colors whitespace-nowrap ${currentView === 'pricing' ? 'text-neutral-900 dark:text-white font-semibold underline underline-offset-8 decoration-indigo-500 decoration-2' : ''}`}
          >
            Pricing
          </button>
          <button
            onClick={() => {
              setCurrentView('projects');
              window.history.pushState({}, '', '/?view=projects');
            }}
            className={`hover:text-neutral-900 dark:hover:text-white transition-colors whitespace-nowrap flex items-center gap-1.5 ${currentView === 'projects' ? 'text-neutral-900 dark:text-white font-semibold underline underline-offset-8 decoration-indigo-500 decoration-2' : ''}`}
          >
            <FolderOpen className="w-4 h-4" />
            <span>My Projects</span>
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={toggleTheme}
            aria-label="Toggle visual theme"
            className="p-2 text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white transition-colors rounded-lg border border-transparent hover:border-neutral-200 dark:hover:border-neutral-800"
          >
            {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {isAdminAuthenticated ? (
            <button
              onClick={() => setCurrentView('admin')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-amber-300 bg-amber-950/60 border border-amber-800/60 rounded-lg hover:bg-amber-900/60 transition-colors whitespace-nowrap"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin Console</span>
            </button>
          ) : (
            <a
              href="/admin-login.html"
              className="hidden sm:inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white transition-colors rounded-lg"
              title="Admin Portal"
            >
              <Shield className="w-3.5 h-3.5" />
            </a>
          )}

          <button
            onClick={() => openTool('cartoon')}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 rounded-lg transition-colors shadow-sm whitespace-nowrap"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Launch Studio</span>
          </button>
        </div>
      </div>
    </header>
  );
};
