import React from 'react';
import { useApp } from '../../context/AppContext';
import { Mail, Phone, ExternalLink } from 'lucide-react';

export const Footer: React.FC = () => {
  const { openTool, openLegalPage, siteConfig } = useApp();

  return (
    <footer className="w-full border-t border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 text-neutral-600 dark:text-neutral-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Col 1: Brand & Contact Info */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
              {siteConfig.siteName || 'CineMorph Studio'}
            </h4>
            <p className="leading-relaxed text-neutral-500 dark:text-neutral-400">
              Professional all-in-one AI video transformation, viral clip creation, audio mastering, and creative production studio.
            </p>
            <div className="pt-2 space-y-1.5">
              <a
                href={`https://wa.me/923199389323`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 hover:text-indigo-500 transition-colors"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>WhatsApp: +923199389323</span>
              </a>
              <a
                href={`mailto:${siteConfig.supportEmail || 'muhammadofficial356@gmail.com'}`}
                className="flex items-center gap-2 hover:text-indigo-500 transition-colors"
              >
                <Mail className="w-3.5 h-3.5" />
                <span>{siteConfig.supportEmail || 'muhammadofficial356@gmail.com'}</span>
              </a>
            </div>
          </div>

          {/* Col 2: Studio Tools */}
          <div className="space-y-2.5">
            <h5 className="font-semibold text-neutral-900 dark:text-neutral-200 uppercase tracking-wider text-[11px]">
              Studio Tools
            </h5>
            <ul className="space-y-2">
              <li>
                <button onClick={() => openTool('cartoon')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Real Video to Cartoon (16 Styles)
                </button>
              </li>
              <li>
                <button onClick={() => openTool('viral-shorts')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Viral Shorts & Clip Maker
                </button>
              </li>
              <li>
                <button onClick={() => openTool('captions')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  AI Caption & Subtitles Editor
                </button>
              </li>
              <li>
                <button onClick={() => openTool('tts')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Text to Speech (AI Voices)
                </button>
              </li>
              <li>
                <button onClick={() => openTool('enhancer')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Video Enhancer & Upscaler
                </button>
              </li>
              <li>
                <button onClick={() => openTool('editor')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Timeline Video Editor
                </button>
              </li>
              <li>
                <button onClick={() => openTool('content')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  AI Scripts & Content Engine
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Media Utilities */}
          <div className="space-y-2.5">
            <h5 className="font-semibold text-neutral-900 dark:text-neutral-200 uppercase tracking-wider text-[11px]">
              Media Utilities
            </h5>
            <ul className="space-y-2">
              <li>
                <button onClick={() => openTool('converter')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Universal Video Converter
                </button>
              </li>
              <li>
                <button onClick={() => openTool('compressor')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Video Compressor
                </button>
              </li>
              <li>
                <button onClick={() => openTool('resizer')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Social Aspect Ratio Resizer
                </button>
              </li>
              <li>
                <button onClick={() => openTool('audio')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Audio Suite & Silence Cutter
                </button>
              </li>
              <li>
                <button onClick={() => openTool('transcription')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Speech-to-Text Transcription
                </button>
              </li>
              <li>
                <button onClick={() => openTool('thumbnail')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Thumbnail Graphic Canvas
                </button>
              </li>
              <li>
                <button onClick={() => openTool('social-repurpose')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Social Repurposer & Safe Zones
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Legal & Policies */}
          <div className="space-y-2.5">
            <h5 className="font-semibold text-neutral-900 dark:text-neutral-200 uppercase tracking-wider text-[11px]">
              Compliance & Legal
            </h5>
            <ul className="space-y-2">
              <li>
                <button onClick={() => openLegalPage('about')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  About Us
                </button>
              </li>
              <li>
                <button onClick={() => openLegalPage('contact')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Contact & Support
                </button>
              </li>
              <li>
                <button onClick={() => openLegalPage('privacy')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => openLegalPage('terms')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Terms of Service
                </button>
              </li>
              <li>
                <button onClick={() => openLegalPage('cookies')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Cookie Policy
                </button>
              </li>
              <li>
                <button onClick={() => openLegalPage('dmca')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  DMCA & Copyright Policy
                </button>
              </li>
              <li>
                <button onClick={() => openLegalPage('ai-disclaimer')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  AI Content Disclaimer
                </button>
              </li>
              <li>
                <button onClick={() => openLegalPage('refund')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Refund Policy (Future Plans)
                </button>
              </li>
              <li>
                <button onClick={() => openLegalPage('security')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Security & Data Privacy
                </button>
              </li>
              <li>
                <button onClick={() => openLegalPage('faq')} className="hover:text-neutral-900 dark:hover:text-white transition-colors">
                  Help Center & FAQs
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar with quiet copyright and admin portal link */}
        <div className="pt-8 border-t border-neutral-200 dark:border-neutral-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-neutral-500">
          <p>
            © {new Date().getFullYear()} {siteConfig.siteName || 'CineMorph Studio'}. All rights reserved. Built for creators and visual artists worldwide.
          </p>
          <div className="flex items-center gap-4 text-[11px]">
            <a
              href="/admin-login.html"
              className="hover:text-neutral-400 transition-colors flex items-center gap-1"
            >
              <span>Admin Gateway</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
