import React from 'react';
import { useApp, LegalPageSlug } from '../../context/AppContext';
import { Phone, Mail, Shield, AlertTriangle, FileText, HelpCircle, CheckCircle } from 'lucide-react';

export const LegalPages: React.FC = () => {
  const { activeLegalSlug, openLegalPage, openTool, siteConfig } = useApp();

  const pagesNav: { slug: LegalPageSlug; label: string }[] = [
    { slug: 'about', label: 'About Us' },
    { slug: 'contact', label: 'Contact Us' },
    { slug: 'privacy', label: 'Privacy Policy' },
    { slug: 'terms', label: 'Terms of Service' },
    { slug: 'cookies', label: 'Cookie Policy' },
    { slug: 'disclaimer', label: 'Disclaimer' },
    { slug: 'dmca', label: 'DMCA / Copyright' },
    { slug: 'acceptable-use', label: 'Acceptable Use' },
    { slug: 'refund', label: 'Refund Policy' },
    { slug: 'ai-disclaimer', label: 'AI Content Disclaimer' },
    { slug: 'security', label: 'Security & Privacy' },
    { slug: 'faq', label: 'Help Center & FAQ' }
  ];

  return (
    <div className="space-y-8 max-w-5xl mx-auto py-4">
      {/* Horizontal Nav Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-neutral-200 dark:border-neutral-800 text-xs">
        {pagesNav.map((item) => (
          <button
            key={item.slug}
            onClick={() => openLegalPage(item.slug)}
            className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors font-medium ${activeLegalSlug === item.slug ? 'bg-indigo-600 text-white' : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'}`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Page Content Rendered */}
      <div className="p-8 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl shadow-sm text-neutral-800 dark:text-neutral-200 leading-relaxed text-sm space-y-6">
        {/* 1. About Us */}
        {activeLegalSlug === 'about' && (
          <div className="space-y-4">
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              About CineMorph Studio
            </h1>
            <p>
              CineMorph Studio is an independent next-generation creative technology platform founded to empower creators, video editors, and social media producers with professional browser-native AI and digital media transformation tools.
            </p>
            <p>
              Unlike legacy cloud render farms that upload heavy gigabytes of footage and lock basic features behind deceptive paywalls, CineMorph Studio prioritizes lightweight, high-performance client-side WebGL canvas processing and authentic neural integrations. Our flagship Real Video-to-Cartoon engine allows full artistic re-styling while preserving genuine human kinematics, facial expressions, and frame compositions.
            </p>
            <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100 pt-2">Our Core Principles</h3>
            <ul className="list-disc list-inside space-y-1.5 text-xs text-neutral-600 dark:text-neutral-400">
              <li><strong>Zero Deceptive Processing:</strong> Every tool actually transforms, cuts, synthesizes, and exports real media.</li>
              <li><strong>Privacy by Architecture:</strong> Video transformation executes locally inside browser memory whenever technically supported.</li>
              <li><strong>Free Accessible Creation:</strong> Generous free allowances with zero upfront credit card requirements.</li>
            </ul>
          </div>
        )}

        {/* 2. Contact Us */}
        {activeLegalSlug === 'contact' && (
          <div className="space-y-5">
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              Contact & Support
            </h1>
            <p className="text-neutral-500">
              Have questions, feedback, or need enterprise assistance? Reach our engineering team directly via official channels:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <a
                href="https://wa.me/923199389323"
                target="_blank"
                rel="noreferrer"
                className="p-5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 flex items-start gap-3.5 hover:border-emerald-500/50 transition-colors"
              >
                <div className="p-2.5 rounded-lg bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-neutral-900 dark:text-neutral-100">WhatsApp Support</h4>
                  <p className="font-mono text-xs text-emerald-600 dark:text-emerald-400 mt-0.5">+923199389323</p>
                  <span className="text-[11px] text-neutral-500 block mt-1">Direct messaging support available</span>
                </div>
              </a>

              <a
                href="mailto:muhammadofficial356@gmail.com"
                className="p-5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 flex items-start gap-3.5 hover:border-indigo-500/50 transition-colors"
              >
                <div className="p-2.5 rounded-lg bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-neutral-900 dark:text-neutral-100">Email Inquiries</h4>
                  <p className="font-mono text-xs text-indigo-600 dark:text-indigo-400 mt-0.5">muhammadofficial356@gmail.com</p>
                  <span className="text-[11px] text-neutral-500 block mt-1">Average response time: &lt; 24 business hours</span>
                </div>
              </a>
            </div>
          </div>
        )}

        {/* 3. Privacy Policy */}
        {activeLegalSlug === 'privacy' && (
          <div className="space-y-4">
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              Privacy Policy
            </h1>
            <p className="text-xs text-neutral-400">Last updated: September 2026</p>
            <p>
              Your privacy is paramount. CineMorph Studio is engineered so that high-bandwidth media processing (video-to-cartoon filters, video trimming, video resizing, audio cutting, and frame enhancements) occurs on the client-side using WebGL, HTML5 Canvas, and Web Audio APIs inside your browser sandbox.
            </p>
            <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100">Information We Process</h3>
            <ul className="list-disc list-inside space-y-1.5 text-xs text-neutral-600 dark:text-neutral-400">
              <li><strong>Local Media:</strong> Uploaded video files stay in your local browser instance unless an AI API call (such as speech-to-text transcription or text-to-speech) is triggered by you.</li>
              <li><strong>AI Queries:</strong> Text prompts submitted to AI Content generation engines or Text-to-Speech are sent encrypted to Google Gemini APIs on the server solely to fulfill the requested generation.</li>
              <li><strong>Retention:</strong> Any temporary server files created for audio transcribing are automatically purged upon request completion.</li>
            </ul>
          </div>
        )}

        {/* 4. Terms of Service */}
        {activeLegalSlug === 'terms' && (
          <div className="space-y-4">
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              Terms of Service
            </h1>
            <p>
              By accessing CineMorph Studio, you agree to these Terms. You retain full intellectual property ownership over the videos, audio, and content you produce through our platform.
            </p>
            <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100">Permitted Use</h3>
            <p className="text-xs text-neutral-600 dark:text-neutral-400">
              You agree not to use the studio to generate unlawful, defamatory, infringing, or malicious media, or to circumvent technical rate limits.
            </p>
          </div>
        )}

        {/* 5. Cookie Policy */}
        {activeLegalSlug === 'cookies' && (
          <div className="space-y-4">
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              Cookie Policy
            </h1>
            <p>
              CineMorph Studio uses strictly necessary local storage cookies solely to preserve user preferences (dark/light theme mode, project library storage, and authorized administrative session tokens).
            </p>
          </div>
        )}

        {/* 6. Disclaimer */}
        {activeLegalSlug === 'disclaimer' && (
          <div className="space-y-4">
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              Disclaimer
            </h1>
            <p>
              All tools are provided on an &ldquo;as is&rdquo; basis. Viral Shorts scores and AI recommendations represent algorithmic heuristics based on common pacing rules; CineMorph Studio makes no fraudulent promise or guarantee of audience metrics or viral reach.
            </p>
          </div>
        )}

        {/* 7. DMCA Policy */}
        {activeLegalSlug === 'dmca' && (
          <div className="space-y-4">
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              DMCA & Copyright Compliance
            </h1>
            <p>
              We respect copyright holders. If you believe your copyrighted material is being infringed through our platform, please send a written takedown notice to <code>muhammadofficial356@gmail.com</code> with proof of ownership.
            </p>
          </div>
        )}

        {/* 8. Acceptable Use Policy */}
        {activeLegalSlug === 'acceptable-use' && (
          <div className="space-y-4">
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              Acceptable Use Policy
            </h1>
            <p>
              Users must not abuse processing infrastructure, generate non-consensual deepfakes of real individuals, or deploy automated DDoS traffic against server endpoints.
            </p>
          </div>
        )}

        {/* 9. Refund Policy */}
        {activeLegalSlug === 'refund' && (
          <div className="space-y-4">
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              Refund Policy (Future Paid Plans)
            </h1>
            <p>
              Currently, CineMorph Studio features are provided 100% free of charge. In the future event that paid subscription tiers (Pro, Premium, Business) are enabled by administrators, subscribers will be entitled to a 14-day money-back satisfaction guarantee on new monthly subscriptions.
            </p>
          </div>
        )}

        {/* 10. AI Content Disclaimer */}
        {activeLegalSlug === 'ai-disclaimer' && (
          <div className="space-y-4">
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              AI Content & Synthetic Media Disclaimer
            </h1>
            <p>
              Artistic styles such as 2D Cartoon, Anime, Pixar-Inspired 3D, and Watercolor use mathematical image filtering and neural style approximations. They do not duplicate or replicate copyrighted animated films or proprietary trademarked characters. Users are advised to review generated scripts and text outputs for factual accuracy.
            </p>
          </div>
        )}

        {/* 11. Security */}
        {activeLegalSlug === 'security' && (
          <div className="space-y-4">
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              Security Architecture
            </h1>
            <p>
              All traffic between your browser and our server is secured with HTTPS TLS 1.3 encryption. Secret environment variables such as <code className="font-mono text-indigo-400">GEMINI_API_KEY</code> and admin credentials are kept strictly server-side and never exposed to client bundles.
            </p>
          </div>
        )}

        {/* 12. FAQ */}
        {activeLegalSlug === 'faq' && (
          <div className="space-y-4">
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              Help Center & Frequently Asked Questions
            </h1>
            <div className="space-y-4 pt-2">
              <div className="p-4 bg-neutral-50 dark:bg-neutral-950 rounded-xl border border-neutral-200 dark:border-neutral-800 space-y-1">
                <h4 className="font-semibold text-neutral-900 dark:text-neutral-100">Is CineMorph Studio free to use?</h4>
                <p className="text-xs text-neutral-500">Yes! All 15 core video, audio, and content generation tools are 100% free with standard daily processing limits.</p>
              </div>
              <div className="p-4 bg-neutral-50 dark:bg-neutral-950 rounded-xl border border-neutral-200 dark:border-neutral-800 space-y-1">
                <h4 className="font-semibold text-neutral-900 dark:text-neutral-100">Are my uploaded videos stored permanently?</h4>
                <p className="text-xs text-neutral-500">No. Processing takes place locally in your browser memory. We do not store your private video footage.</p>
              </div>
              <div className="p-4 bg-neutral-50 dark:bg-neutral-950 rounded-xl border border-neutral-200 dark:border-neutral-800 space-y-1">
                <h4 className="font-semibold text-neutral-900 dark:text-neutral-100">What output video formats are supported?</h4>
                <p className="text-xs text-neutral-500">We support standard WebM, MP4, PNG snapshots, and WAV/MP3 audio downloads.</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
