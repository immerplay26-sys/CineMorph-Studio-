import React from 'react';
import { useApp } from '../../context/AppContext';
import { FolderOpen, Download, Trash2, Video, Sparkles, ExternalLink } from 'lucide-react';

export const ProjectsLibrary: React.FC = () => {
  const { savedProjects, deleteProject, openTool } = useApp();

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <FolderOpen className="w-5 h-5 text-indigo-500" />
            <span>My Projects & Export History</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Access, preview, and re-download your rendered videos, clips, and audio tracks saved in your browser storage.
          </p>
        </div>

        <button
          onClick={() => openTool('cartoon')}
          className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>New Studio Project</span>
        </button>
      </div>

      {savedProjects.length === 0 ? (
        <div className="p-16 text-center border-2 border-dashed border-neutral-200 dark:border-neutral-800 rounded-2xl space-y-3">
          <FolderOpen className="w-10 h-10 text-neutral-400 mx-auto" />
          <h3 className="text-sm font-semibold text-neutral-800 dark:text-neutral-200">
            No projects in your library yet
          </h3>
          <p className="text-xs text-neutral-500 max-w-sm mx-auto">
            Render an animation, extract viral shorts, or generate audio in any tool to save it automatically here.
          </p>
          <button
            onClick={() => openTool('cartoon')}
            className="mt-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold"
          >
            Create Your First Clip
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {savedProjects.map((p) => (
            <div
              key={p.id}
              className="p-4 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[11px] text-neutral-400 font-mono">
                  <span>{new Date(p.createdAt).toLocaleDateString()}</span>
                  <span>{p.fileSize || 'Standard'}</span>
                </div>

                <h4 className="text-sm font-bold text-neutral-900 dark:text-neutral-100 truncate" title={p.title}>
                  {p.title}
                </h4>

                <div className="flex items-center gap-2 text-xs text-neutral-500">
                  <span className="capitalize">{p.toolId.replace('-', ' ')}</span>
                  {p.resolution && (
                    <>
                      <span>·</span>
                      <span className="font-mono">{p.resolution}</span>
                    </>
                  )}
                  {p.duration !== undefined && (
                    <>
                      <span>·</span>
                      <span className="font-mono">{p.duration}s</span>
                    </>
                  )}
                </div>
              </div>

              {p.previewUrl && (
                <div className="relative aspect-video rounded-lg overflow-hidden bg-black border border-neutral-800 flex items-center justify-center">
                  <video src={p.previewUrl} controls className="w-full h-full object-contain" />
                </div>
              )}

              <div className="pt-3 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                {p.previewUrl ? (
                  <a
                    href={p.previewUrl}
                    download={`${p.title}.webm`}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </a>
                ) : (
                  <span className="text-[11px] text-neutral-400">Archived</span>
                )}

                <button
                  onClick={() => deleteProject(p.id)}
                  className="p-1.5 text-neutral-400 hover:text-rose-500 rounded transition-colors"
                  title="Remove from library"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
