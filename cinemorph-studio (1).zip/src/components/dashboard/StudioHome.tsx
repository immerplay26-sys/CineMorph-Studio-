import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { STUDIO_TOOLS } from '../../constants/defaults';
import { StudioToolId } from '../../types';
import {
  Sparkles,
  Film,
  Subtitles,
  Mic,
  Wand2,
  Scissors,
  RefreshCw,
  Minimize2,
  Maximize2,
  Volume2,
  FileText,
  AlignLeft,
  Image as ImageIcon,
  Share2,
  Layers,
  ArrowRight,
  ShieldCheck,
  Zap,
  FolderOpen,
  Languages,
  Video
} from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  Sparkles: <Sparkles className="w-5 h-5 text-indigo-500" />,
  Film: <Film className="w-5 h-5 text-indigo-500" />,
  Subtitles: <Subtitles className="w-5 h-5 text-indigo-500" />,
  Mic: <Mic className="w-5 h-5 text-indigo-500" />,
  Wand2: <Wand2 className="w-5 h-5 text-indigo-500" />,
  Scissors: <Scissors className="w-5 h-5 text-indigo-500" />,
  RefreshCw: <RefreshCw className="w-5 h-5 text-indigo-500" />,
  Minimize2: <Minimize2 className="w-5 h-5 text-indigo-500" />,
  Maximize2: <Maximize2 className="w-5 h-5 text-indigo-500" />,
  Volume2: <Volume2 className="w-5 h-5 text-indigo-500" />,
  FileText: <FileText className="w-5 h-5 text-indigo-500" />,
  AlignLeft: <AlignLeft className="w-5 h-5 text-indigo-500" />,
  Image: <ImageIcon className="w-5 h-5 text-indigo-500" />,
  Share2: <Share2 className="w-5 h-5 text-indigo-500" />,
  Layers: <Layers className="w-5 h-5 text-indigo-500" />,
  Languages: <Languages className="w-5 h-5 text-indigo-500" />,
  Video: <Video className="w-5 h-5 text-indigo-500" />
};

export const StudioHome: React.FC = () => {
  const { openTool, setCurrentView, siteConfig, savedProjects } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = [
    'All',
    'AI Video & Shorts',
    'Audio & Speech',
    'Editor & Timeline',
    'Content AI',
    'Graphics & Media',
    'Converters & Compressors'
  ];

  const filteredTools = STUDIO_TOOLS.filter((t) => {
    if (selectedCategory === 'All') return true;
    if (selectedCategory === 'AI Video & Shorts') {
      return t.category === 'AI VIDEO' || t.category === 'SHORTS & SOCIAL' || t.category === 'VIDEO';
    }
    if (selectedCategory === 'Audio & Speech') {
      return t.category === 'AI AUDIO' || t.category === 'AUDIO' || t.category === 'CAPTIONS & TRANSCRIPTS';
    }
    if (selectedCategory === 'Editor & Timeline') {
      return t.category === 'EDITOR';
    }
    if (selectedCategory === 'Content AI') {
      return t.category === 'CONTENT AI';
    }
    if (selectedCategory === 'Graphics & Media') {
      return t.category === 'IMAGE & THUMBNAIL' || t.category === 'GIF & MEDIA';
    }
    if (selectedCategory === 'Converters & Compressors') {
      return t.category === 'CONVERTERS' || t.category === 'COMPRESSORS';
    }
    return true;
  });

  return (
    <div className="space-y-12">
      {/* Site Announcement Banner if enabled */}
      {siteConfig.announcement?.show && (
        <div className="p-3.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-800 dark:text-indigo-200 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
            <span>{siteConfig.announcement.message}</span>
          </div>
          <button
            onClick={() => openTool('cartoon')}
            className="font-semibold underline hover:opacity-80 shrink-0"
          >
            Try Studio →
          </button>
        </div>
      )}

      {/* Hero Section */}
      <section className="relative rounded-2xl overflow-hidden border border-neutral-200 dark:border-neutral-800 bg-neutral-900 text-white min-h-[440px] flex items-center">
        {/* Background Image with Contrast Scrim */}
        <img
          src="/src/assets/images/cinemorph_hero_showcase_1790828690072.jpg"
          alt="CineMorph Studio Cinematic Production Environment"
          className="absolute inset-0 w-full h-full object-cover object-center opacity-40 mix-blend-luminosity"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-neutral-950 via-neutral-950/80 to-transparent"></div>

        <div className="relative z-10 p-8 sm:p-12 lg:p-16 max-w-2xl space-y-6">
          <div className="text-xs font-semibold text-indigo-400 tracking-wider uppercase flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-indigo-400"></span>
            <span>Next-Generation AI Creative Studio</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight leading-tight text-white" style={{ textWrap: 'balance' }}>
            Transform Real Video into Art. Cut Viral Shorts in Seconds.
          </h1>

          <p className="text-sm sm:text-base text-neutral-300 leading-relaxed max-w-xl">
            All-in-one workstation for digital creators: 16 animation styles, AI highlight clip extraction, animated subtitles, neural voices, and 16 content generation engines.
          </p>

          <div className="flex flex-wrap items-center gap-4 pt-2">
            <button
              onClick={() => openTool('cartoon')}
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-lg shadow-indigo-600/20 transition-colors"
            >
              <Sparkles className="w-4 h-4" />
              <span>Launch Cartoon Studio</span>
            </button>

            <button
              onClick={() => openTool('viral-shorts')}
              className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white border border-white/10 rounded-xl text-xs sm:text-sm font-semibold transition-colors"
            >
              <span>Make Viral Shorts</span>
            </button>
          </div>

          {/* Unboxed Metadata without pills */}
          <div className="flex items-center gap-2.5 text-xs text-neutral-400 pt-2 font-mono">
            <span>15 Studio Tools</span>
            <span aria-hidden="true">·</span>
            <span>16 Cartoon Styles</span>
            <span aria-hidden="true">·</span>
            <span>100% Free Initial Access</span>
            <span aria-hidden="true">·</span>
            <span>Client-Side Privacy</span>
          </div>
        </div>
      </section>

      {/* Flagship Showcases Split Banner */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: Cartoon Studio Spotlight */}
        <div
          onClick={() => openTool('cartoon')}
          className="group relative rounded-2xl overflow-hidden border border-neutral-200 dark:border-neutral-800 bg-neutral-900 cursor-pointer p-8 flex flex-col justify-end min-h-[300px] transition-all hover:border-indigo-500/50"
        >
          <img
            src="/src/assets/images/cartoon_style_showcase_1790828704746.jpg"
            alt="Real to Cartoon Visual Comparison"
            className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:scale-105 transition-transform duration-500"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/60 to-transparent"></div>

          <div className="relative z-10 space-y-2">
            <span className="text-xs font-semibold text-indigo-400">Flagship Technology</span>
            <h3 className="text-xl font-bold text-white group-hover:text-indigo-300 transition-colors">
              Real Video to Cartoon & Anime
            </h3>
            <p className="text-xs text-neutral-300 line-clamp-2">
              Transform subjects and scenes into 2D Cartoon, Pixar-style 3D, Anime, Comic Book, Watercolor, and Stop-Motion while preserving original movements.
            </p>
            <div className="pt-2 flex items-center gap-1.5 text-xs font-semibold text-white">
              <span>Open Studio</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>

        {/* Card 2: Viral Shorts Spotlight */}
        <div
          onClick={() => openTool('viral-shorts')}
          className="group relative rounded-2xl overflow-hidden border border-neutral-200 dark:border-neutral-800 bg-neutral-900 cursor-pointer p-8 flex flex-col justify-end min-h-[300px] transition-all hover:border-indigo-500/50"
        >
          <img
            src="/src/assets/images/viral_shorts_showcase_1790828720160.jpg"
            alt="Vertical Viral Shorts Maker with Subtitles"
            className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:scale-105 transition-transform duration-500"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/60 to-transparent"></div>

          <div className="relative z-10 space-y-2">
            <span className="text-xs font-semibold text-indigo-400">High-Engagement Pipeline</span>
            <h3 className="text-xl font-bold text-white group-hover:text-indigo-300 transition-colors">
              AI Viral Shorts & Clip Extractor
            </h3>
            <p className="text-xs text-neutral-300 line-clamp-2">
              Upload long videos to detect engaging moments, smart-reframe to 9:16 vertical, and burn kinetic karaoke subtitles ready for TikTok and Reels.
            </p>
            <div className="pt-2 flex items-center gap-1.5 text-xs font-semibold text-white">
              <span>Extract Highlights</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      </section>

      {/* Tools Directory Section */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              Studio Tools Directory
            </h2>
            <p className="text-xs text-neutral-500 mt-1">
              Select any creative engine below to begin editing, transforming, or generating.
            </p>
          </div>

          {/* Interactive Filter Tabs */}
          <div className="flex items-center gap-1 p-1 bg-neutral-100 dark:bg-neutral-900 rounded-lg border border-neutral-200 dark:border-neutral-800 self-start sm:self-auto overflow-x-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${selectedCategory === cat ? 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-sm' : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredTools.map((tool) => (
            <div
              key={tool.id}
              onClick={() => openTool(tool.id)}
              className="p-5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 hover:border-indigo-500/50 hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between space-y-4 group"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 group-hover:bg-indigo-50 dark:group-hover:bg-indigo-950/60 transition-colors">
                    {iconMap[tool.iconName] || <Sparkles className="w-5 h-5 text-indigo-500" />}
                  </div>
                  <span className="text-[11px] font-medium text-neutral-500">{tool.category}</span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                    {tool.name}
                  </h3>
                  <p className="text-xs text-neutral-500 mt-1 line-clamp-2 leading-relaxed">
                    {tool.description}
                  </p>
                </div>
              </div>

              <div className="pt-3 border-t border-neutral-100 dark:border-neutral-800/80 flex items-center justify-between text-xs">
                <span className="text-indigo-600 dark:text-indigo-400 font-semibold group-hover:underline">
                  Launch Engine →
                </span>
                {tool.badge && (
                  <span className="text-[10px] font-mono text-neutral-400">
                    {tool.badge}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Privacy Architecture Notice */}
      <section className="p-6 rounded-2xl bg-neutral-100 dark:bg-neutral-900/60 border border-neutral-200 dark:border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <ShieldCheck className="w-8 h-8 text-indigo-500 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
              Transparent Privacy & Browser Execution
            </h4>
            <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed max-w-2xl">
              Video transformation, canvas shaders, video cutting, audio trimming, and compression happen entirely client-side inside your browser memory. No private video files are permanently stored on third-party servers.
            </p>
          </div>
        </div>
        <div className="text-xs font-mono text-neutral-500 shrink-0">
          Zero Data Logging
        </div>
      </section>
    </div>
  );
};
