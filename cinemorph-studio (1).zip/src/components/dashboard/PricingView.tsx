import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Check, Sparkles, Zap, Shield } from 'lucide-react';

export const PricingView: React.FC = () => {
  const { siteConfig, openTool } = useApp();
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  const plans = siteConfig.plans || [];

  return (
    <div className="space-y-12 py-6 max-w-6xl mx-auto">
      {/* Title & Billing Toggle */}
      <div className="text-center space-y-4 max-w-xl mx-auto">
        <span className="text-xs font-semibold text-indigo-500 uppercase tracking-wider">
          Creator & Studio Subscriptions
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-neutral-900 dark:text-neutral-100">
          Flexible Plans for Every Creator
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 leading-relaxed">
          Currently, all 15 CineMorph Studio tools are 100% free with generous default daily processing allowances.
        </p>

        {/* Monthly / Yearly Switcher */}
        <div className="inline-flex items-center gap-1 p-1 bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setBillingCycle('monthly')}
            className={`px-4 py-2 rounded-lg transition-colors ${billingCycle === 'monthly' ? 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-sm' : 'text-neutral-500'}`}
          >
            Monthly Billing
          </button>
          <button
            onClick={() => setBillingCycle('yearly')}
            className={`px-4 py-2 rounded-lg transition-colors flex items-center gap-1.5 ${billingCycle === 'yearly' ? 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-sm' : 'text-neutral-500'}`}
          >
            <span>Annual Billing</span>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-mono font-bold">Save 20%</span>
          </button>
        </div>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {plans.map((plan) => {
          const price = billingCycle === 'monthly' ? plan.priceMonthly : Math.round(plan.priceYearly / 12);
          const isFree = plan.id === 'free';

          return (
            <div
              key={plan.id}
              className={`p-6 rounded-2xl border flex flex-col justify-between space-y-6 relative transition-all ${plan.isPopular ? 'border-indigo-600 bg-indigo-50/20 dark:bg-indigo-950/20 shadow-xl' : 'border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900'}`}
            >
              {plan.isPopular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-bold uppercase tracking-wider shadow">
                  Most Popular
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-bold text-neutral-900 dark:text-neutral-100">{plan.name}</h3>
                  <p className="text-xs text-neutral-500 mt-1 min-h-[32px]">{plan.tagline}</p>
                </div>

                <div className="pt-2 pb-2">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-extrabold font-mono text-neutral-900 dark:text-neutral-100">
                      ${price}
                    </span>
                    <span className="text-xs text-neutral-500 font-mono">/ month</span>
                  </div>
                  {billingCycle === 'yearly' && !isFree && (
                    <span className="text-[11px] text-neutral-400 font-mono block mt-0.5">
                      Billed annually (${plan.priceYearly}/yr)
                    </span>
                  )}
                </div>

                <ul className="space-y-2.5 text-xs text-neutral-600 dark:text-neutral-300 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                  {plan.features.map((feat, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <Check className="w-3.5 h-3.5 text-indigo-500 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <button
                  onClick={() => openTool('cartoon')}
                  className={`w-full py-2.5 rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 ${isFree || plan.isPopular ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm' : 'bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-900 dark:text-white'}`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{isFree ? 'Start Free Now' : 'Choose Plan'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quantitative proof and SLA */}
      <div className="p-8 rounded-2xl bg-neutral-50 dark:bg-neutral-900/60 border border-neutral-200 dark:border-neutral-800 grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
        <div>
          <span className="text-2xl font-bold font-mono text-indigo-600 dark:text-indigo-400">100% Free</span>
          <p className="text-xs text-neutral-500 mt-1">Zero credit card required for standard studio creation</p>
        </div>
        <div>
          <span className="text-2xl font-bold font-mono text-indigo-600 dark:text-indigo-400">1080p & 2K</span>
          <p className="text-xs text-neutral-500 mt-1">Direct export in broadcast video & audio formats</p>
        </div>
        <div>
          <span className="text-2xl font-bold font-mono text-indigo-600 dark:text-indigo-400">Zero Watermark</span>
          <p className="text-xs text-neutral-500 mt-1">Clean exported clips ready for instant publishing</p>
        </div>
      </div>
    </div>
  );
};
