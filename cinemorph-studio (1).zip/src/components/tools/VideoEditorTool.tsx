import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Scissors,
  Upload,
  Play,
  Pause,
  Download,
  RotateCw,
  Volume2,
  VolumeX,
  Gauge,
  Type,
  Sliders,
  Undo2,
  Redo2,
  Layers
} from 'lucide-react';

interface EditorState {
  trimStart: number;
  trimEnd: number;
  rotation: number; // 0, 90, 180, 270
  speed: number; // 0.25 to 4
  volume: number; // 0 to 1
  isMuted: boolean;
  filter: 'none' | 'cinematic' | 'vintage' | 'cyber' | 'warm' | 'bw';
  textOverlay: string;
  textColor: string;
}

export const VideoEditorTool: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [videoName, setVideoName] = useState<string>('project_edit.mp4');
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(20);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  const initialEditorState: EditorState = {
    trimStart: 0,
    trimEnd: 20,
    rotation: 0,
    speed: 1,
    volume: 1,
    isMuted: false,
    filter: 'none',
    textOverlay: '',
    textColor: '#FFFFFF'
  };

  const [state, setState] = useState<EditorState>(initialEditorState);
  const [history, setHistory] = useState<EditorState[]>([initialEditorState]);
  const [historyIdx, setHistoryIdx] = useState<number>(0);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const updateStateWithHistory = (updater: (prev: EditorState) => EditorState) => {
    setState((prev) => {
      const next = updater(prev);
      const newHist = [...history.slice(0, historyIdx + 1), next];
      setHistory(newHist);
      setHistoryIdx(newHist.length - 1);
      return next;
    });
  };

  const handleUndo = () => {
    if (historyIdx > 0) {
      setHistoryIdx(historyIdx - 1);
      setState(history[historyIdx - 1]);
    }
  };

  const handleRedo = () => {
    if (historyIdx < history.length - 1) {
      setHistoryIdx(historyIdx + 1);
      setState(history[historyIdx + 1]);
    }
  };

  // Video playback & render loop
  useEffect(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      if (video && video.readyState >= 2) {
        let w = video.videoWidth || 640;
        let h = video.videoHeight || 360;

        if (state.rotation === 90 || state.rotation === 270) {
          canvas.width = h;
          canvas.height = w;
        } else {
          canvas.width = w;
          canvas.height = h;
        }

        ctx.save();

        // Rotation transform
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate((state.rotation * Math.PI) / 180);

        if (state.rotation === 90 || state.rotation === 270) {
          ctx.drawImage(video, -h / 2, -w / 2, h, w);
        } else {
          ctx.drawImage(video, -w / 2, -h / 2, w, h);
        }

        ctx.restore();

        // Apply visual filter
        if (state.filter === 'cinematic') {
          ctx.fillStyle = 'rgba(15, 23, 42, 0.15)';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        } else if (state.filter === 'vintage') {
          ctx.fillStyle = 'rgba(120, 53, 15, 0.2)';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        } else if (state.filter === 'bw') {
          const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          for (let i = 0; i < imgData.data.length; i += 4) {
            const gray = 0.299 * imgData.data[i] + 0.587 * imgData.data[i + 1] + 0.114 * imgData.data[i + 2];
            imgData.data[i] = gray;
            imgData.data[i + 1] = gray;
            imgData.data[i + 2] = gray;
          }
          ctx.putImageData(imgData, 0, 0);
        } else if (state.filter === 'warm') {
          ctx.fillStyle = 'rgba(251, 146, 60, 0.12)';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }

        // Text overlay
        if (state.textOverlay) {
          ctx.save();
          ctx.font = 'bold 36px "Cabinet Grotesk", sans-serif';
          ctx.fillStyle = state.textColor;
          ctx.textAlign = 'center';
          ctx.shadowColor = 'rgba(0,0,0,0.8)';
          ctx.shadowBlur = 8;
          ctx.fillText(state.textOverlay, canvas.width / 2, canvas.height - 40);
          ctx.restore();
        }

        // Loop within trim range
        if (video.currentTime > state.trimEnd) {
          video.currentTime = state.trimStart;
        }
      } else {
        canvas.width = 640;
        canvas.height = 360;
        ctx.fillStyle = '#090d16';
        ctx.fillRect(0, 0, 640, 360);
        ctx.fillStyle = '#64748b';
        ctx.font = '14px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('Timeline Preview (Upload video to begin)', 320, 180);
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [state]);

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) {
      if (v.currentTime < state.trimStart || v.currentTime >= state.trimEnd) {
        v.currentTime = state.trimStart;
      }
      v.playbackRate = state.speed;
      v.volume = state.isMuted ? 0 : state.volume;
      v.play().then(() => setIsPlaying(true));
    } else {
      v.pause();
      setIsPlaying(false);
    }
  };

  const handleExport = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        saveProject({
          title: `Edited_${videoName}`,
          toolId: 'editor',
          duration: Math.round(state.trimEnd - state.trimStart),
          previewUrl: url
        });

        const a = document.createElement('a');
        a.href = url;
        a.download = `edited_${videoName.replace(/\.[^/.]+$/, '')}.png`;
        a.click();
        showToast('Exported edited snapshot!', 'success');
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <Scissors className="w-5 h-5 text-indigo-500" />
            <span>Timeline Video Editor</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Browser-based non-linear video editing: trim, rotate, speed ramp, audio control, color grading, and text overlays.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Undo / Redo */}
          <div className="flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 p-1 rounded-lg">
            <button
              onClick={handleUndo}
              disabled={historyIdx === 0}
              className="p-1.5 rounded hover:bg-neutral-200 dark:hover:bg-neutral-700 disabled:opacity-40 text-neutral-700 dark:text-neutral-300"
              title="Undo"
            >
              <Undo2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleRedo}
              disabled={historyIdx >= history.length - 1}
              className="p-1.5 rounded hover:bg-neutral-200 dark:hover:bg-neutral-700 disabled:opacity-40 text-neutral-700 dark:text-neutral-300"
              title="Redo"
            >
              <Redo2 className="w-3.5 h-3.5" />
            </button>
          </div>

          <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-200 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded-lg transition-colors border border-neutral-300 dark:border-neutral-700">
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Video</span>
            <input
              type="file"
              accept="video/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) {
                  setVideoSrc(URL.createObjectURL(f));
                  setVideoName(f.name);
                  showToast(`Loaded "${f.name}"`, 'success');
                }
              }}
            />
          </label>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 8 Cols: Canvas Viewport & Timeline Scrubber */}
        <div className="lg:col-span-8 space-y-4">
          <div className="relative aspect-video bg-neutral-950 rounded-xl overflow-hidden border border-neutral-800 shadow-xl flex items-center justify-center">
            {videoSrc && (
              <video
                ref={videoRef}
                src={videoSrc}
                playsInline
                className="hidden"
                onLoadedMetadata={(e) => {
                  const d = e.currentTarget.duration || 20;
                  setDuration(d);
                  updateStateWithHistory((s) => ({ ...s, trimEnd: d }));
                }}
                onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
                crossOrigin="anonymous"
              />
            )}
            <canvas ref={canvasRef} className="w-full h-full object-contain" />
          </div>

          {/* Timeline Bar & Trim Markers */}
          <div className="p-3.5 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3">
            <div className="flex items-center gap-3">
              <button
                onClick={togglePlay}
                disabled={!videoSrc}
                className="p-2 text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg disabled:opacity-50"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>

              <input
                type="range"
                min={0}
                max={duration}
                step="0.05"
                value={currentTime}
                onChange={(e) => {
                  const t = parseFloat(e.target.value);
                  if (videoRef.current) videoRef.current.currentTime = t;
                  setCurrentTime(t);
                }}
                className="flex-1 accent-indigo-600 h-1.5 bg-neutral-200 dark:bg-neutral-800 rounded appearance-none cursor-pointer"
              />

              <span className="text-xs font-mono text-neutral-400 tabular-nums shrink-0">
                {currentTime.toFixed(1)}s / {duration.toFixed(1)}s
              </span>
            </div>

            {/* Trimming In/Out Controls */}
            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800/80 flex items-center justify-between text-xs">
              <div className="flex items-center gap-3">
                <span className="text-neutral-500">Trim In:</span>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max={state.trimEnd}
                  value={state.trimStart}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value) || 0;
                    updateStateWithHistory((s) => ({ ...s, trimStart: v }));
                  }}
                  className="w-16 px-1.5 py-0.5 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded text-center font-mono"
                />
                <span className="text-neutral-500">Trim Out:</span>
                <input
                  type="number"
                  step="0.1"
                  min={state.trimStart}
                  max={duration}
                  value={state.trimEnd}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value) || duration;
                    updateStateWithHistory((s) => ({ ...s, trimEnd: v }));
                  }}
                  className="w-16 px-1.5 py-0.5 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded text-center font-mono"
                />
              </div>

              <button
                onClick={handleExport}
                className="flex items-center gap-1.5 px-3 py-1.5 font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg text-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Frame / Cut</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right 4 Cols: Editor Adjustment Controls */}
        <div className="lg:col-span-4 space-y-4">
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3.5 text-xs">
            <h3 className="font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[11px] pb-2 border-b border-neutral-100 dark:border-neutral-800">
              Transforms & Color Grading
            </h3>

            {/* Rotation */}
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">Orientation</span>
              <button
                onClick={() => updateStateWithHistory((s) => ({ ...s, rotation: (s.rotation + 90) % 360 }))}
                className="flex items-center gap-1 px-2.5 py-1 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded text-neutral-700 dark:text-neutral-300 font-mono"
              >
                <RotateCw className="w-3.5 h-3.5" />
                <span>{state.rotation}°</span>
              </button>
            </div>

            {/* Speed ramp */}
            <div className="space-y-1">
              <div className="flex justify-between text-neutral-500">
                <span>Speed Ramp</span>
                <span className="font-mono tabular-nums">{state.speed}x</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {[0.5, 1.0, 1.5, 2.0].map((spd) => (
                  <button
                    key={spd}
                    onClick={() => updateStateWithHistory((s) => ({ ...s, speed: spd }))}
                    className={`py-1 rounded border text-center font-mono ${state.speed === spd ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-semibold' : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'}`}
                  >
                    {spd}x
                  </button>
                ))}
              </div>
            </div>

            {/* Audio Volume */}
            <div className="space-y-1">
              <div className="flex justify-between text-neutral-500">
                <span>Audio Volume</span>
                <button
                  onClick={() => updateStateWithHistory((s) => ({ ...s, isMuted: !s.isMuted }))}
                  className="text-neutral-400 hover:text-neutral-200"
                >
                  {state.isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                </button>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={state.isMuted ? 0 : state.volume}
                onChange={(e) => {
                  const v = parseFloat(e.target.value);
                  updateStateWithHistory((s) => ({ ...s, volume: v, isMuted: v === 0 }));
                }}
                className="w-full accent-indigo-600 h-1 bg-neutral-200 dark:bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>

            {/* Color Filter */}
            <div className="space-y-1 pt-1">
              <span className="text-neutral-500 block">Look / Film Grading</span>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { id: 'none', label: 'Original' },
                  { id: 'cinematic', label: 'Cinematic' },
                  { id: 'vintage', label: 'Vintage' },
                  { id: 'bw', label: 'B & W' },
                  { id: 'warm', label: 'Warm Sun' }
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => updateStateWithHistory((s) => ({ ...s, filter: f.id as EditorState['filter'] }))}
                    className={`py-1 rounded border text-center ${state.filter === f.id ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-semibold' : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'}`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Text Overlay */}
            <div className="space-y-1 pt-1 border-t border-neutral-100 dark:border-neutral-800">
              <label className="text-neutral-500 block">On-Screen Text Banner</label>
              <input
                type="text"
                value={state.textOverlay}
                onChange={(e) => updateStateWithHistory((s) => ({ ...s, textOverlay: e.target.value }))}
                placeholder="e.g. PART 1: THE DISCOVERY"
                className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
