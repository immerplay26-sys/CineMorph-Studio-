import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Minimize2,
  Upload,
  Download,
  CheckCircle2,
  Sliders,
  FileCheck
} from 'lucide-react';

export const VideoCompressorTool: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [file, setFile] = useState<File | null>(null);
  const [originalSizeMb, setOriginalSizeMb] = useState<number>(45.8);
  const [compressionMode, setCompressionMode] = useState<'percent' | 'targetSize' | 'preset'>('preset');
  const [qualityPreset, setQualityPreset] = useState<'high' | 'medium' | 'low' | 'discord'>('medium');
  const [compressionPercent, setCompressionPercent] = useState<number>(50);
  const [targetSizeMb, setTargetSizeMb] = useState<number>(10);

  const [isCompressing, setIsCompressing] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [compressedBlobUrl, setCompressedBlobUrl] = useState<string | null>(null);

  // Compute estimated size based on quality preset or percentage
  let estimatedSizeMb = originalSizeMb;
  if (compressionMode === 'preset') {
    if (qualityPreset === 'high') estimatedSizeMb = originalSizeMb * 0.75;
    else if (qualityPreset === 'medium') estimatedSizeMb = originalSizeMb * 0.5;
    else if (qualityPreset === 'low') estimatedSizeMb = originalSizeMb * 0.25;
    else if (qualityPreset === 'discord') estimatedSizeMb = Math.min(originalSizeMb * 0.4, 8); // Discord 8MB limit
  } else if (compressionMode === 'percent') {
    estimatedSizeMb = originalSizeMb * (1 - compressionPercent / 100);
  } else {
    estimatedSizeMb = targetSizeMb;
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      setFile(f);
      const mb = parseFloat((f.size / (1024 * 1024)).toFixed(1));
      setOriginalSizeMb(mb);
      setTargetSizeMb(Math.max(2, Math.floor(mb * 0.4)));
      setCompressedBlobUrl(null);
      showToast(`Selected "${f.name}" (${mb} MB)`, 'info');
    }
  };

  const handleCompress = () => {
    setIsCompressing(true);
    setProgress(0);

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsCompressing(false);

          // Simulated high-efficiency compressed blob
          const simulatedBlob = new Blob([new ArrayBuffer(Math.floor(estimatedSizeMb * 1024 * 1024))], {
            type: 'video/mp4'
          });
          const url = URL.createObjectURL(simulatedBlob);
          setCompressedBlobUrl(url);

          saveProject({
            title: `Compressed_${file?.name || 'video.mp4'}`,
            toolId: 'compressor',
            fileSize: `${estimatedSizeMb.toFixed(1)} MB`,
            previewUrl: url
          });

          showToast('Video compression completed!', 'success');
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <Minimize2 className="w-5 h-5 text-indigo-500" />
            <span>Smart Video Compressor</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Reduce video file sizes by up to 85% for Discord, email, WhatsApp, and websites while maintaining perceptual clarity.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 6 Cols: Upload & Estimation Panel */}
        <div className="lg:col-span-6 space-y-4">
          <label className="border-2 border-dashed border-neutral-300 dark:border-neutral-800 hover:border-indigo-500 dark:hover:border-indigo-500 rounded-xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-colors bg-white dark:bg-neutral-900">
            <Upload className="w-8 h-8 text-neutral-400 mb-2" />
            <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
              {file ? file.name : 'Click to select video or drag file here'}
            </span>
            <span className="text-[11px] text-neutral-500 mt-1">
              Initial Size: {originalSizeMb.toFixed(1)} MB
            </span>
            <input type="file" accept="video/*" onChange={handleFileChange} className="hidden" />
          </label>

          {/* Before/After Size Estimation Box */}
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-700 dark:text-neutral-300">
              Compression Metrics & Output Estimate
            </h4>

            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="p-3 bg-neutral-50 dark:bg-neutral-950 rounded-lg border border-neutral-200 dark:border-neutral-800">
                <span className="text-[11px] text-neutral-500 block">Original Size</span>
                <span className="text-base font-bold font-mono text-neutral-800 dark:text-neutral-200">
                  {originalSizeMb.toFixed(1)} MB
                </span>
              </div>

              <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 rounded-lg border border-indigo-200 dark:border-indigo-900/40">
                <span className="text-[11px] text-indigo-600 dark:text-indigo-400 block">Estimated Size</span>
                <span className="text-base font-bold font-mono text-indigo-600 dark:text-indigo-300">
                  {estimatedSizeMb.toFixed(1)} MB
                </span>
              </div>
            </div>

            <div className="pt-2 text-center text-xs text-emerald-600 dark:text-emerald-400 font-medium">
              Saved ~{(((originalSizeMb - estimatedSizeMb) / originalSizeMb) * 100).toFixed(0)}% storage space!
            </div>
          </div>

          {isCompressing && (
            <div className="p-4 bg-neutral-900 rounded-xl border border-neutral-800 space-y-2 text-center">
              <div className="text-xs font-semibold text-white">Compressing frames ({progress}%)</div>
              <div className="w-full bg-neutral-800 h-2 rounded-full overflow-hidden">
                <div className="bg-indigo-500 h-full transition-all" style={{ width: `${progress}%` }}></div>
              </div>
            </div>
          )}

          {compressedBlobUrl && (
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/30 rounded-xl border border-emerald-300 dark:border-emerald-800 flex items-center justify-between text-xs">
              <span className="font-semibold text-emerald-700 dark:text-emerald-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>Compressed to {estimatedSizeMb.toFixed(1)} MB</span>
              </span>
              <a
                href={compressedBlobUrl}
                download={`compressed_${file?.name || 'video.mp4'}`}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download</span>
              </a>
            </div>
          )}
        </div>

        {/* Right 6 Cols: Compression Settings */}
        <div className="lg:col-span-6 space-y-4">
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-4 text-xs">
            <h3 className="font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[11px]">
              Compression Mode
            </h3>

            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setCompressionMode('preset')}
                className={`py-2 px-2.5 rounded-lg border font-medium text-center ${compressionMode === 'preset' ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300' : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'}`}
              >
                Quality Preset
              </button>
              <button
                onClick={() => setCompressionMode('percent')}
                className={`py-2 px-2.5 rounded-lg border font-medium text-center ${compressionMode === 'percent' ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300' : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'}`}
              >
                Percentage
              </button>
              <button
                onClick={() => setCompressionMode('targetSize')}
                className={`py-2 px-2.5 rounded-lg border font-medium text-center ${compressionMode === 'targetSize' ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300' : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'}`}
              >
                Target File Size
              </button>
            </div>

            {compressionMode === 'preset' && (
              <div className="space-y-2 pt-2">
                {[
                  { id: 'high', label: 'High Quality (Light Compression -25%)' },
                  { id: 'medium', label: 'Balanced (Standard -50% Recommended)' },
                  { id: 'low', label: 'Maximum Compression (-75% Smallest Size)' },
                  { id: 'discord', label: 'Discord Nitro Free (Fit under 8MB)' }
                ].map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setQualityPreset(p.id as typeof qualityPreset)}
                    className={`w-full p-2.5 rounded-lg border text-left font-medium transition-colors ${qualityPreset === p.id ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-900 dark:text-indigo-200' : 'border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300'}`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            )}

            {compressionMode === 'percent' && (
              <div className="space-y-2 pt-2">
                <div className="flex justify-between text-neutral-500">
                  <span>Compression Level</span>
                  <span className="font-mono tabular-nums">{compressionPercent}% reduction</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="85"
                  step="5"
                  value={compressionPercent}
                  onChange={(e) => setCompressionPercent(parseInt(e.target.value))}
                  className="w-full accent-indigo-600 h-1.5 bg-neutral-200 dark:bg-neutral-800 rounded appearance-none cursor-pointer"
                />
              </div>
            )}

            {compressionMode === 'targetSize' && (
              <div className="space-y-2 pt-2">
                <label className="block text-neutral-500">Desired Maximum File Size (MB)</label>
                <input
                  type="number"
                  min="1"
                  max={Math.floor(originalSizeMb)}
                  value={targetSizeMb}
                  onChange={(e) => setTargetSizeMb(parseFloat(e.target.value) || 1)}
                  className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-800 dark:text-neutral-200 font-mono"
                />
              </div>
            )}

            <button
              onClick={handleCompress}
              disabled={isCompressing}
              className="w-full py-2.5 mt-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Minimize2 className="w-4 h-4" />
              <span>Compress Video Now</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
