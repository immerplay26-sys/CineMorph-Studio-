import React, { useState, useRef, useEffect } from 'react';
import { ViralClipItem, SubtitleCue } from '../../types';
import { ApiService } from '../../services/api';
import { AudioProcessingEngine } from '../../services/audioProcessor';
import { useApp } from '../../context/AppContext';
import {
  Film,
  Upload,
  Play,
  Pause,
  Download,
  Sparkles,
  Scissors,
  CheckCircle2,
  Video,
  Layers,
  ArrowRight,
  Maximize
} from 'lucide-react';

export const ViralShortsMaker: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [videoName, setVideoName] = useState<string>('podcast_episode_long.mp4');
  const [duration, setDuration] = useState<number>(120);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  const [isDetecting, setIsDetecting] = useState<boolean>(false);
  const [detectedClips, setDetectedClips] = useState<ViralClipItem[]>([]);
  const [selectedClip, setSelectedClip] = useState<ViralClipItem | null>(null);

  // Reframing mode for 9:16
  const [reframeMode, setReframeMode] = useState<'center' | 'pan' | 'left' | 'right'>('center');
  const [showCaptions, setShowCaptions] = useState<boolean>(true);
  const [captionText, setCaptionText] = useState<string>('WAIT FOR THIS MOMENT');

  // Export state
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportProgress, setExportProgress] = useState<number>(0);
  const [exportedClips, setExportedClips] = useState<{ id: string; url: string; title: string }[]>([]);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const verticalCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Load demo video if none
  const loadDemoVideo = () => {
    // Generate synthetic motion video
    const demoCanvas = document.createElement('canvas');
    demoCanvas.width = 640;
    demoCanvas.height = 360;
    const ctx = demoCanvas.getContext('2d')!;

    const stream = demoCanvas.captureStream(30);
    const mediaRec = new MediaRecorder(stream, { mimeType: 'video/webm' });
    const chunks: Blob[] = [];

    mediaRec.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };

    mediaRec.onstop = () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      const url = URL.createObjectURL(blob);
      setVideoSrc(url);
      setVideoName('podcast_interview_sample.webm');
      setDuration(60);
      showToast('Loaded demo video', 'success');
    };

    mediaRec.start();

    let frame = 0;
    const totalFrames = 180; // 6 seconds loopable

    const drawDemo = () => {
      if (frame >= totalFrames) {
        mediaRec.stop();
        return;
      }
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, 640, 360);

      // Studio background
      const grad = ctx.createLinearGradient(0, 0, 640, 360);
      grad.addColorStop(0, '#1e1b4b');
      grad.addColorStop(1, '#090d16');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 640, 360);

      // Talking head speaker in center
      const bob = Math.sin(frame * 0.15) * 6;
      ctx.fillStyle = '#f87171';
      ctx.beginPath();
      ctx.arc(320, 150 + bob, 45, 0, Math.PI * 2);
      ctx.fill();

      // Speaker body
      ctx.fillStyle = '#4f46e5';
      ctx.beginPath();
      ctx.roundRect(250, 205 + bob, 140, 160, 20);
      ctx.fill();

      // Microphone
      ctx.fillStyle = '#64748b';
      ctx.fillRect(310, 220, 20, 60);
      ctx.fillStyle = '#94a3b8';
      ctx.beginPath();
      ctx.arc(320, 215, 16, 0, Math.PI * 2);
      ctx.fill();

      frame++;
      requestAnimationFrame(drawDemo);
    };

    drawDemo();
  };

  useEffect(() => {
    if (!videoSrc) {
      loadDemoVideo();
    }
  }, [videoSrc]);

  // Run AI highlight detection
  const handleDetectClips = async () => {
    setIsDetecting(true);
    try {
      const clips = await ApiService.detectClips(videoName, duration || 60);
      setDetectedClips(clips);
      if (clips.length > 0) {
        setSelectedClip(clips[0]);
        setCaptionText(clips[0].hook.toUpperCase());
        if (videoRef.current) {
          videoRef.current.currentTime = clips[0].startTime;
        }
      }
      showToast(`Detected ${clips.length} AI-highlighted moments!`, 'success');
    } catch {
      showToast('Highlight detection failed. Please retry.', 'error');
    } finally {
      setIsDetecting(false);
    }
  };

  // Run 9:16 vertical render loop
  useEffect(() => {
    const video = videoRef.current;
    const canvas = verticalCanvasRef.current;
    if (!video || !canvas) return;

    // 9:16 target aspect ratio (e.g. 540x960)
    canvas.width = 540;
    canvas.height = 960;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const renderVertical = () => {
      if (video.readyState >= 2) {
        const vw = video.videoWidth || 640;
        const vh = video.videoHeight || 360;

        // Calculate source crop window for 9:16
        // Target aspect is 9/16 = 0.5625
        const targetAspect = 9 / 16;
        let cropW = vh * targetAspect;
        let cropH = vh;

        if (cropW > vw) {
          cropW = vw;
          cropH = vw / targetAspect;
        }

        // Reframe horizontal offset
        let cropX = (vw - cropW) / 2;
        if (reframeMode === 'pan') {
          // Dynamic smooth pan between left and right
          const panFactor = (Math.sin(video.currentTime * 0.8) + 1) / 2;
          cropX = (vw - cropW) * panFactor;
        } else if (reframeMode === 'left') {
          cropX = 0;
        } else if (reframeMode === 'right') {
          cropX = vw - cropW;
        }

        const cropY = (vh - cropH) / 2;

        // Draw blurred ambient background to fill any letterbox
        ctx.save();
        ctx.filter = 'blur(20px) brightness(0.6)';
        ctx.drawImage(video, 0, 0, vw, vh, -50, -50, 640, 1060);
        ctx.restore();

        // Draw reframed video in center
        const destY = (960 - (540 / targetAspect)) / 2;
        ctx.drawImage(
          video,
          cropX,
          cropY,
          cropW,
          cropH,
          0,
          destY,
          540,
          540 / targetAspect
        );

        // Draw animated captions overlay
        if (showCaptions && captionText) {
          ctx.save();
          ctx.font = 'bold 32px "Cabinet Grotesk", sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';

          const textY = 720;
          const words = captionText.split(' ');
          const activeWordIndex = Math.floor(video.currentTime * 2.5) % words.length;

          // Background pill
          ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
          const textMetrics = ctx.measureText(captionText);
          ctx.beginPath();
          ctx.roundRect(270 - (textMetrics.width / 2) - 16, textY - 24, textMetrics.width + 32, 48, 8);
          ctx.fill();

          // Render words with active yellow highlight
          let currentX = 270 - (textMetrics.width / 2);
          for (let i = 0; i < words.length; i++) {
            const word = words[i] + ' ';
            const wordWidth = ctx.measureText(word).width;

            if (i === activeWordIndex) {
              ctx.fillStyle = '#FACC15'; // Vibrant Hormozi yellow
              ctx.shadowColor = 'rgba(250, 204, 21, 0.8)';
              ctx.shadowBlur = 10;
            } else {
              ctx.fillStyle = '#FFFFFF';
              ctx.shadowBlur = 0;
            }

            ctx.fillText(word, currentX + wordWidth / 2, textY);
            currentX += wordWidth;
          }
          ctx.restore();
        }

        // Draw safe-zone guide lines quietly if paused
        if (video.paused) {
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
          ctx.lineWidth = 1;
          ctx.setLineDash([4, 4]);
          // Safe top header
          ctx.strokeRect(30, 80, 480, 800);
          ctx.setLineDash([]);
        }
      }

      animFrameRef.current = requestAnimationFrame(renderVertical);
    };

    animFrameRef.current = requestAnimationFrame(renderVertical);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [reframeMode, showCaptions, captionText]);

  // Video time events
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onLoaded = () => setDuration(video.duration || 60);
    const onTime = () => {
      setCurrentTime(video.currentTime);
      // Loop within selected clip
      if (selectedClip && video.currentTime >= selectedClip.endTime) {
        video.currentTime = selectedClip.startTime;
      }
    };

    video.addEventListener('loadedmetadata', onLoaded);
    video.addEventListener('timeupdate', onTime);

    return () => {
      video.removeEventListener('loadedmetadata', onLoaded);
      video.removeEventListener('timeupdate', onTime);
    };
  }, [selectedClip]);

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      if (selectedClip && (video.currentTime < selectedClip.startTime || video.currentTime >= selectedClip.endTime)) {
        video.currentTime = selectedClip.startTime;
      }
      video.play().then(() => setIsPlaying(true));
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  const handleSelectClip = (clip: ViralClipItem) => {
    setSelectedClip(clip);
    setCaptionText(clip.hook.toUpperCase());
    if (videoRef.current) {
      videoRef.current.currentTime = clip.startTime;
    }
  };

  // Export current vertical 9:16 clip
  const handleExportSelectedClip = async () => {
    if (!selectedClip || !verticalCanvasRef.current || !videoRef.current) return;
    const video = videoRef.current;
    const canvas = verticalCanvasRef.current;

    setIsExporting(true);
    setExportProgress(0);
    video.pause();
    setIsPlaying(false);

    try {
      const stream = canvas.captureStream(30);
      let mimeType = 'video/webm;codecs=vp9';
      if (!MediaRecorder.isTypeSupported(mimeType)) mimeType = 'video/webm';

      const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 4_000_000 });
      const chunks: Blob[] = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };

      const clipDuration = selectedClip.endTime - selectedClip.startTime;

      recorder.onstop = () => {
        const finalBlob = new Blob(chunks, { type: mimeType });
        const url = URL.createObjectURL(finalBlob);
        setExportedClips(prev => [...prev, { id: selectedClip.id, url, title: selectedClip.title }]);

        saveProject({
          title: `Short_${selectedClip.title.slice(0, 30)}`,
          toolId: 'viral-shorts',
          duration: Math.round(clipDuration),
          resolution: '540x960 (9:16)',
          fileSize: `${(finalBlob.size / (1024 * 1024)).toFixed(2)} MB`,
          previewUrl: url
        });

        showToast(`Exported "${selectedClip.title}" successfully!`, 'success');
        setIsExporting(false);
      };

      video.currentTime = selectedClip.startTime;
      await new Promise<void>((r) => {
        const onSeek = () => {
          video.removeEventListener('seeked', onSeek);
          r();
        };
        video.addEventListener('seeked', onSeek);
      });

      recorder.start(200);
      await video.play();

      const checkEnd = () => {
        const elapsed = video.currentTime - selectedClip.startTime;
        const progress = Math.min(100, Math.floor((elapsed / clipDuration) * 100));
        setExportProgress(progress);

        if (video.currentTime >= selectedClip.endTime || video.ended) {
          video.pause();
          recorder.stop();
        } else {
          requestAnimationFrame(checkEnd);
        }
      };

      requestAnimationFrame(checkEnd);
    } catch (err) {
      console.error('Export failed:', err);
      showToast('Export failed. Please try again.', 'error');
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <Film className="w-5 h-5 text-indigo-500" />
            <span>Viral Clip & Shorts Maker</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Detects high-energy moments in long videos and crops them into 9:16 vertical Shorts with animated captions.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-200 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded-lg transition-colors border border-neutral-300 dark:border-neutral-700">
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Long Video</span>
            <input
              type="file"
              accept="video/*"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  setVideoSrc(URL.createObjectURL(file));
                  setVideoName(file.name);
                  showToast(`Uploaded "${file.name}"`, 'success');
                }
              }}
            />
          </label>

          <button
            onClick={handleDetectClips}
            disabled={isDetecting}
            className="inline-flex items-center gap-2 px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 disabled:opacity-50 rounded-lg transition-colors shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isDetecting ? 'Detecting Moments...' : 'AI Detect Highlights'}</span>
          </button>
        </div>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 5 Cols: Vertical 9:16 Live Preview */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div className="relative w-full max-w-[320px] aspect-[9/16] bg-neutral-950 rounded-2xl overflow-hidden border-2 border-neutral-800 shadow-2xl flex items-center justify-center">
            {videoSrc && (
              <video
                ref={videoRef}
                src={videoSrc}
                playsInline
                className="hidden"
                crossOrigin="anonymous"
              />
            )}

            <canvas
              ref={verticalCanvasRef}
              className="w-full h-full object-cover"
            />

            {/* Exporting progress overlay */}
            {isExporting && (
              <div className="absolute inset-0 bg-neutral-950/85 backdrop-blur-md z-30 flex flex-col items-center justify-center p-4 text-center space-y-3">
                <div className="w-10 h-10 border-3 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                <p className="text-xs font-semibold text-white">Exporting 9:16 Short...</p>
                <div className="w-48 bg-neutral-800 rounded-full h-2 overflow-hidden">
                  <div className="bg-indigo-500 h-full" style={{ width: `${exportProgress}%` }}></div>
                </div>
                <span className="text-[11px] font-mono text-indigo-400">{exportProgress}%</span>
              </div>
            )}
          </div>

          {/* Player controls */}
          <div className="w-full max-w-[320px] mt-3 flex items-center justify-between gap-3 p-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs">
            <button
              onClick={togglePlay}
              className="p-1.5 text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>
            <span className="font-mono text-neutral-400 text-[11px]">
              {Math.floor(currentTime)}s / {Math.floor(duration)}s
            </span>
            <button
              onClick={handleExportSelectedClip}
              disabled={!selectedClip || isExporting}
              className="px-3 py-1.5 font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg flex items-center gap-1.5 text-[11px]"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Short</span>
            </button>
          </div>
        </div>

        {/* Right 7 Cols: Reframing Controls & Detected Clips List */}
        <div className="lg:col-span-7 space-y-5">
          {/* Smart Reframing & Caption Settings */}
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3.5 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-100 dark:border-neutral-800">
              <span className="font-semibold text-neutral-900 dark:text-neutral-100">
                9:16 Vertical Reframing & Subtitles
              </span>
              <span className="text-neutral-500 text-[11px]">TikTok & Shorts Ready</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'center', label: 'Center Lock' },
                { id: 'pan', label: 'Auto Smooth Pan' },
                { id: 'left', label: 'Left Bias' },
                { id: 'right', label: 'Right Bias' }
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setReframeMode(item.id as unknown as typeof reframeMode)}
                  className={`px-3 py-2 rounded-lg border text-center font-medium transition-colors ${reframeMode === item.id ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300' : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'}`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="pt-2 flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer text-neutral-700 dark:text-neutral-300">
                <input
                  type="checkbox"
                  checked={showCaptions}
                  onChange={(e) => setShowCaptions(e.target.checked)}
                  className="rounded accent-indigo-600"
                />
                <span>Burn-in Animated Karaoke Subtitles</span>
              </label>

              <input
                type="text"
                value={captionText}
                onChange={(e) => setCaptionText(e.target.value)}
                placeholder="Hook text on screen"
                className="px-2.5 py-1 text-xs bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg max-w-[200px]"
              />
            </div>
          </div>

          {/* AI Detected Clips List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-900 dark:text-neutral-200">
                Detected Highlight Clips ({detectedClips.length})
              </h3>
              {detectedClips.length === 0 && (
                <button
                  onClick={handleDetectClips}
                  className="text-indigo-500 hover:text-indigo-400 text-xs font-medium"
                >
                  Click to scan moments →
                </button>
              )}
            </div>

            {detectedClips.length === 0 ? (
              <div className="p-8 text-center border-2 border-dashed border-neutral-200 dark:border-neutral-800 rounded-xl space-y-2">
                <Scissors className="w-8 h-8 text-neutral-400 mx-auto" />
                <p className="text-sm font-medium text-neutral-700 dark:text-neutral-300">
                  No clips extracted yet
                </p>
                <p className="text-xs text-neutral-500">
                  Click &ldquo;AI Detect Highlights&rdquo; above to automatically detect high-retention segments.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {detectedClips.map((clip) => {
                  const isSelected = selectedClip?.id === clip.id;
                  return (
                    <div
                      key={clip.id}
                      onClick={() => handleSelectClip(clip)}
                      className={`p-3.5 rounded-xl border cursor-pointer transition-all ${isSelected ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 shadow-md' : 'border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 hover:border-neutral-300 dark:hover:border-neutral-700'}`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-xs text-neutral-900 dark:text-neutral-100">
                              {clip.title}
                            </span>
                            <span className="text-[10px] font-mono text-neutral-500">
                              {clip.startTime}s - {clip.endTime}s ({clip.duration}s)
                            </span>
                          </div>
                          <p className="text-xs text-indigo-600 dark:text-indigo-400 font-medium">
                            Hook: &ldquo;{clip.hook}&rdquo;
                          </p>
                          <p className="text-[11px] text-neutral-500 leading-snug">
                            {clip.rationale}
                          </p>
                        </div>

                        <div className="text-right shrink-0">
                          <span className="text-xs font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                            {clip.viralScore} Score
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Exported Clips Shelf */}
          {exportedClips.length > 0 && (
            <div className="p-4 bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-300 dark:border-emerald-900/40 rounded-xl space-y-3">
              <h4 className="text-xs font-semibold text-emerald-700 dark:text-emerald-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>Ready for Social Media Download ({exportedClips.length})</span>
              </h4>
              <div className="space-y-2">
                {exportedClips.map((item) => (
                  <div key={item.id} className="flex items-center justify-between text-xs p-2 bg-white dark:bg-neutral-900 rounded-lg border border-neutral-200 dark:border-neutral-800">
                    <span className="truncate max-w-[280px] font-medium text-neutral-800 dark:text-neutral-200">{item.title}</span>
                    <a
                      href={item.url}
                      download={`Short_${item.id}.webm`}
                      className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-semibold flex items-center gap-1 shrink-0"
                    >
                      <Download className="w-3 h-3" />
                      <span>Download 9:16</span>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
