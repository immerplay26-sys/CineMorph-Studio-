import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Image as ImageIcon,
  Upload,
  Download,
  Type,
  Palette,
  Sparkles,
  Layers,
  RotateCcw
} from 'lucide-react';

export const ThumbnailStudioTool: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [aspect, setAspect] = useState<'16:9' | '9:16' | '1:1'>('16:9');
  const [headline, setHeadline] = useState<string>('HOW I BUILT THIS IN 24H');
  const [subline, setSubline] = useState<string>('STEP BY STEP BLUEPRINT');
  const [fontFamily, setFontFamily] = useState<string>('Cabinet Grotesk');
  const [textColor, setTextColor] = useState<string>('#FACC15'); // High CTR yellow
  const [hasStroke, setHasStroke] = useState<boolean>(true);
  const [bgColor, setBgColor] = useState<string>('#090D16');
  const [bgImage, setBgImage] = useState<HTMLImageElement | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const width = aspect === '16:9' ? 1280 : aspect === '9:16' ? 720 : 1080;
  const height = aspect === '16:9' ? 720 : aspect === '9:16' ? 1280 : 1080;

  // Render thumbnail canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = width;
    canvas.height = height;

    // 1. Background
    if (bgImage) {
      ctx.drawImage(bgImage, 0, 0, width, height);
      // Dark gradient overlay for text readability
      const grad = ctx.createLinearGradient(0, height * 0.4, 0, height);
      grad.addColorStop(0, 'rgba(0,0,0,0)');
      grad.addColorStop(1, 'rgba(0,0,0,0.85)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
    } else {
      // Dynamic dark gradient
      const grad = ctx.createRadialGradient(width / 2, height / 2, 50, width / 2, height / 2, width / 1.5);
      grad.addColorStop(0, '#1e1b4b');
      grad.addColorStop(1, bgColor);
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Glowing corner accent
      const glow = ctx.createRadialGradient(width, 0, 10, width, 0, 400);
      glow.addColorStop(0, 'rgba(99, 102, 241, 0.4)');
      glow.addColorStop(1, 'rgba(99, 102, 241, 0)');
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, width, height);
    }

    // 2. Headline with 3D shadow & stroke
    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    const mainSize = aspect === '9:16' ? 52 : 72;
    ctx.font = `900 ${mainSize}px "${fontFamily}", sans-serif`;

    const centerY = height * 0.5;

    if (hasStroke) {
      ctx.lineWidth = 14;
      ctx.strokeStyle = '#000000';
      ctx.lineJoin = 'miter';
      ctx.miterLimit = 2;
      ctx.strokeText(headline.toUpperCase(), width / 2, centerY);
    }

    ctx.fillStyle = textColor;
    ctx.fillText(headline.toUpperCase(), width / 2, centerY);

    // 3. Subline with dark badge
    if (subline) {
      const subSize = aspect === '9:16' ? 32 : 38;
      ctx.font = `800 ${subSize}px "${fontFamily}", sans-serif`;
      const subY = centerY + 80;

      const metrics = ctx.measureText(subline.toUpperCase());
      ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
      ctx.beginPath();
      ctx.roundRect(width / 2 - metrics.width / 2 - 20, subY - 28, metrics.width + 40, 56, 8);
      ctx.fill();

      ctx.fillStyle = '#FFFFFF';
      ctx.fillText(subline.toUpperCase(), width / 2, subY);
    }

    ctx.restore();
  }, [width, height, headline, subline, fontFamily, textColor, hasStroke, bgColor, bgImage, aspect]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const img = new Image();
      img.onload = () => {
        setBgImage(img);
        showToast('Background image loaded onto canvas', 'success');
      };
      img.src = URL.createObjectURL(file);
    }
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `thumbnail_${aspect.replace(':', 'x')}.png`;
        a.click();

        saveProject({
          title: `Thumbnail_${headline.slice(0, 15)}`,
          toolId: 'thumbnail',
          resolution: `${width}x${height}`,
          previewUrl: url
        });

        showToast('Thumbnail exported successfully in 1080p!', 'success');
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <ImageIcon className="w-5 h-5 text-indigo-500" />
            <span>AI Thumbnail & Graphic Studio</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Design high-CTR clickable thumbnails with 3D text strokes, high-contrast badges, background images, and social presets.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDownload}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export High-Res PNG</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 Cols: Canvas Viewport */}
        <div className="lg:col-span-7 flex flex-col items-center">
          <div className="max-w-full overflow-hidden rounded-xl border border-neutral-800 shadow-2xl bg-neutral-950 p-2 flex items-center justify-center">
            <canvas ref={canvasRef} className="max-h-[460px] w-auto max-w-full object-contain" />
          </div>
          <span className="text-[11px] font-mono text-neutral-500 mt-2">
            {width} x {height} ({aspect})
          </span>
        </div>

        {/* Right 5 Cols: Thumbnail Controls */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3.5 text-xs">
            <h3 className="font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[11px]">
              Preset Canvas Aspect Ratio
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: '16:9', label: 'YouTube (16:9)' },
                { id: '9:16', label: 'Shorts/TikTok' },
                { id: '1:1', label: 'Square (1:1)' }
              ].map((p) => (
                <button
                  key={p.id}
                  onClick={() => setAspect(p.id as typeof aspect)}
                  className={`py-2 rounded-lg border text-center font-medium ${aspect === p.id ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-semibold' : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'}`}
                >
                  {p.label}
                </button>
              ))}
            </div>

            <div className="space-y-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
              <label className="text-neutral-600 dark:text-neutral-400 block font-medium">Headline Text (Short & Punchy)</label>
              <input
                type="text"
                value={headline}
                onChange={(e) => setHeadline(e.target.value)}
                className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100 font-bold"
              />
            </div>

            <div className="space-y-2">
              <label className="text-neutral-600 dark:text-neutral-400 block font-medium">Subline / Badge Text</label>
              <input
                type="text"
                value={subline}
                onChange={(e) => setSubline(e.target.value)}
                className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100"
              />
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <label className="text-neutral-500 block mb-1">Text Color</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={textColor}
                    onChange={(e) => setTextColor(e.target.value)}
                    className="w-8 h-8 rounded border border-neutral-300 dark:border-neutral-700 cursor-pointer"
                  />
                  <span className="font-mono text-[11px] text-neutral-500">{textColor}</span>
                </div>
              </div>

              <div>
                <label className="text-neutral-500 block mb-1">Heavy Black Outline</label>
                <label className="flex items-center gap-2 cursor-pointer mt-1 text-neutral-700 dark:text-neutral-300">
                  <input
                    type="checkbox"
                    checked={hasStroke}
                    onChange={(e) => setHasStroke(e.target.checked)}
                    className="rounded accent-indigo-600"
                  />
                  <span>High-CTR Stroke</span>
                </label>
              </div>
            </div>

            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800">
              <label className="cursor-pointer w-full py-2.5 px-3 border border-neutral-300 dark:border-neutral-700 hover:border-indigo-500 rounded-lg flex items-center justify-center gap-2 font-medium text-neutral-700 dark:text-neutral-300 transition-colors">
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Custom Photo Background</span>
                <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
