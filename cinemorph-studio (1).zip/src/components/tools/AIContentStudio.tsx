import React, { useState } from 'react';
import { AI_CONTENT_TOOLS } from '../../constants/defaults';
import { AIContentToolMeta } from '../../types';
import { ApiService } from '../../services/api';
import { useApp } from '../../context/AppContext';
import {
  FileText,
  Sparkles,
  Copy,
  Check,
  RotateCcw,
  Layers,
  Send
} from 'lucide-react';

export const AIContentStudio: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [selectedTool, setSelectedTool] = useState<AIContentToolMeta>(AI_CONTENT_TOOLS[0]);
  const [formInputs, setFormInputs] = useState<Record<string, string>>({});
  const [generatedResult, setGeneratedResult] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isCopied, setIsCopied] = useState<boolean>(false);

  const handleSelectTool = (tool: AIContentToolMeta) => {
    setSelectedTool(tool);
    setFormInputs({});
    setGeneratedResult('');
  };

  const handleInputChange = (name: string, val: string) => {
    setFormInputs((prev) => ({ ...prev, [name]: val }));
  };

  const handleGenerate = async () => {
    // Fill prompt template with user inputs
    let prompt = selectedTool.promptTemplate;
    for (const input of selectedTool.inputs) {
      const val = formInputs[input.name] || input.defaultValue || '';
      prompt = prompt.replace(`{${input.name}}`, val);
    }

    setIsLoading(true);
    try {
      const output = await ApiService.generateContent(prompt, selectedTool.id);
      setGeneratedResult(output);

      saveProject({
        title: `${selectedTool.name} Output`,
        toolId: 'content',
        metadata: { toolId: selectedTool.id, output }
      });

      showToast(`Generated ${selectedTool.name} successfully!`, 'success');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Generation failed';
      showToast(msg, 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (!generatedResult) return;
    navigator.clipboard.writeText(generatedResult);
    setIsCopied(true);
    showToast('Copied to clipboard!', 'success');
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-500" />
            <span>AI Content & Script Studio</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            16 specialized creator AI engines for video scripts, viral hooks, high-CTR titles, captions, hashtags, and social repurposing.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 4 Cols: 16 AI Tools Directory */}
        <div className="lg:col-span-4 space-y-4">
          <div className="p-3 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-2">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-500 px-2 py-1">
              Select AI Engine (16 Available)
            </h3>
            <div className="space-y-1 max-h-[560px] overflow-y-auto pr-1">
              {AI_CONTENT_TOOLS.map((tool) => {
                const isSelected = selectedTool.id === tool.id;
                return (
                  <button
                    key={tool.id}
                    onClick={() => handleSelectTool(tool)}
                    className={`w-full p-2.5 rounded-lg border text-left text-xs transition-colors flex items-center justify-between ${isSelected ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-900 dark:text-indigo-200 font-semibold' : 'border-transparent hover:border-neutral-200 dark:hover:border-neutral-800 text-neutral-700 dark:text-neutral-300'}`}
                  >
                    <div className="truncate">
                      <div>{tool.name}</div>
                      <div className="text-[10px] text-neutral-400 font-normal">{tool.category}</div>
                    </div>
                    {isSelected && <Sparkles className="w-3.5 h-3.5 text-indigo-600 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right 8 Cols: Input Form & Generated Output */}
        <div className="lg:col-span-8 space-y-4">
          <div className="p-5 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
              <div>
                <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
                  {selectedTool.name}
                </h3>
                <p className="text-xs text-neutral-500 mt-0.5">{selectedTool.description}</p>
              </div>
              <span className="text-[11px] text-indigo-500 font-mono font-medium">Gemini 3.8 Flash</span>
            </div>

            {/* Dynamic Form Inputs */}
            <div className="space-y-3.5">
              {selectedTool.inputs.map((input) => (
                <div key={input.name} className="space-y-1 text-xs">
                  <label className="font-medium text-neutral-700 dark:text-neutral-300">
                    {input.label}
                  </label>

                  {input.type === 'text' && (
                    <input
                      type="text"
                      placeholder={input.placeholder}
                      value={formInputs[input.name] || ''}
                      onChange={(e) => handleInputChange(input.name, e.target.value)}
                      className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100 focus:outline-none focus:border-indigo-500 text-xs"
                    />
                  )}

                  {input.type === 'textarea' && (
                    <textarea
                      rows={4}
                      placeholder={input.placeholder}
                      value={formInputs[input.name] || ''}
                      onChange={(e) => handleInputChange(input.name, e.target.value)}
                      className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100 focus:outline-none focus:border-indigo-500 text-xs resize-none"
                    />
                  )}

                  {input.type === 'select' && input.options && (
                    <select
                      value={formInputs[input.name] || input.options[0]}
                      onChange={(e) => handleInputChange(input.name, e.target.value)}
                      className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100 text-xs"
                    >
                      {input.options.map((opt) => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  )}
                </div>
              ))}
            </div>

            <button
              onClick={handleGenerate}
              disabled={isLoading}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold text-xs flex items-center justify-center gap-2 disabled:opacity-50 shadow-sm"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isLoading ? 'Generating with Gemini AI...' : 'Generate Creator Output'}</span>
            </button>
          </div>

          {/* Result Output Shelf */}
          {generatedResult && (
            <div className="p-5 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-neutral-100 dark:border-neutral-800">
                <span className="text-xs font-semibold text-neutral-900 dark:text-neutral-100">
                  AI Generated Result
                </span>
                <button
                  onClick={copyToClipboard}
                  className="flex items-center gap-1.5 px-3 py-1 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-300 rounded text-xs font-medium"
                >
                  {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{isCopied ? 'Copied!' : 'Copy Text'}</span>
                </button>
              </div>

              <div className="p-4 bg-neutral-50 dark:bg-neutral-950 rounded-lg border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-800 dark:text-neutral-200 whitespace-pre-wrap font-sans leading-relaxed max-h-96 overflow-y-auto">
                {generatedResult}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
