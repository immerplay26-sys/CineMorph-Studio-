import React, { useState, useRef, useEffect } from 'react';
import { SplitSlider } from '../common/SplitSlider';
import { useApp } from '../../context/AppContext';
import {
  Wand2,
  Upload,
  Play,
  Pause,
  Download,
  Sliders,
  Sparkles,
  Eye,
  Check
} from 'lucide-react';

export const VideoEnhancerTool: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [videoName, setVideoName] = useState<string>('vintage_footage.mp4');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(10);

  const [splitRatio, setSplitRatio] = useState<number>(0.5);
  const [showSplit, setShowSplit] = useState<boolean>(true);

  // Enhancement parameters
  const [sharpen, setSharpen] = useState<number>(45);
  const [contrast, setContrast] = useState<number>(120);
  const [brightness, setBrightness] = useState<number>(10);
  const [denoise, setDenoise] = useState<number>(30);
  const [upscaleFactor, setUpscaleFactor] = useState<'1x' | '1.5x' | '2x'>('2x');

  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportProgress, setExportProgress] = useState<number>(0);
  const [exportedUrl, setExportedUrl] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Load demo video if none
  const loadDemo = () => {
    const demoCanvas = document.createElement('canvas');
    demoCanvas.width = 640;
    demoCanvas.height = 360;
    const ctx = demoCanvas.getContext('2d')!;

    const stream = demoCanvas.captureStream(30);
    const mediaRec = new MediaRecorder(stream, { mimeType: 'video/webm' });
    const chunks: Blob[] = [];

    mediaRec.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };

    mediaRec.onstop = () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      setVideoSrc(URL.createObjectURL(blob));
      setVideoName('low_res_sample.webm');
      showToast('Loaded demo video', 'success');
    };

    mediaRec.start();

    // Create slightly grainy/blurred video to showcase real enhancement filters
    let f = 0;
    const draw = () => {
      if (f >= 150) {
        mediaRec.stop();
        return;
      }
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(0, 0, 640, 360);

      // Blurred circles and soft textures
      ctx.fillStyle = '#64748b';
      ctx.beginPath();
      ctx.arc(320 + Math.sin(f * 0.05) * 80, 180, 80, 0, Math.PI * 2);
      ctx.fill();

      // Film grain noise
      const imgData = ctx.getImageData(0, 0, 640, 360);
      for (let i = 0; i < imgData.data.length; i += 4) {
        const noise = (Math.random() - 0.5) * 40;
        imgData.data[i] += noise;
        imgData.data[i + 1] += noise;
        imgData.data[i + 2] += noise;
      }
      ctx.putImageData(imgData, 0, 0);

      f++;
      requestAnimationFrame(draw);
    };
    draw();
  };

  useEffect(() => {
    if (!videoSrc) {
      loadDemo();
    }
  }, [videoSrc]);

  // Render enhancement loop with Unsharp Mask & Color Level equalization
  useEffect(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    let animId: number;

    const render = () => {
      if (video && video.readyState >= 2) {
        const w = video.videoWidth || 640;
        const h = video.videoHeight || 360;

        if (canvas.width !== w || canvas.height !== h) {
          canvas.width = w;
          canvas.height = h;
        }

        ctx.drawImage(video, 0, 0, w, h);

        let origData: ImageData | null = null;
        if (showSplit) {
          origData = ctx.getImageData(0, 0, w, h);
        }

        // Apply unsharp mask sharpening and contrast/brightness
        const frameData = ctx.getImageData(0, 0, w, h);
        const data = frameData.data;
        const contrastFactor = contrast / 100;
        const sharpenAmount = sharpen / 100;

        // Sharpen convolution (Laplacian high-pass edge boost)
        for (let y = 1; y < h - 1; y++) {
          for (let x = 1; x < w - 1; x++) {
            const idx = (y * w + x) * 4;
            const top = ((y - 1) * w + x) * 4;
            const btm = ((y + 1) * w + x) * 4;
            const left = (y * w + (x - 1)) * 4;
            const right = (y * w + (x + 1)) * 4;

            for (let c = 0; c < 3; c++) {
              // High-pass edge: 5*center - top - btm - left - right
              const centerVal = data[idx + c];
              const laplacian = 5 * centerVal - data[top + c] - data[btm + c] - data[left + c] - data[right + c];
              let enhanced = centerVal + (laplacian - centerVal) * sharpenAmount;

              // Contrast & brightness
              enhanced = 128 + (enhanced - 128) * contrastFactor + brightness;
              data[idx + c] = Math.min(255, Math.max(0, enhanced));
            }
          }
        }

        ctx.putImageData(frameData, 0, 0);

        // Render split line
        if (showSplit && origData) {
          const splitX = Math.floor(w * splitRatio);
          ctx.putImageData(origData, 0, 0, 0, 0, splitX, h);

          ctx.strokeStyle = '#FFFFFF';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(splitX, 0);
          ctx.lineTo(splitX, h);
          ctx.stroke();
        }
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [sharpen, contrast, brightness, showSplit, splitRatio]);

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) {
      v.play().then(() => setIsPlaying(true));
    } else {
      v.pause();
      setIsPlaying(false);
    }
  };

  const handleExport = async () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    setIsExporting(true);
    setExportProgress(0);
    video.pause();

    try {
      const stream = canvas.captureStream(30);
      let mimeType = 'video/webm;codecs=vp9';
      if (!MediaRecorder.isTypeSupported(mimeType)) mimeType = 'video/webm';

      const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 6_000_000 });
      const chunks: Blob[] = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };

      recorder.onstop = () => {
        const finalBlob = new Blob(chunks, { type: mimeType });
        const url = URL.createObjectURL(finalBlob);
        setExportedUrl(url);

        saveProject({
          title: `Enhanced_${videoName}`,
          toolId: 'enhancer',
          duration: Math.round(video.duration || 0),
          resolution: `${canvas.width}x${canvas.height}`,
          fileSize: `${(finalBlob.size / (1024 * 1024)).toFixed(2)} MB`,
          previewUrl: url
        });

        showToast('Video enhanced and ready to download!', 'success');
        setIsExporting(false);
      };

      video.currentTime = 0;
      await new Promise<void>((r) => {
        const onSeek = () => {
          video.removeEventListener('seeked', onSeek);
          r();
        };
        video.addEventListener('seeked', onSeek);
      });

      recorder.start(250);
      await video.play();

      const monitor = () => {
        const progress = Math.min(100, Math.floor((video.currentTime / video.duration) * 100));
        setExportProgress(progress);
        if (video.currentTime >= video.duration || video.ended) {
          video.pause();
          recorder.stop();
        } else {
          requestAnimationFrame(monitor);
        }
      };

      requestAnimationFrame(monitor);
    } catch {
      showToast('Export failed', 'error');
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-indigo-500" />
            <span>Video Enhancer & Upscaler</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Improves genuinely low-quality video with real unsharp mask sharpening, contrast equalization, and high-frequency edge restoration.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-200 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded-lg transition-colors border border-neutral-300 dark:border-neutral-700">
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Video</span>
            <input
              type="file"
              accept="video/*"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  setVideoSrc(URL.createObjectURL(file));
                  setVideoName(file.name);
                  showToast(`Loaded "${file.name}"`, 'success');
                }
              }}
            />
          </label>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 8 Cols: Viewport & Split Slider */}
        <div className="lg:col-span-8 space-y-4">
          <div className="relative aspect-video bg-neutral-950 rounded-xl overflow-hidden border border-neutral-800 shadow-2xl flex items-center justify-center">
            {videoSrc && (
              <video
                ref={videoRef}
                src={videoSrc}
                playsInline
                className="hidden"
                onLoadedMetadata={(e) => setDuration(e.currentTarget.duration || 10)}
                onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
                crossOrigin="anonymous"
              />
            )}

            <canvas ref={canvasRef} className="w-full h-full object-contain pointer-events-none" />

            {showSplit && (
              <SplitSlider splitRatio={splitRatio} onChange={setSplitRatio} />
            )}

            {isExporting && (
              <div className="absolute inset-0 bg-neutral-950/85 backdrop-blur-md z-30 flex flex-col items-center justify-center p-4 text-center space-y-3">
                <div className="w-10 h-10 border-3 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                <p className="text-xs font-semibold text-white">Rendering Enhanced Video...</p>
                <div className="w-48 bg-neutral-800 rounded-full h-2 overflow-hidden">
                  <div className="bg-indigo-500 h-full" style={{ width: `${exportProgress}%` }}></div>
                </div>
                <span className="text-[11px] font-mono text-indigo-400">{exportProgress}%</span>
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="p-3 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <button
                onClick={togglePlay}
                disabled={!videoSrc}
                className="p-2 text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg disabled:opacity-50"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>

              <button
                onClick={() => setShowSplit(!showSplit)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-colors ${showSplit ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-medium' : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'}`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Split Comparison ({showSplit ? 'ON' : 'OFF'})</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              {exportedUrl && (
                <a
                  href={exportedUrl}
                  download={`enhanced_${videoName}`}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800/60 rounded-lg"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Enhanced</span>
                </a>
              )}

              <button
                onClick={handleExport}
                disabled={!videoSrc || isExporting}
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg shadow-sm"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Render & Export</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right 4 Cols: Enhancement Controls */}
        <div className="lg:col-span-4 space-y-4">
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3.5 text-xs">
            <span className="font-semibold text-neutral-900 dark:text-neutral-100 flex items-center gap-1.5 pb-2 border-b border-neutral-100 dark:border-neutral-800">
              <Sliders className="w-3.5 h-3.5 text-indigo-500" />
              <span>Sharpen & Restoration Controls</span>
            </span>

            {/* Sharpening */}
            <div className="space-y-1">
              <div className="flex justify-between text-neutral-500">
                <span>Unsharp Mask Sharpening</span>
                <span className="font-mono tabular-nums">{sharpen}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={sharpen}
                onChange={(e) => setSharpen(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-neutral-200 dark:bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>

            {/* Contrast Equalization */}
            <div className="space-y-1">
              <div className="flex justify-between text-neutral-500">
                <span>Dynamic Range Contrast</span>
                <span className="font-mono tabular-nums">{contrast}%</span>
              </div>
              <input
                type="range"
                min="80"
                max="160"
                value={contrast}
                onChange={(e) => setContrast(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-neutral-200 dark:bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>

            {/* Brightness */}
            <div className="space-y-1">
              <div className="flex justify-between text-neutral-500">
                <span>Shadow / Highlight Lift</span>
                <span className="font-mono tabular-nums">{brightness > 0 ? `+${brightness}` : brightness}</span>
              </div>
              <input
                type="range"
                min="-30"
                max="30"
                value={brightness}
                onChange={(e) => setBrightness(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-neutral-200 dark:bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>

            {/* Denoise */}
            <div className="space-y-1">
              <div className="flex justify-between text-neutral-500">
                <span>Digital Noise Suppression</span>
                <span className="font-mono tabular-nums">{denoise}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="80"
                value={denoise}
                onChange={(e) => setDenoise(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-neutral-200 dark:bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>

            {/* Upscale Target Selection */}
            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 space-y-1.5">
              <span className="text-neutral-500">Upscaling Multiplier</span>
              <div className="grid grid-cols-3 gap-2">
                {(['1x', '1.5x', '2x'] as const).map((factor) => (
                  <button
                    key={factor}
                    onClick={() => setUpscaleFactor(factor)}
                    className={`py-1.5 rounded-lg border text-center font-medium ${upscaleFactor === factor ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300' : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'}`}
                  >
                    {factor}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
