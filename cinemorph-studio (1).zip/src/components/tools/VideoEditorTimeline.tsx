import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { TimelineTrack, TimelineTrackItem } from '../../types';
import {
  Scissors,
  Play,
  Pause,
  Plus,
  Trash2,
  Copy,
  RotateCw,
  Volume2,
  VolumeX,
  Type,
  Download,
  Upload,
  Undo2,
  Redo2,
  Sparkles,
  Sliders,
  ZoomIn,
  ZoomOut,
  Maximize2
} from 'lucide-react';

export const VideoEditorTimeline: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [tracks, setTracks] = useState<TimelineTrack[]>([
    { id: 'v1', name: 'Video 1 (Base)', type: 'video', muted: false, locked: false, visible: true },
    { id: 't1', name: 'Text & Titles', type: 'overlay', muted: false, locked: false, visible: true },
    { id: 'a1', name: 'Audio Track', type: 'audio', muted: false, locked: false, visible: true }
  ]);

  const [items, setItems] = useState<TimelineTrackItem[]>([
    {
      id: 'clip_1',
      trackId: 'v1',
      type: 'video',
      name: 'Main Footage',
      startTime: 0,
      duration: 12,
      sourceOffset: 0,
      speed: 1,
      volume: 1,
      opacity: 1,
      rotation: 0,
      scale: 1,
      x: 0,
      y: 0
    },
    {
      id: 'txt_1',
      trackId: 't1',
      type: 'text',
      name: 'Title Overlay',
      startTime: 1,
      duration: 5,
      sourceOffset: 0,
      speed: 1,
      volume: 1,
      opacity: 1,
      rotation: 0,
      scale: 1,
      x: 0,
      y: 0,
      textContent: 'CINEMATIC OPENING',
      fontSize: 42,
      fontFamily: 'Cabinet Grotesk',
      textColor: '#FACC15'
    }
  ]);

  const [selectedItemId, setSelectedItemId] = useState<string>('clip_1');
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [timelineDuration, setTimelineDuration] = useState<number>(20);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [zoomLevel, setZoomLevel] = useState<number>(30); // pixels per second

  // Color grading filter settings
  const [brightness, setBrightness] = useState<number>(0);
  const [contrast, setContrast] = useState<number>(100);
  const [saturation, setSaturation] = useState<number>(100);
  const [temperature, setTemperature] = useState<number>(0);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const selectedItem = items.find(i => i.id === selectedItemId);

  // Playhead update
  useEffect(() => {
    let animId: number;
    if (isPlaying) {
      const startWallTime = performance.now();
      const startTimelineTime = currentTime;

      const loop = (now: number) => {
        const elapsed = (now - startWallTime) / 1000;
        const newTime = startTimelineTime + elapsed;
        if (newTime >= timelineDuration) {
          setCurrentTime(0);
          setIsPlaying(false);
        } else {
          setCurrentTime(newTime);
          animId = requestAnimationFrame(loop);
        }
      };
      animId = requestAnimationFrame(loop);
    }
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, timelineDuration, currentTime]);

  // Canvas composite rendering loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 1280;
    canvas.height = 720;

    // Dark canvas background
    ctx.fillStyle = '#090D16';
    ctx.fillRect(0, 0, 1280, 720);

    // Find active video item at currentTime
    const activeVideo = items.find(i => i.type === 'video' && currentTime >= i.startTime && currentTime <= (i.startTime + i.duration));

    if (activeVideo) {
      // Draw procedural motion pattern / gradient video scene
      ctx.save();
      const grad = ctx.createLinearGradient(0, 0, 1280, 720);
      grad.addColorStop(0, '#1e1b4b');
      grad.addColorStop(0.5, '#312e81');
      grad.addColorStop(1, '#0f172a');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 1280, 720);

      // Geometric dynamic animated focal object
      const posX = 640 + Math.sin(currentTime * 2) * 120;
      const posY = 360 + Math.cos(currentTime * 2) * 40;

      ctx.fillStyle = '#4f46e5';
      ctx.beginPath();
      ctx.arc(posX, posY, 90, 0, Math.PI * 2);
      ctx.fill();

      // Film color adjustments
      if (contrast !== 100 || brightness !== 0 || saturation !== 100) {
        ctx.filter = `contrast(${contrast}%) brightness(${100 + brightness}%) saturate(${saturation}%)`;
      }
      ctx.restore();
    }

    // Find active text overlay item at currentTime
    const activeText = items.find(i => i.type === 'text' && currentTime >= i.startTime && currentTime <= (i.startTime + i.duration));

    if (activeText && activeText.textContent) {
      ctx.save();
      ctx.font = `bold ${activeText.fontSize || 42}px "${activeText.fontFamily || 'Cabinet Grotesk'}", sans-serif`;
      ctx.fillStyle = activeText.textColor || '#FFFFFF';
      ctx.textAlign = 'center';
      ctx.shadowColor = 'rgba(0,0,0,0.9)';
      ctx.shadowBlur = 12;
      ctx.fillText(activeText.textContent, 640, 580);
      ctx.restore();
    }
  }, [currentTime, items, brightness, contrast, saturation, temperature]);

  // Timeline operations
  const splitSelectedItem = () => {
    if (!selectedItem) return;
    if (currentTime <= selectedItem.startTime || currentTime >= (selectedItem.startTime + selectedItem.duration)) {
      showToast('Position playhead inside clip to split', 'info');
      return;
    }

    const firstDuration = currentTime - selectedItem.startTime;
    const secondDuration = selectedItem.duration - firstDuration;

    const firstClip: TimelineTrackItem = {
      ...selectedItem,
      duration: firstDuration
    };

    const secondClip: TimelineTrackItem = {
      ...selectedItem,
      id: `clip_${Date.now()}`,
      startTime: currentTime,
      duration: secondDuration,
      sourceOffset: selectedItem.sourceOffset + firstDuration
    };

    setItems(items.map(i => i.id === selectedItem.id ? firstClip : i).concat(secondClip));
    showToast('Clip split successfully at playhead', 'success');
  };

  const deleteSelectedItem = () => {
    if (!selectedItem) return;
    setItems(items.filter(i => i.id !== selectedItem.id));
    setSelectedItemId('');
    showToast('Deleted clip from timeline', 'info');
  };

  const addTextTrackItem = () => {
    const newItem: TimelineTrackItem = {
      id: `txt_${Date.now()}`,
      trackId: 't1',
      type: 'text',
      name: 'New Text',
      startTime: currentTime,
      duration: 4,
      sourceOffset: 0,
      speed: 1,
      volume: 1,
      opacity: 1,
      rotation: 0,
      scale: 1,
      x: 0,
      y: 0,
      textContent: 'ENTER TEXT HERE',
      fontSize: 38,
      fontFamily: 'Cabinet Grotesk',
      textColor: '#FFFFFF'
    };
    setItems([...items, newItem]);
    setSelectedItemId(newItem.id);
    showToast('Added text title layer', 'success');
  };

  const handleExport = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        saveProject({
          title: 'Timeline_Project_Snapshot',
          toolId: 'editor',
          duration: Math.round(timelineDuration),
          previewUrl: url,
          timelineState: { tracks, items }
        });
        const a = document.createElement('a');
        a.href = url;
        a.download = 'timeline_render.png';
        a.click();
        showToast('Exported project render!', 'success');
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <Scissors className="w-5 h-5 text-indigo-500" />
            <span>Multi-Track Timeline Video Editor</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Non-linear video editing workstation: multiple video/audio/text tracks, split, trim, ripple delete, and color grading.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={addTextTrackItem}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 rounded-lg text-xs font-semibold"
          >
            <Type className="w-3.5 h-3.5 text-indigo-500" />
            <span>+ Text Layer</span>
          </button>

          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Composition</span>
          </button>
        </div>
      </div>

      {/* Workspace: Top Half Viewport & Inspector, Bottom Half Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 8 Cols: Canvas Monitor */}
        <div className="lg:col-span-8 space-y-3">
          <div className="relative aspect-video bg-neutral-950 rounded-xl overflow-hidden border border-neutral-800 shadow-2xl flex items-center justify-center">
            <canvas ref={canvasRef} className="w-full h-full object-contain" />
          </div>

          {/* Transport Bar */}
          <div className="p-3 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="p-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>

              <button
                onClick={splitSelectedItem}
                className="p-2 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 text-neutral-700 dark:text-neutral-300 rounded-lg"
                title="Split clip at playhead"
              >
                <Scissors className="w-4 h-4" />
              </button>

              <button
                onClick={deleteSelectedItem}
                disabled={!selectedItem}
                className="p-2 bg-neutral-100 dark:bg-neutral-800 hover:bg-rose-500 hover:text-white text-neutral-500 rounded-lg disabled:opacity-40"
                title="Delete clip"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            <div className="font-mono text-neutral-400 text-xs tabular-nums">
              {currentTime.toFixed(2)}s / {timelineDuration.toFixed(2)}s
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setZoomLevel(Math.max(15, zoomLevel - 5))}
                className="p-1.5 text-neutral-500 hover:text-neutral-300"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <button
                onClick={() => setZoomLevel(Math.min(60, zoomLevel + 5))}
                className="p-1.5 text-neutral-500 hover:text-neutral-300"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Right 4 Cols: Clip Inspector & Color Controls */}
        <div className="lg:col-span-4 space-y-4">
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3.5 text-xs">
            <h3 className="font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[11px] pb-2 border-b border-neutral-100 dark:border-neutral-800">
              Inspector: {selectedItem ? selectedItem.name : 'No Clip Selected'}
            </h3>

            {selectedItem && selectedItem.type === 'text' && (
              <div className="space-y-2">
                <label className="text-neutral-500 block">Text Content</label>
                <input
                  type="text"
                  value={selectedItem.textContent || ''}
                  onChange={(e) => {
                    const txt = e.target.value;
                    setItems(items.map(i => i.id === selectedItem.id ? { ...i, textContent: txt } : i));
                  }}
                  className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100 font-bold"
                />
              </div>
            )}

            {/* Color grading controls */}
            <div className="space-y-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
              <span className="font-medium text-neutral-700 dark:text-neutral-300 block">Color & Exposure Grading</span>

              <div className="space-y-1">
                <div className="flex justify-between text-neutral-500">
                  <span>Contrast</span>
                  <span className="font-mono">{contrast}%</span>
                </div>
                <input
                  type="range"
                  min="60"
                  max="160"
                  value={contrast}
                  onChange={(e) => setContrast(parseInt(e.target.value))}
                  className="w-full accent-indigo-600 h-1 bg-neutral-200 dark:bg-neutral-800 rounded"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-neutral-500">
                  <span>Saturation</span>
                  <span className="font-mono">{saturation}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="200"
                  value={saturation}
                  onChange={(e) => setSaturation(parseInt(e.target.value))}
                  className="w-full accent-indigo-600 h-1 bg-neutral-200 dark:bg-neutral-800 rounded"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-neutral-500">
                  <span>Exposure / Brightness</span>
                  <span className="font-mono">{brightness}</span>
                </div>
                <input
                  type="range"
                  min="-40"
                  max="40"
                  value={brightness}
                  onChange={(e) => setBrightness(parseInt(e.target.value))}
                  className="w-full accent-indigo-600 h-1 bg-neutral-200 dark:bg-neutral-800 rounded"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Multi-Track Interactive Timeline Viewport */}
      <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3">
        <div className="flex items-center justify-between text-xs text-neutral-500 pb-2 border-b border-neutral-100 dark:border-neutral-800">
          <span className="font-semibold text-neutral-800 dark:text-neutral-200">Timeline Tracks ({tracks.length})</span>
          <span className="font-mono">Zoom: {zoomLevel} px/sec</span>
        </div>

        {/* Timeline Tracks Rows */}
        <div className="space-y-2 overflow-x-auto pb-4 relative min-h-[160px]">
          {/* Vertical Playhead line */}
          <div
            className="absolute top-0 bottom-0 w-0.5 bg-rose-500 z-20 pointer-events-none shadow-md"
            style={{ left: `${currentTime * zoomLevel + 160}px` }}
          >
            <div className="w-2.5 h-2.5 bg-rose-500 rounded-full -translate-x-[4px] -top-1"></div>
          </div>

          {tracks.map((track) => (
            <div key={track.id} className="flex items-center gap-2">
              {/* Track Header Header */}
              <div className="w-40 p-2 bg-neutral-100 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-xs shrink-0 flex items-center justify-between">
                <span className="font-medium truncate">{track.name}</span>
                <span className="text-[10px] uppercase text-neutral-400 font-mono">{track.type}</span>
              </div>

              {/* Track Lane */}
              <div
                className="flex-1 h-12 bg-neutral-50 dark:bg-neutral-950/60 rounded-lg border border-neutral-200 dark:border-neutral-800 relative cursor-pointer overflow-hidden"
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const clickX = e.clientX - rect.left;
                  const newTime = Math.max(0, Math.min(timelineDuration, clickX / zoomLevel));
                  setCurrentTime(newTime);
                }}
              >
                {/* Clips positioned on this track */}
                {items.filter(i => i.trackId === track.id).map((item) => {
                  const isSelected = selectedItemId === item.id;
                  const itemWidth = item.duration * zoomLevel;
                  const itemLeft = item.startTime * zoomLevel;

                  return (
                    <div
                      key={item.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedItemId(item.id);
                      }}
                      className={`absolute top-1 bottom-1 rounded-md px-2.5 flex items-center justify-between text-xs font-medium cursor-move border transition-all ${isSelected ? 'border-white bg-indigo-600 text-white shadow-lg z-10' : 'border-indigo-400/30 bg-indigo-500/20 text-indigo-200 hover:bg-indigo-500/30'}`}
                      style={{
                        left: `${itemLeft}px`,
                        width: `${itemWidth}px`
                      }}
                    >
                      <span className="truncate text-[11px]">{item.name}</span>
                      <span className="text-[10px] font-mono opacity-75 shrink-0">{item.duration}s</span>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
