import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Maximize2,
  Upload,
  Play,
  Pause,
  Download,
  Share2
} from 'lucide-react';

export const VideoResizerTool: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [videoName, setVideoName] = useState<string>('clip_to_format.mp4');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  const [aspectPreset, setAspectPreset] = useState<string>('9:16');
  const [fitMode, setFitMode] = useState<'blur' | 'crop' | 'black'>('blur');

  const [customW, setCustomW] = useState<number>(1080);
  const [customH, setCustomH] = useState<number>(1920);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const presets = [
    { id: '16:9', label: 'YouTube / Landscape', aspect: '16:9', w: 1920, h: 1080, icon: 'YouTube' },
    { id: '9:16', label: 'Shorts / TikTok / Reels', aspect: '9:16', w: 1080, h: 1920, icon: 'Vertical' },
    { id: '1:1', label: 'Instagram Square / Post', aspect: '1:1', w: 1080, h: 1080, icon: 'Square' },
    { id: '4:5', label: 'Instagram Portrait', aspect: '4:5', w: 1080, h: 1350, icon: 'Feed' },
    { id: 'custom', label: 'Custom Dimension', aspect: 'custom', w: customW, h: customH, icon: 'Custom' }
  ];

  // Render video into canvas with chosen fit mode (blurred padding, crop, black bars)
  useEffect(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let targetW = 1080;
    let targetH = 1920;

    const matched = presets.find(p => p.id === aspectPreset);
    if (matched) {
      targetW = matched.w;
      targetH = matched.h;
    } else {
      targetW = customW;
      targetH = customH;
    }

    canvas.width = targetW;
    canvas.height = targetH;

    let animId: number;

    const render = () => {
      if (video && video.readyState >= 2) {
        const vw = video.videoWidth || 640;
        const vh = video.videoHeight || 360;

        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, targetW, targetH);

        if (fitMode === 'blur') {
          // Draw blurred zoomed background
          ctx.save();
          ctx.filter = 'blur(25px) brightness(0.6)';
          ctx.drawImage(video, 0, 0, vw, vh, -targetW * 0.1, -targetH * 0.1, targetW * 1.2, targetH * 1.2);
          ctx.restore();

          // Draw contained video in center
          const scale = Math.min(targetW / vw, targetH / vh);
          const dw = vw * scale;
          const dh = vh * scale;
          const dx = (targetW - dw) / 2;
          const dy = (targetH - dh) / 2;
          ctx.drawImage(video, 0, 0, vw, vh, dx, dy, dw, dh);
        } else if (fitMode === 'crop') {
          // Center-crop to fill target
          const scale = Math.max(targetW / vw, targetH / vh);
          const sw = targetW / scale;
          const sh = targetH / scale;
          const sx = (vw - sw) / 2;
          const sy = (vh - sh) / 2;
          ctx.drawImage(video, sx, sy, sw, sh, 0, 0, targetW, targetH);
        } else {
          // Black bars
          const scale = Math.min(targetW / vw, targetH / vh);
          const dw = vw * scale;
          const dh = vh * scale;
          const dx = (targetW - dw) / 2;
          const dy = (targetH - dh) / 2;
          ctx.drawImage(video, 0, 0, vw, vh, dx, dy, dw, dh);
        }
      } else {
        // Placeholder
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(0, 0, targetW, targetH);
        ctx.fillStyle = '#94a3b8';
        ctx.font = '16px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(`Aspect: ${aspectPreset} (${targetW}x${targetH})`, targetW / 2, targetH / 2);
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [aspectPreset, fitMode, customW, customH]);

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) v.play().then(() => setIsPlaying(true));
    else { v.pause(); setIsPlaying(false); }
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Direct snapshot export or WebM
    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `resized_${aspectPreset.replace(':', 'x')}_${videoName.replace(/\.[^/.]+$/, '')}.png`;
        a.click();
        showToast(`Frame resized to ${aspectPreset} exported`, 'success');
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <Maximize2 className="w-5 h-5 text-indigo-500" />
            <span>Video Resizer & Social Formatter</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Convert any video aspect ratio to YouTube (16:9), Shorts/TikTok (9:16), or Instagram (1:1, 4:5) with blurred ambient padding or crop.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-200 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded-lg transition-colors border border-neutral-300 dark:border-neutral-700">
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Video</span>
            <input
              type="file"
              accept="video/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) {
                  setVideoSrc(URL.createObjectURL(f));
                  setVideoName(f.name);
                  showToast(`Loaded "${f.name}"`, 'success');
                }
              }}
            />
          </label>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 Cols: Resized Canvas Viewport */}
        <div className="lg:col-span-7 flex flex-col items-center">
          <div className="relative max-h-[480px] w-full bg-neutral-950 rounded-xl overflow-hidden border border-neutral-800 shadow-xl flex items-center justify-center">
            {videoSrc && (
              <video
                ref={videoRef}
                src={videoSrc}
                playsInline
                loop
                className="hidden"
                crossOrigin="anonymous"
              />
            )}
            <canvas ref={canvasRef} className="max-h-[480px] w-auto max-w-full object-contain" />
          </div>

          <div className="w-full mt-3 p-3 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl flex items-center justify-between text-xs">
            <button
              onClick={togglePlay}
              disabled={!videoSrc}
              className="p-2 text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg disabled:opacity-50"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>

            <span className="font-mono text-neutral-500">
              Preset: {aspectPreset}
            </span>

            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Formatted</span>
            </button>
          </div>
        </div>

        {/* Right 5 Cols: Presets & Fit Mode */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3.5 text-xs">
            <h3 className="font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[11px]">
              Platform & Aspect Presets
            </h3>
            <div className="space-y-2">
              {presets.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setAspectPreset(p.id)}
                  className={`w-full p-2.5 rounded-lg border text-left font-medium transition-colors flex items-center justify-between ${aspectPreset === p.id ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300' : 'border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300'}`}
                >
                  <div>
                    <div className="font-semibold">{p.label}</div>
                    <div className="text-[10px] text-neutral-400 font-mono">{p.w} x {p.h} ({p.aspect})</div>
                  </div>
                  <span className="text-[11px] font-mono">{p.aspect}</span>
                </button>
              ))}
            </div>

            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 space-y-2">
              <label className="block text-neutral-500">Aspect Ratio Fit Mode</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'blur', label: 'Ambient Blur' },
                  { id: 'crop', label: 'Crop Fill' },
                  { id: 'black', label: 'Black Bars' }
                ].map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setFitMode(m.id as typeof fitMode)}
                    className={`py-1.5 rounded-lg border text-center font-medium ${fitMode === m.id ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300' : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'}`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
