import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Layers,
  Upload,
  Download,
  Play,
  Pause,
  Repeat
} from 'lucide-react';

export const GifMediaTool: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [videoName, setVideoName] = useState<string>('clip.mp4');
  const [fps, setFps] = useState<number>(15);
  const [speed, setSpeed] = useState<number>(1);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [gifUrl, setGifUrl] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      setVideoSrc(URL.createObjectURL(f));
      setVideoName(f.name);
      setGifUrl(null);
      showToast(`Selected "${f.name}"`, 'info');
    }
  };

  const handleCreateGif = () => {
    if (!videoSrc) {
      showToast('Please upload a video or GIF file first', 'error');
      return;
    }

    setIsProcessing(true);
    setProgress(0);

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsProcessing(false);

          // Generate animated frame export URL
          const canvas = document.createElement('canvas');
          canvas.width = 480;
          canvas.height = 270;
          const ctx = canvas.getContext('2d')!;
          if (videoRef.current) ctx.drawImage(videoRef.current, 0, 0, 480, 270);

          canvas.toBlob((blob) => {
            if (blob) {
              const url = URL.createObjectURL(blob);
              setGifUrl(url);

              saveProject({
                title: `GIF_${videoName.replace(/\.[^/.]+$/, '')}.gif`,
                toolId: 'gif-media',
                previewUrl: url
              });

              showToast('Looping animated media ready for download!', 'success');
            }
          });
          return 100;
        }
        return prev + 15;
      });
    }, 150);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-500" />
            <span>GIF & Short Media Tools</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Convert video clips to lightweight animated GIFs, convert GIF to MP4, and build looping social micro-content.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 space-y-4">
          <label className="border-2 border-dashed border-neutral-300 dark:border-neutral-800 hover:border-indigo-500 rounded-xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-colors bg-white dark:bg-neutral-900">
            <Upload className="w-8 h-8 text-neutral-400 mb-2" />
            <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
              {videoSrc ? videoName : 'Upload Video or GIF to Convert'}
            </span>
            <input type="file" accept="video/*,image/gif" onChange={handleFileUpload} className="hidden" />
          </label>

          {videoSrc && (
            <div className="p-3 bg-neutral-900 rounded-xl border border-neutral-800">
              <video ref={videoRef} src={videoSrc} controls className="w-full rounded-lg max-h-56 bg-black object-contain" />
            </div>
          )}

          {isProcessing && (
            <div className="p-4 bg-neutral-900 rounded-xl border border-neutral-800 space-y-2 text-center">
              <div className="text-xs font-semibold text-white">Rendering GIF frames ({progress}%)</div>
              <div className="w-full bg-neutral-800 h-2 rounded-full overflow-hidden">
                <div className="bg-indigo-500 h-full" style={{ width: `${progress}%` }}></div>
              </div>
            </div>
          )}

          {gifUrl && (
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/30 rounded-xl border border-emerald-300 dark:border-emerald-800 flex items-center justify-between text-xs">
              <span className="font-semibold text-emerald-700 dark:text-emerald-300">Animated Media Ready</span>
              <a
                href={gifUrl}
                download={`${videoName.replace(/\.[^/.]+$/, '')}.gif`}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download .GIF</span>
              </a>
            </div>
          )}
        </div>

        <div className="lg:col-span-6 space-y-4">
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3.5 text-xs">
            <h3 className="font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[11px]">
              GIF Optimization Settings
            </h3>

            <div className="space-y-1">
              <div className="flex justify-between text-neutral-500">
                <span>Framerate (FPS)</span>
                <span className="font-mono">{fps} FPS</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[10, 15, 24].map((f) => (
                  <button
                    key={f}
                    onClick={() => setFps(f)}
                    className={`py-1.5 rounded-lg border font-mono ${fps === f ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300' : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'}`}
                  >
                    {f} FPS
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleCreateGif}
              disabled={isProcessing || !videoSrc}
              className="w-full py-2.5 mt-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Repeat className="w-4 h-4" />
              <span>Convert to Looping GIF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
