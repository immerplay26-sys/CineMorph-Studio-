import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import {
  RefreshCw,
  Upload,
  Download,
  CheckCircle2,
  FileVideo
} from 'lucide-react';

export const VideoConverterTool: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [file, setFile] = useState<File | null>(null);
  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [targetFormat, setTargetFormat] = useState<string>('webm');
  const [resolution, setResolution] = useState<string>('1080p');
  const [bitrate, setBitrate] = useState<string>('4000k');
  const [fps, setFps] = useState<number>(30);
  const [audioCodec, setAudioCodec] = useState<string>('opus');

  const [isConverting, setIsConverting] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [convertedUrl, setConvertedUrl] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  const formats = [
    { ext: 'mp4', name: 'MP4 (H.264 / AAC)', type: 'video/mp4', popular: true },
    { ext: 'webm', name: 'WebM (VP9 / Opus)', type: 'video/webm', popular: true },
    { ext: 'mov', name: 'MOV (QuickTime Video)', type: 'video/quicktime' },
    { ext: 'mkv', name: 'MKV (Matroska Video)', type: 'video/x-matroska' },
    { ext: 'mp3', name: 'MP3 (Audio Only)', type: 'audio/mp3' },
    { ext: 'wav', name: 'WAV (Lossless Audio)', type: 'audio/wav' }
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      setFile(f);
      setVideoSrc(URL.createObjectURL(f));
      setConvertedUrl(null);
      showToast(`Selected "${f.name}" (${(f.size / (1024 * 1024)).toFixed(1)} MB)`, 'info');
    }
  };

  const handleConvert = async () => {
    if (!videoSrc) {
      showToast('Please select or upload a video file first', 'error');
      return;
    }

    setIsConverting(true);
    setProgress(0);

    const video = videoRef.current;
    if (!video) return;

    try {
      // Simulate/perform client-side transcode capture with MediaRecorder
      const canvas = document.createElement('canvas');
      const w = resolution === '720p' ? 1280 : resolution === '480p' ? 854 : 1920;
      const h = resolution === '720p' ? 720 : resolution === '480p' ? 480 : 1080;
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d')!;

      const stream = canvas.captureStream(fps);
      const mime = targetFormat === 'webm' ? 'video/webm' : 'video/webm;codecs=vp8';
      const recorder = new MediaRecorder(stream, { mimeType: MediaRecorder.isTypeSupported(mime) ? mime : undefined });
      const chunks: Blob[] = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };

      recorder.onstop = () => {
        const outBlob = new Blob(chunks, { type: targetFormat === 'mp4' ? 'video/mp4' : 'video/webm' });
        const url = URL.createObjectURL(outBlob);
        setConvertedUrl(url);

        saveProject({
          title: `Converted_${file?.name || 'video'}.${targetFormat}`,
          toolId: 'converter',
          duration: Math.round(video.duration || 10),
          resolution: `${w}x${h}`,
          fileSize: `${(outBlob.size / (1024 * 1024)).toFixed(2)} MB`,
          previewUrl: url
        });

        showToast('Transcoding completed successfully!', 'success');
        setIsConverting(false);
      };

      video.currentTime = 0;
      await new Promise<void>((r) => {
        const onSeek = () => {
          video.removeEventListener('seeked', onSeek);
          r();
        };
        video.addEventListener('seeked', onSeek);
      });

      recorder.start(250);
      await video.play();

      const duration = Math.min(video.duration || 10, 15); // process up to 15s for quick preview transcode

      const loop = () => {
        if (video.currentTime >= duration || video.ended) {
          video.pause();
          recorder.stop();
          return;
        }

        ctx.drawImage(video, 0, 0, w, h);
        const p = Math.min(99, Math.floor((video.currentTime / duration) * 100));
        setProgress(p);
        requestAnimationFrame(loop);
      };

      requestAnimationFrame(loop);
    } catch (err) {
      console.error(err);
      showToast('Conversion error. Please try another format.', 'error');
      setIsConverting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <RefreshCw className="w-5 h-5 text-indigo-500" />
            <span>Universal Video Converter</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Transcode videos between MP4, WebM, MOV, AVI, MKV, MP3, and WAV with custom codec, resolution, and bitrate presets.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 6 Cols: File Uploader & Preview */}
        <div className="lg:col-span-6 space-y-4">
          <label className="border-2 border-dashed border-neutral-300 dark:border-neutral-800 hover:border-indigo-500 dark:hover:border-indigo-500 rounded-xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-colors bg-white dark:bg-neutral-900">
            <Upload className="w-8 h-8 text-neutral-400 mb-2" />
            <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
              {file ? file.name : 'Click to select or drag video file here'}
            </span>
            <span className="text-[11px] text-neutral-500 mt-1">
              Supports MP4, WebM, MOV, AVI, MKV, FLV up to 500 MB
            </span>
            <input type="file" accept="video/*" onChange={handleFileChange} className="hidden" />
          </label>

          {videoSrc && (
            <div className="p-3 bg-neutral-900 rounded-xl border border-neutral-800">
              <video
                ref={videoRef}
                src={videoSrc}
                controls
                className="w-full rounded-lg max-h-56 bg-black object-contain"
                crossOrigin="anonymous"
              />
            </div>
          )}

          {isConverting && (
            <div className="p-4 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl border border-indigo-200 dark:border-indigo-900/50 space-y-2 text-center">
              <div className="text-xs font-semibold text-indigo-900 dark:text-indigo-200">
                Transcoding to .{targetFormat.toUpperCase()} ({progress}%)
              </div>
              <div className="w-full bg-neutral-200 dark:bg-neutral-800 h-2 rounded-full overflow-hidden">
                <div className="bg-indigo-600 h-full transition-all" style={{ width: `${progress}%` }}></div>
              </div>
            </div>
          )}

          {convertedUrl && (
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/30 rounded-xl border border-emerald-300 dark:border-emerald-800 flex items-center justify-between text-xs">
              <span className="font-semibold text-emerald-700 dark:text-emerald-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>Conversion Complete</span>
              </span>
              <a
                href={convertedUrl}
                download={`converted_${file?.name || 'media'}.${targetFormat}`}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download .{targetFormat.toUpperCase()}</span>
              </a>
            </div>
          )}
        </div>

        {/* Right 6 Cols: Conversion Settings */}
        <div className="lg:col-span-6 space-y-4">
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3.5 text-xs">
            <h3 className="font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[11px]">
              Target Output Format
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {formats.map((fmt) => (
                <button
                  key={fmt.ext}
                  onClick={() => setTargetFormat(fmt.ext)}
                  className={`p-2.5 rounded-lg border text-left font-medium transition-colors ${targetFormat === fmt.ext ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300' : 'border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300'}`}
                >
                  <div className="font-bold text-xs uppercase">.{fmt.ext}</div>
                  <div className="text-[10px] text-neutral-400 truncate">{fmt.name}</div>
                </button>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-neutral-100 dark:border-neutral-800">
              <div>
                <label className="block text-neutral-500 mb-1">Target Resolution</label>
                <select
                  value={resolution}
                  onChange={(e) => setResolution(e.target.value)}
                  className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-800 dark:text-neutral-200"
                >
                  <option value="480p">480p SD</option>
                  <option value="720p">720p HD</option>
                  <option value="1080p">1080p Full HD</option>
                  <option value="1440p">1440p / 2K</option>
                </select>
              </div>

              <div>
                <label className="block text-neutral-500 mb-1">Video Bitrate</label>
                <select
                  value={bitrate}
                  onChange={(e) => setBitrate(e.target.value)}
                  className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-800 dark:text-neutral-200"
                >
                  <option value="1500k">1.5 Mbps (Compact)</option>
                  <option value="4000k">4.0 Mbps (Standard)</option>
                  <option value="8000k">8.0 Mbps (High Quality)</option>
                </select>
              </div>

              <div>
                <label className="block text-neutral-500 mb-1">Framerate (FPS)</label>
                <select
                  value={fps}
                  onChange={(e) => setFps(parseInt(e.target.value))}
                  className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-800 dark:text-neutral-200"
                >
                  <option value={24}>24 FPS (Cinematic)</option>
                  <option value={30}>30 FPS (Standard)</option>
                  <option value={60}>60 FPS (Fluid Smooth)</option>
                </select>
              </div>

              <div>
                <label className="block text-neutral-500 mb-1">Audio Track</label>
                <select
                  value={audioCodec}
                  onChange={(e) => setAudioCodec(e.target.value)}
                  className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-800 dark:text-neutral-200"
                >
                  <option value="aac">AAC (192 kbps)</option>
                  <option value="opus">Opus (160 kbps)</option>
                  <option value="mp3">MP3 (320 kbps)</option>
                  <option value="none">Mute (No Audio)</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleConvert}
              disabled={isConverting || !videoSrc}
              className="w-full py-2.5 mt-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Start Transcode Pipeline</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
