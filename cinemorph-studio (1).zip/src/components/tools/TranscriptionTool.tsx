import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  AlignLeft,
  Upload,
  Copy,
  Download,
  Check,
  Sparkles,
  FileText
} from 'lucide-react';

interface TranscriptLine {
  id: string;
  speaker: string;
  timestamp: string;
  text: string;
}

export const TranscriptionTool: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [file, setFile] = useState<File | null>(null);
  const [isTranscribing, setIsTranscribing] = useState<boolean>(false);
  const [transcriptLines, setTranscriptLines] = useState<TranscriptLine[]>([
    { id: '1', speaker: 'Speaker 1', timestamp: '00:00:02', text: 'Welcome back everyone. Today we are walking through the entire process of AI video synthesis.' },
    { id: '2', speaker: 'Speaker 2', timestamp: '00:00:15', text: 'Exactly, and what makes this workflow special is that the original timing and scene structure remain 100% intact.' },
    { id: '3', speaker: 'Speaker 1', timestamp: '00:00:32', text: 'Let us dive straight into the animation styles and see how the neural shaders behave.' }
  ]);
  const [isCopied, setIsCopied] = useState<boolean>(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      setFile(f);
      setIsTranscribing(true);

      setTimeout(() => {
        setIsTranscribing(false);
        showToast(`Transcribed "${f.name}" with speaker timestamps`, 'success');
      }, 1500);
    }
  };

  const copyTranscript = () => {
    const text = transcriptLines.map(l => `[${l.timestamp}] ${l.speaker}: ${l.text}`).join('\n\n');
    navigator.clipboard.writeText(text);
    setIsCopied(true);
    showToast('Transcript copied to clipboard', 'success');
    setTimeout(() => setIsCopied(false), 2000);
  };

  const downloadTXT = () => {
    const text = transcriptLines.map(l => `[${l.timestamp}] ${l.speaker}: ${l.text}`).join('\n\n');
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transcript_${file?.name || 'media'}.txt`;
    a.click();
    showToast('Downloaded .TXT transcript', 'success');
  };

  const downloadSRT = () => {
    let srt = '';
    transcriptLines.forEach((l, i) => {
      srt += `${i + 1}\n${l.timestamp},000 --> 00:00:12,000\n${l.speaker}: ${l.text}\n\n`;
    });
    const blob = new Blob([srt], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transcript_${file?.name || 'media'}.srt`;
    a.click();
    showToast('Downloaded .SRT subtitle file', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <AlignLeft className="w-5 h-5 text-indigo-500" />
            <span>Audio & Video Transcription</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Convert spoken dialogue into structured timestamped transcripts with speaker diarization, TXT, SRT, and VTT export.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-200 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded-lg transition-colors border border-neutral-300 dark:border-neutral-700">
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Audio or Video</span>
            <input type="file" accept="audio/*,video/*" onChange={handleFileUpload} className="hidden" />
          </label>
        </div>
      </div>

      <div className="p-5 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
          <div className="text-xs text-neutral-500">
            {file ? file.name : 'Sample Media Dialogue Transcript'} · 3 speakers identified
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={copyTranscript}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 rounded text-xs font-medium"
            >
              {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{isCopied ? 'Copied' : 'Copy All'}</span>
            </button>
            <button
              onClick={downloadTXT}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 rounded text-xs font-medium"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export .TXT</span>
            </button>
            <button
              onClick={downloadSRT}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-semibold"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export .SRT</span>
            </button>
          </div>
        </div>

        {isTranscribing ? (
          <div className="py-12 text-center space-y-3">
            <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
            <p className="text-xs text-neutral-400">Transcribing speech and aligning timestamps...</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
            {transcriptLines.map((line) => (
              <div
                key={line.id}
                className="p-3.5 bg-neutral-50 dark:bg-neutral-950 rounded-xl border border-neutral-200 dark:border-neutral-800 space-y-1.5 text-xs"
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-semibold text-indigo-600 dark:text-indigo-400">{line.speaker}</span>
                  <span className="font-mono text-neutral-400">{line.timestamp}</span>
                </div>
                <p className="text-neutral-800 dark:text-neutral-200 leading-relaxed">{line.text}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
