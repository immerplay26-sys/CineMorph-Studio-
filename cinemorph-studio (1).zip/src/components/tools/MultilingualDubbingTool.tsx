import React, { useState, useRef } from 'react';
import { SUPPORTED_LANGUAGES } from '../../constants/defaults';
import { useApp } from '../../context/AppContext';
import {
  Languages,
  Upload,
  Play,
  Pause,
  Download,
  Volume2,
  Sparkles,
  Subtitles,
  CheckCircle2,
  FileDown
} from 'lucide-react';

export const MultilingualDubbingTool: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [videoName, setVideoName] = useState<string>('speech_original.mp4');
  const [sourceLang, setSourceLang] = useState<string>('en');
  const [targetLang, setTargetLang] = useState<string>('es');
  const [dubbingMode, setDubbingMode] = useState<'both' | 'voice' | 'subtitles'>('both');
  const [voiceName, setVoiceName] = useState<string>('Kore');
  const [voiceSpeed, setVoiceSpeed] = useState<number>(1.0);
  const [originalAudioVolume, setOriginalAudioVolume] = useState<number>(0.2); // 20% background ducking

  const [transcript, setTranscript] = useState<string>(
    'Welcome to CineMorph Studio. Today we are demonstrating how AI translates spoken video while preserving original visual timing and pacing.'
  );

  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [stepStatus, setStepStatus] = useState<string>('');
  const [translatedText, setTranslatedText] = useState<string>('');
  const [dubbedAudioUrl, setDubbedAudioUrl] = useState<string | null>(null);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  const handleStartDubbing = async () => {
    setIsProcessing(true);
    setStepStatus('Analyzing speech & detecting language...');

    try {
      setStepStatus(`Translating transcript into ${targetLang}...`);
      const response = await fetch('/api/ai/dubbing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transcript,
          sourceLanguage: sourceLang,
          targetLanguage: targetLang,
          voiceName
        })
      });

      if (!response.ok) {
        throw new Error('Dubbing API request failed');
      }

      const data = await response.json();
      setTranslatedText(data.translatedText || '');

      if (data.audioBase64) {
        const audioUrl = `data:audio/wav;base64,${data.audioBase64}`;
        setDubbedAudioUrl(audioUrl);
      }

      saveProject({
        title: `Dubbed_${targetLang}_${videoName.replace(/\.[^/.]+$/, '')}`,
        toolId: 'dubbing',
        previewUrl: dubbedAudioUrl || undefined,
        metadata: { sourceLang, targetLang, translatedText: data.translatedText }
      });

      showToast(`Dubbing & translation into ${targetLang.toUpperCase()} complete!`, 'success');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Dubbing failed';
      showToast(msg, 'error');
    } finally {
      setIsProcessing(false);
      setStepStatus('');
    }
  };

  const exportTranslatedSRT = () => {
    if (!translatedText) return;
    const srt = `1\n00:00:01,000 --> 00:00:08,000\n${translatedText}\n\n`;
    const blob = new Blob([srt], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dubbed_${targetLang}.srt`;
    a.click();
    showToast('Downloaded translated SRT', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <Languages className="w-5 h-5 text-indigo-500" />
            <span>Video Translation & AI Dubbing</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Multilingual speech translation into 45+ languages with synchronized neural voice dubbing and translated subtitles.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-200 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 rounded-lg transition-colors border border-neutral-300 dark:border-neutral-700">
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Video or Audio</span>
            <input
              type="file"
              accept="video/*,audio/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) {
                  setVideoSrc(URL.createObjectURL(f));
                  setVideoName(f.name);
                  showToast(`Loaded "${f.name}"`, 'success');
                }
              }}
            />
          </label>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 Cols: Transcript & Language Routing */}
        <div className="lg:col-span-7 space-y-4">
          {/* Language Pair Selectors */}
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-900 dark:text-neutral-100">
              Language Pair & Output Mode
            </h3>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-neutral-500 mb-1">Source Language</label>
                <select
                  value={sourceLang}
                  onChange={(e) => setSourceLang(e.target.value)}
                  className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100"
                >
                  {SUPPORTED_LANGUAGES.map((l) => (
                    <option key={l.code} value={l.code}>{l.name} ({l.nativeName})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-neutral-500 mb-1">Target Language (45+ Supported)</label>
                <select
                  value={targetLang}
                  onChange={(e) => setTargetLang(e.target.value)}
                  className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100"
                >
                  {SUPPORTED_LANGUAGES.map((l) => (
                    <option key={l.code} value={l.code}>{l.name} ({l.nativeName})</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Mode selection: Voice, Subtitles, Both */}
            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 space-y-1.5 text-xs">
              <span className="text-neutral-500 block">Dubbing Delivery Mode</span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'both', label: 'Voice + Subtitles' },
                  { id: 'voice', label: 'Voice Dubbing Only' },
                  { id: 'subtitles', label: 'Translated Subtitles' }
                ].map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setDubbingMode(m.id as typeof dubbingMode)}
                    className={`py-2 rounded-lg border font-medium text-center ${dubbingMode === m.id ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300' : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'}`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Transcript Box */}
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-2 text-xs">
            <span className="font-semibold text-neutral-800 dark:text-neutral-200 block">Source Transcript</span>
            <textarea
              rows={4}
              value={transcript}
              onChange={(e) => setTranscript(e.target.value)}
              className="w-full p-3 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100 resize-none text-xs leading-relaxed"
            />
          </div>

          <button
            onClick={handleStartDubbing}
            disabled={isProcessing}
            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold text-xs flex items-center justify-center gap-2 disabled:opacity-50 shadow-sm"
          >
            <Sparkles className="w-4 h-4" />
            <span>{isProcessing ? stepStatus || 'Processing Translation...' : 'Start AI Dubbing & Translation'}</span>
          </button>

          {/* Results Output */}
          {translatedText && (
            <div className="p-4 bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-300 dark:border-emerald-800 rounded-xl space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Translated Speech ({targetLang.toUpperCase()})</span>
                </span>
                <button
                  onClick={exportTranslatedSRT}
                  className="flex items-center gap-1 px-2.5 py-1 bg-white dark:bg-neutral-900 border border-emerald-300 rounded text-emerald-700 dark:text-emerald-300 font-medium"
                >
                  <FileDown className="w-3.5 h-3.5" />
                  <span>Export .SRT</span>
                </button>
              </div>

              <p className="p-3 bg-white dark:bg-neutral-900 rounded-lg border border-emerald-200 dark:border-emerald-900 text-neutral-900 dark:text-neutral-100 leading-relaxed">
                {translatedText}
              </p>

              {dubbedAudioUrl && (
                <div className="pt-2 flex items-center justify-between">
                  <audio ref={audioRef} controls src={dubbedAudioUrl} className="h-8 flex-1 max-w-sm mr-3" />
                  <a
                    href={dubbedAudioUrl}
                    download={`dubbed_${targetLang}.wav`}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold flex items-center gap-1 text-[11px]"
                  >
                    <Download className="w-3 h-3" />
                    <span>Download WAV</span>
                  </a>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right 5 Cols: Voice Persona & Synchronization Settings */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3.5 text-xs">
            <h3 className="font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[11px] pb-2 border-b border-neutral-100 dark:border-neutral-800">
              Voice Persona & Audio Ducking
            </h3>

            {/* Voice select */}
            <div>
              <label className="text-neutral-500 block mb-1">Target Voice Persona</label>
              <select
                value={voiceName}
                onChange={(e) => setVoiceName(e.target.value)}
                className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100"
              >
                <option value="Kore">Kore (Female - Narrative, articulate)</option>
                <option value="Puck">Puck (Male - Dynamic, energetic)</option>
                <option value="Charon">Charon (Male - Deep, cinematic)</option>
                <option value="Fenrir">Fenrir (Male - Authoritative)</option>
                <option value="Zephyr">Zephyr (Female - Friendly, upbeat)</option>
              </select>
            </div>

            {/* Voice Pacing */}
            <div className="space-y-1">
              <div className="flex justify-between text-neutral-500">
                <span>Pacing / Speed Alignment</span>
                <span className="font-mono">{voiceSpeed}x</span>
              </div>
              <input
                type="range"
                min="0.75"
                max="1.5"
                step="0.05"
                value={voiceSpeed}
                onChange={(e) => setVoiceSpeed(parseFloat(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-neutral-200 dark:bg-neutral-800 rounded"
              />
            </div>

            {/* Background Audio Volume Ducking */}
            <div className="space-y-1">
              <div className="flex justify-between text-neutral-500">
                <span>Original Audio Ducking</span>
                <span className="font-mono">{Math.round(originalAudioVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="0.5"
                step="0.05"
                value={originalAudioVolume}
                onChange={(e) => setOriginalAudioVolume(parseFloat(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-neutral-200 dark:bg-neutral-800 rounded"
              />
              <span className="text-[10px] text-neutral-400 block">Leaves subtle ambient room presence behind translated speech.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
