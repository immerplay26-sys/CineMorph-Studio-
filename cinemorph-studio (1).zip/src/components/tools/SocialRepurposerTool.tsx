import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Share2,
  Upload,
  Download,
  Eye,
  CheckCircle2,
  Layers
} from 'lucide-react';

export const SocialRepurposerTool: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [videoName, setVideoName] = useState<string>('master_video.mp4');
  const [activePlatform, setActivePlatform] = useState<'tiktok' | 'reels' | 'shorts'>('tiktok');

  const platforms = [
    { id: 'tiktok', name: 'TikTok', aspect: '9:16', desc: 'Safe zone margins for right-side action buttons and bottom sound/caption stack.' },
    { id: 'reels', name: 'Instagram Reels', aspect: '9:16', desc: 'Safe margins avoiding bottom comment bar and top search header.' },
    { id: 'shorts', name: 'YouTube Shorts', aspect: '9:16', desc: 'Safe zone optimized for right-side thumbs up / subscribe bar.' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <Share2 className="w-5 h-5 text-indigo-500" />
            <span>Social Media Repurposing & Safe Zones</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Simulate native UI overlays for TikTok, Instagram Reels, and YouTube Shorts so your text and face never get covered by buttons.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-200 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded-lg transition-colors border border-neutral-300 dark:border-neutral-700">
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Master Video</span>
            <input
              type="file"
              accept="video/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) {
                  setVideoSrc(URL.createObjectURL(f));
                  setVideoName(f.name);
                  showToast(`Loaded "${f.name}"`, 'success');
                }
              }}
            />
          </label>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 5 Cols: Smartphone Screen Simulator with Native UI Overlay */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div className="relative w-full max-w-[320px] aspect-[9/16] bg-neutral-950 rounded-3xl overflow-hidden border-4 border-neutral-800 shadow-2xl flex items-center justify-center">
            {videoSrc ? (
              <video
                src={videoSrc}
                playsInline
                autoPlay
                loop
                muted
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="text-center p-6 space-y-2">
                <Share2 className="w-10 h-10 text-neutral-600 mx-auto" />
                <span className="text-xs text-neutral-400 block">Preview Screen</span>
              </div>
            )}

            {/* Simulated Native Platform UI Overlays */}
            {activePlatform === 'tiktok' && (
              <div className="absolute inset-0 pointer-events-none p-4 flex flex-col justify-between text-white">
                <div className="flex justify-between items-center pt-2 text-xs font-semibold opacity-80">
                  <span>LIVE</span>
                  <span>Following | For You</span>
                  <span>🔍</span>
                </div>

                {/* Right side interaction buttons */}
                <div className="self-end space-y-4 pr-1 text-center text-[10px] font-medium opacity-90">
                  <div className="w-9 h-9 rounded-full bg-rose-500 mx-auto flex items-center justify-center font-bold">♥</div>
                  <span>482K</span>
                  <div className="w-9 h-9 rounded-full bg-neutral-800/80 mx-auto flex items-center justify-center">💬</div>
                  <span>3.2K</span>
                  <div className="w-9 h-9 rounded-full bg-neutral-800/80 mx-auto flex items-center justify-center">🔖</div>
                  <span>24K</span>
                  <div className="w-9 h-9 rounded-full bg-neutral-800/80 mx-auto flex items-center justify-center">↗</div>
                  <span>Share</span>
                </div>

                {/* Bottom title & sound banner */}
                <div className="pb-2 space-y-1 text-xs opacity-90">
                  <span className="font-bold">@creator · Follow</span>
                  <p className="text-[11px] line-clamp-2">This is the safe zone area where captions stay visible!</p>
                  <div className="text-[10px] opacity-75">♫ Original sound - Trending Creator Track</div>
                </div>
              </div>
            )}

            {activePlatform === 'reels' && (
              <div className="absolute inset-0 pointer-events-none p-4 flex flex-col justify-between text-white">
                <div className="flex justify-between items-center text-xs font-bold pt-2 opacity-80">
                  <span>Reels</span>
                  <span>📷</span>
                </div>

                <div className="self-end space-y-4 pr-1 text-center text-[10px] opacity-90">
                  <div className="w-9 h-9 rounded-full bg-neutral-800/70 mx-auto flex items-center justify-center">♡</div>
                  <span>120K</span>
                  <div className="w-9 h-9 rounded-full bg-neutral-800/70 mx-auto flex items-center justify-center">💬</div>
                  <span>840</span>
                  <div className="w-9 h-9 rounded-full bg-neutral-800/70 mx-auto flex items-center justify-center">✈</div>
                </div>

                <div className="pb-2 space-y-1 text-xs opacity-90">
                  <span className="font-bold">instagram_creator</span>
                  <p className="text-[11px]">Keep important visual elements inside the middle bounding box.</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right 7 Cols: Platform Selector & Guidance */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3.5 text-xs">
            <h3 className="font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[11px]">
              Select Platform Preview Guide
            </h3>

            <div className="space-y-2">
              {platforms.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setActivePlatform(p.id as typeof activePlatform)}
                  className={`w-full p-3 rounded-lg border text-left font-medium transition-colors ${activePlatform === p.id ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-900 dark:text-indigo-200' : 'border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300'}`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm">{p.name}</span>
                    <span className="font-mono text-[11px] text-neutral-400">{p.aspect}</span>
                  </div>
                  <p className="text-[11px] text-neutral-500 mt-1">{p.desc}</p>
                </button>
              ))}
            </div>

            <div className="pt-3 border-t border-neutral-100 dark:border-neutral-800 space-y-2 text-neutral-600 dark:text-neutral-400">
              <span className="font-semibold text-neutral-900 dark:text-neutral-100 block">Creator Safe Zone Tips:</span>
              <ul className="space-y-1.5 list-disc list-inside text-[11px]">
                <li>Keep faces and focal actions within the upper-middle 60% of the screen.</li>
                <li>Avoid placing key subtitles below 80% screen height where captions and descriptions overlap.</li>
                <li>Leave at least 70px margin on the right side to prevent button overlap.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
