import React, { useState, useRef } from 'react';
import { ApiService } from '../../services/api';
import { useApp } from '../../context/AppContext';
import {
  Mic,
  Play,
  Pause,
  Download,
  Volume2,
  Sparkles,
  RotateCcw
} from 'lucide-react';

export const TextToSpeechTool: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [text, setText] = useState<string>(
    'Welcome to CineMorph Studio. Today, we are exploring cutting-edge AI video transformation and high-fidelity speech synthesis.'
  );
  const [selectedVoice, setSelectedVoice] = useState<string>('Kore');
  const [speed, setSpeed] = useState<number>(1.0);
  const [pitch, setPitch] = useState<number>(1.0);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const voices = [
    { id: 'Kore', name: 'Kore', gender: 'Female', tone: 'Calm, articulate, warm narrative' },
    { id: 'Puck', name: 'Puck', gender: 'Male', tone: 'Energetic, dynamic, engaging creator' },
    { id: 'Charon', name: 'Charon', gender: 'Male', tone: 'Deep, authoritative, cinematic' },
    { id: 'Fenrir', name: 'Fenrir', gender: 'Male', tone: 'Commanding, resonant, intense' },
    { id: 'Zephyr', name: 'Zephyr', gender: 'Female', tone: 'Crisp, breezy, cheerful, upbeat' }
  ];

  const handleGenerate = async () => {
    if (!text.trim()) {
      showToast('Please enter some text to generate speech.', 'error');
      return;
    }

    setIsGenerating(true);
    try {
      const res = await ApiService.textToSpeech(text, selectedVoice, speed);
      if (res.audioUrl) {
        setAudioUrl(res.audioUrl);
        showToast('Speech generated successfully via Gemini Studio TTS', 'success');

        saveProject({
          title: `Voice_${selectedVoice}_${text.slice(0, 20)}`,
          toolId: 'tts',
          duration: Math.ceil(text.split(' ').length / 2.5),
          previewUrl: res.audioUrl,
          metadata: { voice: selectedVoice, speed }
        });
      } else if (res.isClientFallback) {
        showToast('Playing speech via browser speech engine', 'info');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Speech generation failed';
      showToast(msg, 'error');
    } finally {
      setIsGenerating(false);
    }
  };

  const togglePlayback = () => {
    if (!audioRef.current) return;
    if (audioRef.current.paused) {
      audioRef.current.play().then(() => setIsPlaying(true));
    } else {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <Mic className="w-5 h-5 text-indigo-500" />
            <span>Text to Speech (AI Neural Voices)</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Convert script text into natural studio narration powered by Gemini 3.8 Flash Lite TTS with prebuilt voice personas.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isGenerating ? 'Synthesizing...' : 'Generate Studio Speech'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 Cols: Text Editor & Audio Player */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between text-xs text-neutral-500">
              <span className="font-semibold text-neutral-800 dark:text-neutral-200">Script / Narration Text</span>
              <span className="font-mono">{text.length} characters · ~{Math.ceil(text.split(/\s+/).length / 2.5)}s duration</span>
            </div>

            <textarea
              rows={7}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Enter your script or dialogue here..."
              className="w-full p-3.5 text-sm bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100 focus:outline-none focus:border-indigo-500 leading-relaxed resize-none"
            />
          </div>

          {/* Audio Wave Player Shelf */}
          {audioUrl && (
            <div className="p-4 bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-900/40 rounded-xl space-y-3">
              <audio
                ref={audioRef}
                src={audioUrl}
                onEnded={() => setIsPlaying(false)}
                className="hidden"
              />

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button
                    onClick={togglePlayback}
                    className="p-3 text-white bg-indigo-600 hover:bg-indigo-500 rounded-full shadow-md"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>
                  <div>
                    <h4 className="text-xs font-semibold text-neutral-900 dark:text-neutral-100">
                      Generated Audio ({selectedVoice})
                    </h4>
                    <p className="text-[11px] text-neutral-500">24kHz 16-bit Broadcast WAV format</p>
                  </div>
                </div>

                <a
                  href={audioUrl}
                  download={`cinemorph_voice_${selectedVoice}.wav`}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .WAV</span>
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Right 5 Cols: Voice Personas & Parameters */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-900 dark:text-neutral-100">
              Select Voice Persona
            </h3>

            <div className="space-y-2">
              {voices.map((v) => {
                const isSelected = selectedVoice === v.id;
                return (
                  <button
                    key={v.id}
                    onClick={() => setSelectedVoice(v.id)}
                    className={`w-full p-3 rounded-lg border text-left text-xs transition-colors flex items-center justify-between ${isSelected ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-100 font-medium' : 'border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300'}`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm">{v.name}</span>
                        <span className="text-[10px] text-neutral-400">· {v.gender}</span>
                      </div>
                      <p className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-0.5">{v.tone}</p>
                    </div>
                    {isSelected && <Volume2 className="w-4 h-4 text-indigo-600" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Speed & Pitch */}
          <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3 text-xs">
            <div className="flex justify-between items-center pb-2 border-b border-neutral-100 dark:border-neutral-800">
              <span className="font-semibold text-neutral-900 dark:text-neutral-100">Speech Modulation</span>
              <button
                onClick={() => { setSpeed(1.0); setPitch(1.0); }}
                className="text-[11px] text-neutral-400 hover:text-neutral-200 flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-neutral-500">
                <span>Speed / Pacing</span>
                <span className="font-mono tabular-nums">{speed}x</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="2.0"
                step="0.05"
                value={speed}
                onChange={(e) => setSpeed(parseFloat(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-neutral-200 dark:bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-neutral-500">
                <span>Pitch Elevation</span>
                <span className="font-mono tabular-nums">{pitch}x</span>
              </div>
              <input
                type="range"
                min="0.75"
                max="1.5"
                step="0.05"
                value={pitch}
                onChange={(e) => setPitch(parseFloat(e.target.value))}
                className="w-full accent-indigo-600 h-1 bg-neutral-200 dark:bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
