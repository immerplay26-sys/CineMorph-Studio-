import React, { useState, useRef } from 'react';
import { AudioProcessingEngine } from '../../services/audioProcessor';
import { useApp } from '../../context/AppContext';
import {
  Volume2,
  Mic,
  Scissors,
  Download,
  Upload,
  Play,
  Pause,
  Sparkles,
  RefreshCw,
  Square
} from 'lucide-react';

export const AudioStudioTool: React.FC = () => {
  const { showToast, saveProject } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'extractor' | 'cutter' | 'silence' | 'recorder'>('extractor');
  const [file, setFile] = useState<File | null>(null);

  // Audio Extractor & Cutter state
  const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
  const [extractedBlobUrl, setExtractedBlobUrl] = useState<string | null>(null);
  const [isExtracting, setIsExtracting] = useState<boolean>(false);
  const [trimStart, setTrimStart] = useState<number>(0);
  const [trimEnd, setTrimEnd] = useState<number>(30);

  // Silence Detector state
  const [silences, setSilences] = useState<{ start: number; end: number; duration: number }[]>([]);

  // Microphone voice recorder state
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const engineRef = useRef<AudioProcessingEngine>(new AudioProcessingEngine());

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f);
    setIsExtracting(true);

    try {
      const buffer = await engineRef.current.extractAudioFromVideo(f);
      setAudioBuffer(buffer);
      setTrimStart(0);
      setTrimEnd(Math.min(30, buffer.duration));

      const wavBlob = engineRef.current.audioBufferToWav(buffer);
      const url = URL.createObjectURL(wavBlob);
      setExtractedBlobUrl(url);

      showToast(`Extracted lossless audio track (${buffer.duration.toFixed(1)}s)`, 'success');
    } catch {
      showToast('Could not extract audio track. Ensure media file contains valid audio.', 'error');
    } finally {
      setIsExtracting(false);
    }
  };

  const handleTrimAudio = async () => {
    if (!audioBuffer) return;
    try {
      const trimmedBlob = await engineRef.current.trimAudio(audioBuffer, trimStart, trimEnd);
      const url = URL.createObjectURL(trimmedBlob);
      setExtractedBlobUrl(url);

      saveProject({
        title: `Clipped_Audio_${file?.name || 'track'}`,
        toolId: 'audio',
        duration: Math.round(trimEnd - trimStart),
        previewUrl: url
      });

      showToast(`Audio trimmed (${trimStart}s - ${trimEnd}s) and ready!`, 'success');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Trim failed';
      showToast(msg, 'error');
    }
  };

  const handleDetectSilences = () => {
    if (!audioBuffer) {
      showToast('Upload or extract an audio file first', 'error');
      return;
    }
    const detected = engineRef.current.detectSilences(audioBuffer, -36, 0.4);
    setSilences(detected);
    showToast(`Detected ${detected.length} silent pause segments!`, 'success');
  };

  // Microphone recording handlers
  const startRecording = async () => {
    try {
      await engineRef.current.startMicrophoneRecording();
      setIsRecording(true);
      setRecordingSeconds(0);
      setRecordedAudioUrl(null);

      timerRef.current = setInterval(() => {
        setRecordingSeconds((s) => s + 1);
      }, 1000);
      showToast('Microphone recording active...', 'info');
    } catch {
      showToast('Microphone access denied or unavailable', 'error');
    }
  };

  const stopRecording = async () => {
    if (timerRef.current) clearInterval(timerRef.current);
    try {
      const blob = await engineRef.current.stopMicrophoneRecording();
      const url = URL.createObjectURL(blob);
      setRecordedAudioUrl(url);
      setIsRecording(false);

      saveProject({
        title: `VoiceRecording_${new Date().toLocaleTimeString()}`,
        toolId: 'audio',
        duration: recordingSeconds,
        previewUrl: url
      });

      showToast('Voice recorded successfully!', 'success');
    } catch {
      setIsRecording(false);
      showToast('Failed to finalize voice recording', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-indigo-500" />
            <span>Complete Audio Suite</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Extract lossless audio from video, detect & remove silences, trim clips, and record studio voiceovers.
          </p>
        </div>

        {/* Sub-tools Tab Bar */}
        <div className="flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 p-1 rounded-lg text-xs">
          <button
            onClick={() => setActiveSubTab('extractor')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${activeSubTab === 'extractor' ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-sm' : 'text-neutral-600 dark:text-neutral-400'}`}
          >
            Audio Extractor
          </button>
          <button
            onClick={() => setActiveSubTab('cutter')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${activeSubTab === 'cutter' ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-sm' : 'text-neutral-600 dark:text-neutral-400'}`}
          >
            Audio Cutter
          </button>
          <button
            onClick={() => setActiveSubTab('silence')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${activeSubTab === 'silence' ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-sm' : 'text-neutral-600 dark:text-neutral-400'}`}
          >
            Silence Remover
          </button>
          <button
            onClick={() => setActiveSubTab('recorder')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${activeSubTab === 'recorder' ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-sm' : 'text-neutral-600 dark:text-neutral-400'}`}
          >
            Voice Recorder
          </button>
        </div>
      </div>

      {/* Main Feature Panes */}
      <div className="p-6 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-6">
        {/* Upload Slot for Extractor / Cutter / Silence */}
        {activeSubTab !== 'recorder' && (
          <div className="space-y-4">
            <label className="border-2 border-dashed border-neutral-300 dark:border-neutral-800 hover:border-indigo-500 rounded-xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-colors">
              <Upload className="w-8 h-8 text-neutral-400 mb-2" />
              <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
                {file ? file.name : 'Upload Video or Audio File'}
              </span>
              <span className="text-[11px] text-neutral-500 mt-1">
                Extracts lossless WAV track instantly
              </span>
              <input type="file" accept="video/*,audio/*" onChange={handleFileUpload} className="hidden" />
            </label>

            {isExtracting && (
              <p className="text-center text-xs text-indigo-500 font-medium">Extracting and decoding audio stream...</p>
            )}

            {extractedBlobUrl && (
              <div className="p-4 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-xl flex items-center justify-between">
                <audio controls src={extractedBlobUrl} className="w-full max-w-md h-10" />
                <a
                  href={extractedBlobUrl}
                  download={`extracted_${file?.name || 'audio'}.wav`}
                  className="px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 ml-4"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .WAV</span>
                </a>
              </div>
            )}
          </div>
        )}

        {/* Sub-Tab 1: Audio Cutter */}
        {activeSubTab === 'cutter' && audioBuffer && (
          <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold text-neutral-900 dark:text-neutral-100 flex items-center gap-1.5">
                <Scissors className="w-4 h-4 text-indigo-500" />
                <span>Trim & Cut Range</span>
              </h4>
              <span className="font-mono text-neutral-500">Duration: {audioBuffer.duration.toFixed(1)}s</span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-neutral-500 mb-1">Start Time (seconds)</label>
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  max={trimEnd}
                  value={trimStart}
                  onChange={(e) => setTrimStart(parseFloat(e.target.value) || 0)}
                  className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg font-mono"
                />
              </div>
              <div>
                <label className="block text-neutral-500 mb-1">End Time (seconds)</label>
                <input
                  type="number"
                  step="0.5"
                  min={trimStart}
                  max={audioBuffer.duration}
                  value={trimEnd}
                  onChange={(e) => setTrimEnd(parseFloat(e.target.value) || audioBuffer.duration)}
                  className="w-full p-2 bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg font-mono"
                />
              </div>
            </div>

            <button
              onClick={handleTrimAudio}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold flex items-center gap-2"
            >
              <Scissors className="w-3.5 h-3.5" />
              <span>Apply Trim Cut</span>
            </button>
          </div>
        )}

        {/* Sub-Tab 2: Silence Detector */}
        {activeSubTab === 'silence' && (
          <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold text-neutral-900 dark:text-neutral-100">
                Silence & Pause Detection (-36 dB threshold)
              </h4>
              <button
                onClick={handleDetectSilences}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Scan Audio Silences</span>
              </button>
            </div>

            {silences.length > 0 && (
              <div className="space-y-2">
                <span className="text-neutral-500">Detected Pauses ({silences.length}):</span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {silences.map((s, idx) => (
                    <div key={idx} className="p-2 bg-neutral-100 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700 text-center font-mono">
                      <span className="text-[10px] text-neutral-400 block">Pause #{idx + 1}</span>
                      <span>{s.start}s - {s.end}s ({s.duration}s)</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Sub-Tab 3: Voice Recorder */}
        {activeSubTab === 'recorder' && (
          <div className="text-center py-8 space-y-6 max-w-md mx-auto">
            <div className="w-20 h-20 mx-auto rounded-full bg-indigo-100 dark:bg-indigo-950 flex items-center justify-center border-2 border-indigo-500">
              <Mic className={`w-8 h-8 ${isRecording ? 'text-rose-500 animate-pulse' : 'text-indigo-600'}`} />
            </div>

            <div>
              <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100">
                {isRecording ? 'Recording Voiceover...' : 'Studio Voice Recorder'}
              </h3>
              <p className="text-xs text-neutral-500 mt-1">
                Record crisp narration directly with microphone wave monitoring.
              </p>
            </div>

            <div className="text-3xl font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {Math.floor(recordingSeconds / 60)}:{('0' + (recordingSeconds % 60)).slice(-2)}
            </div>

            <div className="flex justify-center gap-3">
              {!isRecording ? (
                <button
                  onClick={startRecording}
                  className="px-6 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-semibold flex items-center gap-2 shadow-sm"
                >
                  <Mic className="w-4 h-4" />
                  <span>Start Recording</span>
                </button>
              ) : (
                <button
                  onClick={stopRecording}
                  className="px-6 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-semibold flex items-center gap-2 border border-neutral-700"
                >
                  <Square className="w-4 h-4" />
                  <span>Stop & Save Audio</span>
                </button>
              )}
            </div>

            {recordedAudioUrl && (
              <div className="p-4 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-3">
                <audio controls src={recordedAudioUrl} className="w-full h-10" />
                <a
                  href={recordedAudioUrl}
                  download="voiceover_recording.webm"
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Recording</span>
                </a>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
