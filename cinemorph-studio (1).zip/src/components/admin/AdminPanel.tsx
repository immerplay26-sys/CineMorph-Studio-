import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AdminSiteConfig, PricingPlan } from '../../types';
import { STUDIO_TOOLS } from '../../constants/defaults';
import {
  Shield,
  LogOut,
  Save,
  Palette,
  Sliders,
  CreditCard,
  Search,
  Bell,
  BarChart,
  Lock,
  Check,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';

export const AdminPanel: React.FC = () => {
  const {
    siteConfig,
    updateSiteConfig,
    logoutAdmin,
    adminUser,
    showToast
  } = useApp();

  const [activeTab, setActiveTab] = useState<'branding' | 'tools' | 'plans' | 'seo' | 'announcements' | 'analytics' | 'security'>('branding');
  const [config, setConfig] = useState<AdminSiteConfig>(siteConfig);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await updateSiteConfig(config);
    } finally {
      setIsSaving(false);
    }
  };

  const toggleToolEnabled = (toolId: string) => {
    const current = config.toolSettings[toolId] || { enabled: true, dailyLimit: 50 };
    setConfig({
      ...config,
      toolSettings: {
        ...config.toolSettings,
        [toolId]: {
          ...current,
          enabled: !current.enabled
        }
      }
    });
  };

  const updateToolLimit = (toolId: string, dailyLimit: number) => {
    const current = config.toolSettings[toolId] || { enabled: true, dailyLimit: 50 };
    setConfig({
      ...config,
      toolSettings: {
        ...config.toolSettings,
        [toolId]: {
          ...current,
          dailyLimit
        }
      }
    });
  };

  const updatePlan = (planId: string, updates: Partial<PricingPlan>) => {
    setConfig({
      ...config,
      plans: config.plans.map(p => p.id === planId ? { ...p, ...updates } : p)
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <Shield className="w-5 h-5 text-indigo-500" />
            <span>Admin Management Console</span>
          </h2>
          <p className="text-xs text-neutral-500 mt-1">
            Logged in as <span className="font-mono text-neutral-800 dark:text-neutral-200">{adminUser?.email}</span> (Super Admin)
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow-sm disabled:opacity-50"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{isSaving ? 'Saving Changes...' : 'Save Configuration'}</span>
          </button>

          <button
            onClick={logoutAdmin}
            className="flex items-center gap-1.5 px-3 py-2 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-300 rounded-lg text-xs font-medium"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Navigation Sidebar */}
        <div className="lg:col-span-3 space-y-1">
          {[
            { id: 'branding', label: 'Branding & Identity', icon: <Palette className="w-4 h-4" /> },
            { id: 'tools', label: 'Tools Directory & Limits', icon: <Sliders className="w-4 h-4" /> },
            { id: 'plans', label: 'Monetization & Plans', icon: <CreditCard className="w-4 h-4" /> },
            { id: 'seo', label: 'SEO & Metadata', icon: <Search className="w-4 h-4" /> },
            { id: 'announcements', label: 'Banners & Maintenance', icon: <Bell className="w-4 h-4" /> },
            { id: 'analytics', label: 'Analytics & AdSense', icon: <BarChart className="w-4 h-4" /> },
            { id: 'security', label: 'Security & Credentials', icon: <Lock className="w-4 h-4" /> }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`w-full p-3 rounded-lg border text-left text-xs font-medium flex items-center gap-2.5 transition-colors ${activeTab === tab.id ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300' : 'border-transparent text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'}`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Configuration Canvas */}
        <div className="lg:col-span-9 p-6 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-6 text-xs">
          {/* Tab 1: Branding */}
          {activeTab === 'branding' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100 pb-2 border-b border-neutral-100 dark:border-neutral-800">
                Site Identity & Contact Information
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-neutral-600 dark:text-neutral-400 mb-1">Brand Name</label>
                  <input
                    type="text"
                    value={config.siteName}
                    onChange={(e) => setConfig({ ...config, siteName: e.target.value })}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100"
                  />
                </div>

                <div>
                  <label className="block text-neutral-600 dark:text-neutral-400 mb-1">Tagline</label>
                  <input
                    type="text"
                    value={config.tagline}
                    onChange={(e) => setConfig({ ...config, tagline: e.target.value })}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100"
                  />
                </div>

                <div>
                  <label className="block text-neutral-600 dark:text-neutral-400 mb-1">Support Email</label>
                  <input
                    type="email"
                    value={config.supportEmail}
                    onChange={(e) => setConfig({ ...config, supportEmail: e.target.value })}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100"
                  />
                </div>

                <div>
                  <label className="block text-neutral-600 dark:text-neutral-400 mb-1">WhatsApp Contact</label>
                  <input
                    type="text"
                    value={config.supportWhatsApp}
                    onChange={(e) => setConfig({ ...config, supportWhatsApp: e.target.value })}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100 font-mono"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Tools Directory & Limits */}
          {activeTab === 'tools' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100 pb-2 border-b border-neutral-100 dark:border-neutral-800">
                Manage Tools Visibility & Free Processing Limits
              </h3>

              <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                {STUDIO_TOOLS.map((tool) => {
                  const setting = config.toolSettings[tool.id] || { enabled: true, dailyLimit: 50 };
                  return (
                    <div
                      key={tool.id}
                      className="p-3 bg-neutral-50 dark:bg-neutral-950 rounded-lg border border-neutral-200 dark:border-neutral-800 flex items-center justify-between gap-4"
                    >
                      <div>
                        <div className="font-semibold text-neutral-900 dark:text-neutral-100">{tool.name}</div>
                        <div className="text-[11px] text-neutral-500">{tool.category} · ID: {tool.id}</div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-1.5 text-neutral-500">
                          <span>Daily Limit:</span>
                          <input
                            type="number"
                            min="1"
                            max="1000"
                            value={setting.dailyLimit}
                            onChange={(e) => updateToolLimit(tool.id, parseInt(e.target.value) || 50)}
                            className="w-16 px-1.5 py-0.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded text-center font-mono"
                          />
                        </div>

                        <button
                          onClick={() => toggleToolEnabled(tool.id)}
                          className={`flex items-center gap-1 px-3 py-1 rounded text-xs font-semibold ${setting.enabled ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300' : 'bg-neutral-200 dark:bg-neutral-800 text-neutral-500'}`}
                        >
                          {setting.enabled ? 'Enabled' : 'Disabled'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Tab 3: Monetization & Plans */}
          {activeTab === 'plans' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100 pb-2 border-b border-neutral-100 dark:border-neutral-800">
                Monetization & Future Subscription Plans
              </h3>
              <p className="text-xs text-neutral-500">
                Configure prices and features for future billing activation. No payment is currently charged to normal users.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {config.plans.map((p) => (
                  <div key={p.id} className="p-4 bg-neutral-50 dark:bg-neutral-950 rounded-xl border border-neutral-200 dark:border-neutral-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-neutral-900 dark:text-neutral-100">{p.name}</span>
                      <button
                        onClick={() => updatePlan(p.id, { enabled: !p.enabled })}
                        className={`px-2 py-0.5 rounded text-[11px] font-semibold ${p.enabled ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300' : 'bg-neutral-200 text-neutral-600'}`}
                      >
                        {p.enabled ? 'Active' : 'Inactive'}
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-neutral-500 block mb-0.5">Monthly Price ($)</label>
                        <input
                          type="number"
                          value={p.priceMonthly}
                          onChange={(e) => updatePlan(p.id, { priceMonthly: parseFloat(e.target.value) || 0 })}
                          className="w-full p-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-neutral-500 block mb-0.5">Yearly Price ($)</label>
                        <input
                          type="number"
                          value={p.priceYearly}
                          onChange={(e) => updatePlan(p.id, { priceYearly: parseFloat(e.target.value) || 0 })}
                          className="w-full p-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded font-mono"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 4: SEO & Metadata */}
          {activeTab === 'seo' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100 pb-2 border-b border-neutral-100 dark:border-neutral-800">
                Search Engine Optimization & OpenGraph Metadata
              </h3>

              <div className="space-y-3">
                <div>
                  <label className="block text-neutral-600 dark:text-neutral-400 mb-1">Site Title Tag (&lt;title&gt;)</label>
                  <input
                    type="text"
                    value={config.seo.siteTitle}
                    onChange={(e) => setConfig({ ...config, seo: { ...config.seo, siteTitle: e.target.value } })}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100"
                  />
                </div>

                <div>
                  <label className="block text-neutral-600 dark:text-neutral-400 mb-1">Meta Description</label>
                  <textarea
                    rows={3}
                    value={config.seo.metaDescription}
                    onChange={(e) => setConfig({ ...config, seo: { ...config.seo, metaDescription: e.target.value } })}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100 resize-none"
                  />
                </div>

                <div>
                  <label className="block text-neutral-600 dark:text-neutral-400 mb-1">Keywords</label>
                  <input
                    type="text"
                    value={config.seo.keywords}
                    onChange={(e) => setConfig({ ...config, seo: { ...config.seo, keywords: e.target.value } })}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100"
                  />
                </div>

                <div>
                  <label className="block text-neutral-600 dark:text-neutral-400 mb-1">Canonical URL</label>
                  <input
                    type="text"
                    value={config.seo.canonicalUrl}
                    onChange={(e) => setConfig({ ...config, seo: { ...config.seo, canonicalUrl: e.target.value } })}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg text-neutral-900 dark:text-neutral-100 font-mono"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Tab 5: Announcements & Maintenance */}
          {activeTab === 'announcements' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100 pb-2 border-b border-neutral-100 dark:border-neutral-800">
                Announcements & Maintenance Mode
              </h3>

              <div className="p-4 bg-neutral-50 dark:bg-neutral-950 rounded-xl border border-neutral-200 dark:border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-neutral-900 dark:text-neutral-100">Top Announcement Banner</span>
                  <input
                    type="checkbox"
                    checked={config.announcement.show}
                    onChange={(e) => setConfig({ ...config, announcement: { ...config.announcement, show: e.target.checked } })}
                    className="rounded accent-indigo-600 w-4 h-4"
                  />
                </div>

                <div>
                  <label className="block text-neutral-500 mb-1">Announcement Message</label>
                  <input
                    type="text"
                    value={config.announcement.message}
                    onChange={(e) => setConfig({ ...config, announcement: { ...config.announcement, message: e.target.value } })}
                    className="w-full p-2.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg"
                  />
                </div>
              </div>

              <div className="p-4 bg-neutral-50 dark:bg-neutral-950 rounded-xl border border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-neutral-900 dark:text-neutral-100 block">System Maintenance Mode</span>
                  <span className="text-[11px] text-neutral-500">When enabled, visitors will see a graceful maintenance page.</span>
                </div>
                <input
                  type="checkbox"
                  checked={config.maintenanceMode}
                  onChange={(e) => setConfig({ ...config, maintenanceMode: e.target.checked })}
                  className="rounded accent-indigo-600 w-4 h-4"
                />
              </div>
            </div>
          )}

          {/* Tab 6: Analytics & Ads */}
          {activeTab === 'analytics' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100 pb-2 border-b border-neutral-100 dark:border-neutral-800">
                Google Analytics 4 & AdSense Slots
              </h3>

              <div className="space-y-3">
                <div>
                  <label className="block text-neutral-600 dark:text-neutral-400 mb-1">Google Analytics 4 Measurement ID</label>
                  <input
                    type="text"
                    placeholder="G-XXXXXXXXXX"
                    value={config.analytics.ga4MeasurementId}
                    onChange={(e) => setConfig({ ...config, analytics: { ...config.analytics, ga4MeasurementId: e.target.value } })}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block text-neutral-600 dark:text-neutral-400 mb-1">Google Search Console Verification Tag</label>
                  <input
                    type="text"
                    placeholder="google-site-verification=..."
                    value={config.analytics.googleSearchConsoleCode}
                    onChange={(e) => setConfig({ ...config, analytics: { ...config.analytics, googleSearchConsoleCode: e.target.value } })}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block text-neutral-600 dark:text-neutral-400 mb-1">Google AdSense Publisher ID</label>
                  <input
                    type="text"
                    placeholder="pub-XXXXXXXXXXXXXXXX"
                    value={config.analytics.adsensePublisherId}
                    onChange={(e) => setConfig({ ...config, analytics: { ...config.analytics, adsensePublisherId: e.target.value } })}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg font-mono"
                  />
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <input
                    type="checkbox"
                    checked={config.analytics.enableAdSensePlaceholders}
                    onChange={(e) => setConfig({ ...config, analytics: { ...config.analytics, enableAdSensePlaceholders: e.target.checked } })}
                    className="rounded accent-indigo-600"
                  />
                  <span>Enable non-intrusive AdSense banner placeholders</span>
                </div>
              </div>
            </div>
          )}

          {/* Tab 7: Security */}
          {activeTab === 'security' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100 pb-2 border-b border-neutral-100 dark:border-neutral-800">
                Security Architecture & Environment Credentials
              </h3>

              <div className="p-4 bg-neutral-50 dark:bg-neutral-950 rounded-xl border border-neutral-200 dark:border-neutral-800 space-y-2">
                <span className="font-semibold text-neutral-800 dark:text-neutral-200 block">Server-Side Credentials Policy</span>
                <p className="text-neutral-500 leading-relaxed">
                  Admin passwords and GEMINI_API_KEY are verified strictly on the server-side via environment variables (<code className="font-mono text-indigo-400">ADMIN_EMAIL</code>, <code className="font-mono text-indigo-400">ADMIN_INITIAL_PASSWORD</code>, <code className="font-mono text-indigo-400">GEMINI_API_KEY</code>). No credentials or secrets are ever bundled into client JavaScript.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
