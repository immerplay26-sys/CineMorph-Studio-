import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import crypto from 'crypto';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const AUTH_SECRET = process.env.AUTH_SECRET || 'cinemorph-secret-key-salt-2026';

app.use(express.json({ limit: '75mb' }));
app.use(express.urlencoded({ extended: true, limit: '75mb' }));

// Provider-agnostic In-Memory & File-Backed Job Queue
interface JobRecord {
  id: string;
  type: string;
  status: 'queued' | 'processing' | 'completed' | 'failed' | 'cancelled';
  progress: number;
  currentStep?: string;
  error?: string;
  resultData?: unknown;
  createdAt: number;
  updatedAt: number;
}

const jobQueue = new Map<string, JobRecord>();
const activeAdminTokens = new Set<string>();

const CONFIG_FILE = path.resolve(process.cwd(), '.site-config.json');
const TEMP_DIR = path.resolve(process.cwd(), '.temp_media');

if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, { recursive: true });
}

// Temporary file auto-cleanup (purges files older than 1 hour)
function cleanupTempFiles() {
  try {
    const files = fs.readdirSync(TEMP_DIR);
    const now = Date.now();
    for (const f of files) {
      const p = path.join(TEMP_DIR, f);
      const stat = fs.statSync(p);
      if (now - stat.mtimeMs > 3600000) {
        fs.unlinkSync(p);
      }
    }
  } catch (err) {
    console.error('Temp file cleanup error:', err);
  }
}
setInterval(cleanupTempFiles, 600000); // Check every 10 mins

function loadSiteConfig() {
  if (fs.existsSync(CONFIG_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
    } catch {
      // Fallback
    }
  }
  return null;
}

function saveSiteConfigToFile(cfg: unknown) {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write site config file:', err);
  }
}

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Admin Login endpoint
app.post('/api/admin/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  const configuredEmail = process.env.ADMIN_EMAIL || 'admin@cinemorph.studio';
  const configuredPassword = process.env.ADMIN_INITIAL_PASSWORD || 'CineMorphAdmin2026!';

  if (!email || !password) {
    res.status(400).json({ error: 'Email and password are required' });
    return;
  }

  if (email.trim().toLowerCase() === configuredEmail.trim().toLowerCase() && password === configuredPassword) {
    const token = crypto.createHmac('sha256', AUTH_SECRET).update(`${email}-${Date.now()}`).digest('hex');
    activeAdminTokens.add(token);
    res.json({
      success: true,
      token,
      user: {
        email: configuredEmail,
        role: 'super_admin'
      }
    });
  } else {
    res.status(401).json({ error: 'Invalid admin credentials' });
  }
});

function requireAdmin(req: Request, res: Response, next: () => void) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Unauthorized: Admin token required' });
    return;
  }
  const token = authHeader.split(' ')[1];
  if (!activeAdminTokens.has(token)) {
    res.status(401).json({ error: 'Session expired or invalid token' });
    return;
  }
  next();
}

app.get('/api/admin/config', (req: Request, res: Response) => {
  const cfg = loadSiteConfig();
  res.json(cfg || { status: 'default' });
});

app.post('/api/admin/config', requireAdmin, (req: Request, res: Response) => {
  saveSiteConfigToFile(req.body);
  res.json({ success: true, message: 'Configuration saved successfully' });
});

// Job Queue Endpoints
app.get('/api/jobs/:id', (req: Request, res: Response) => {
  const job = jobQueue.get(req.params.id);
  if (!job) {
    res.status(404).json({ error: 'Job not found' });
    return;
  }
  res.json(job);
});

app.post('/api/jobs/:id/cancel', (req: Request, res: Response) => {
  const job = jobQueue.get(req.params.id);
  if (!job) {
    res.status(404).json({ error: 'Job not found' });
    return;
  }
  job.status = 'cancelled';
  job.updatedAt = Date.now();
  res.json({ success: true, message: 'Job cancelled' });
});

// Multilingual Video Dubbing & Translation endpoint
app.post('/api/ai/dubbing', async (req: Request, res: Response) => {
  try {
    const { transcript, sourceLanguage = 'en', targetLanguage = 'es', voiceName = 'Kore' } = req.body;
    if (!transcript) {
      res.status(400).json({ error: 'Transcript text is required for translation and dubbing' });
      return;
    }

    if (!apiKey) {
      res.status(500).json({ error: 'GEMINI_API_KEY is not configured on the server' });
      return;
    }

    // Step 1: Translate transcript accurately
    const prompt = `Translate the following dialogue/transcript from ${sourceLanguage} to ${targetLanguage}.
Keep sentences natural for speech timing.
Return strictly valid JSON with format:
{
  "translatedText": "Full translated speech in ${targetLanguage}",
  "cues": [
    { "original": "sentence", "translated": "translated sentence" }
  ]
}

Text to translate:
"${transcript}"`;

    const translationResponse = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: { responseMimeType: 'application/json' }
    });

    const parsed = JSON.parse(translationResponse.text || '{}');
    const translatedText = parsed.translatedText || transcript;

    // Step 2: Generate natural speech audio in the target language
    const ttsResponse = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: translatedText,
              speechMetadata: {
                style: `Clear professional fluent ${targetLanguage} speaker, articulate, natural cadence`,
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voiceName || 'Kore' },
          },
        },
      },
    });

    const base64Audio = ttsResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

    res.json({
      translatedText,
      cues: parsed.cues || [],
      audioBase64: base64Audio || null
    });
  } catch (err: unknown) {
    console.error('Dubbing error:', err);
    const msg = err instanceof Error ? err.message : 'Dubbing failed';
    res.status(500).json({ error: msg });
  }
});

// AI Content Generation endpoint (Gemini 3.8 Flash)
app.post('/api/ai/content-generate', async (req: Request, res: Response) => {
  try {
    const { prompt, taskType } = req.body;
    if (!prompt) {
      res.status(400).json({ error: 'Prompt is required' });
      return;
    }

    if (!apiKey) {
      res.status(500).json({ error: 'GEMINI_API_KEY is not configured on the server' });
      return;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: `You are CineMorph Studio AI, an expert video director, viral copywriter, and YouTube/Shorts producer. Produce exceptionally high-quality, actionable, creator-ready results without conversational fluff.`
      }
    });

    res.json({ text: response.text || '' });
  } catch (err: unknown) {
    console.error('Error generating AI content:', err);
    const msg = err instanceof Error ? err.message : 'Unknown generation error';
    res.status(500).json({ error: msg });
  }
});

// AI Text to Speech (Gemini 3.8 Flash Lite TTS)
app.post('/api/ai/tts', async (req: Request, res: Response) => {
  try {
    const { text, voiceName = 'Kore', speed = 1.0 } = req.body;
    if (!text) {
      res.status(400).json({ error: 'Text is required for TTS' });
      return;
    }

    if (!apiKey) {
      res.status(500).json({ error: 'GEMINI_API_KEY is not configured on the server' });
      return;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: text,
              speechMetadata: {
                style: 'Clear, modern professional studio narrator, energetic, articulate',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voiceName || 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      throw new Error('TTS model did not return audio data');
    }

    res.json({ audioBase64: base64Audio });
  } catch (err: unknown) {
    console.error('TTS error:', err);
    const msg = err instanceof Error ? err.message : 'TTS failure';
    res.status(500).json({ error: msg });
  }
});

// AI Detect Viral Clips & Moments with exact sentence boundaries
app.post('/api/ai/detect-clips', async (req: Request, res: Response) => {
  try {
    const { videoTitle, durationSeconds, transcriptContext, targetCount = 3, targetDuration = 30 } = req.body;

    if (!apiKey) {
      res.status(500).json({ error: 'GEMINI_API_KEY not configured' });
      return;
    }

    const prompt = `Analyze this video for viral Short/Reel clip extraction:
Video Title: "${videoTitle || 'Untitled Video'}"
Total Duration: ${durationSeconds} seconds
Transcript / Context: "${transcriptContext || 'Engaging discussion with hooks and practical advice'}"
Requested Clips Count: ${targetCount}
Target Clip Duration: around ${targetDuration} seconds

Return a JSON array of exactly ${targetCount} high-impact clips that make great standalone 9:16 vertical shorts.
Each clip must cut at natural sentence boundaries and have:
- title: string (punchy clip title)
- hook: string (compelling opening hook on screen)
- startTime: number (in seconds, must be < durationSeconds)
- endTime: number (in seconds, duration 15 to 60 seconds)
- viralScore: number (80 to 98)
- rationale: string (why this moment holds high retention)
- sentenceBoundaryStart: string (opening phrase)
- sentenceBoundaryEnd: string (closing phrase)
- ctaSuggestion: string (call to action for end of clip)
- hashtags: string[] (3 relevant hashtags)
- description: string (1-sentence social caption)

Format strictly as valid JSON with key "clips": [...]`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });

    const parsed = JSON.parse(response.text || '{"clips": []}');
    res.json(parsed);
  } catch (err: unknown) {
    console.error('Clip detection error:', err);
    res.status(500).json({ error: 'Failed to detect clips' });
  }
});

// AI Transcribe Audio (Gemini 3.5 Transcribe)
app.post('/api/ai/transcribe', async (req: Request, res: Response) => {
  try {
    const { audioBase64, mimeType = 'audio/webm' } = req.body;
    if (!audioBase64) {
      res.status(400).json({ error: 'audioBase64 data required' });
      return;
    }

    if (!apiKey) {
      res.status(500).json({ error: 'GEMINI_API_KEY not configured' });
      return;
    }

    const audioPart = {
      inlineData: {
        mimeType: mimeType,
        data: audioBase64,
      },
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-transcribe',
      contents: {
        parts: [
          audioPart,
          {
            text: 'Transcribe this audio precisely into text. Format each sentence with [MM:SS] timestamp and speaker label if multiple speakers exist.'
          }
        ]
      }
    });

    res.json({ transcript: response.text || '', cues: [] });
  } catch (err: unknown) {
    console.error('Transcription error:', err);
    res.status(500).json({ error: 'Failed to transcribe' });
  }
});

// Serve admin-login.html directly
app.get('/admin-login.html', (req: Request, res: Response) => {
  const filePath = path.resolve(process.cwd(), 'admin-login.html');
  if (fs.existsSync(filePath)) {
    res.sendFile(filePath);
  } else {
    res.redirect('/?view=admin');
  }
});

// Mount Vite or serve static dist
async function setupViteOrStatic() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CineMorph Studio server active at http://0.0.0.0:${PORT}`);
  });
}

setupViteOrStatic().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
